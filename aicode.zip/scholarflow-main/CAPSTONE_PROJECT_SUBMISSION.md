# ScholarFlow - Capstone Project Submission

**Automated Multilingual Research Submission Processor**  
*Multi-Agent AI System with Semantic Kernel Process Framework*

---

## Project Overview

ScholarFlow is a proof-of-concept multi-agent AI system that automates the processing of academic research paper submissions. The system demonstrates the effective use of Microsoft Semantic Kernel's Process Framework to orchestrate multiple specialized AI agents for document ingestion, translation, validation, and question-answering.

### Key Achievements

- ✅ **Multi-Agent Architecture**: 8 specialized AI agents working collaboratively
- ✅ **Process Orchestration**: Leverages Semantic Kernel's built-in Process Framework for workflow management
- ✅ **RAG Pipeline**: Implemented retrieval-augmented generation for intelligent Q&A
- ✅ **Human-in-the-Loop**: Review workflow with approval/rejection capabilities
- ✅ **Modern Web UI**: Vanilla JavaScript SPA with role-based access control
- ✅ **Comprehensive Validation**: Plagiarism detection, content safety, metadata validation

### Technology Stack

- **Backend**: ASP.NET Core 10.0, Entity Framework Core
- **AI Framework**: Microsoft Semantic Kernel 1.73.0 with Process Framework
- **AI Services**: Azure OpenAI (GPT-4o, text-embedding-3-large)
- **Database**: SQLite (with EF Core migrations)
- **Frontend**: Vue.js 3 (via CDN) + Tailwind CSS
- **Authentication**: JWT-based with role-based access control
- **Vector Store**: In-memory vector database with cosine similarity

---

### Complete Feature Set
- ✅ PDF upload with drag-and-drop interface
- ✅ Text extraction (including OCR for scanned documents)
- ✅ Automatic language detection
- ✅ Translation to English (supports 100+ languages)
- ✅ Structured metadata extraction (title, authors, affiliations, abstract, keywords)
- ✅ Validation rules (page count, required sections)
- ✅ Plagiarism detection with vector embeddings
- ✅ Content safety checking (toxicity detection)
- ✅ Human-in-the-loop review workflow
- ✅ AI-generated summaries
- ✅ RAG pipeline with in-memory vector store
- ✅ Conversational Q&A with chat history
- ✅ Dark/Light theme UI
- ✅ Role-based access control (Researcher/Reviewer)

### Architecture Highlights

**Semantic Kernel Process Framework**:
- Built-in workflow orchestration eliminates custom state machine development
- Step-based execution with automatic state management and transitions
- Error handling with retry logic and graceful failure recovery
- Comprehensive audit logging at every step for full traceability

**Multi-Agent Architecture**:
- 8 specialized AI agents with single responsibility principle (Ingestion, Preprocess, Translation, Extraction, Validation, Summary, RAG, and Q&A)
- Interface-based design enabling independent testing and mocking
- Agent orchestration through ProcessOrchestrator coordinating sequential workflow execution
- Stateless agent design with immutable input/output contracts

**Document Processing Pipeline**:
- 7-step automated workflow from upload to completion (Language Detection → Translation → Metadata Extraction → Validation → Summarization → RAG Indexing → Human Review)
- Asynchronous processing with status tracking and real-time progress updates
- Parallel validation checks including plagiarism detection and content safety
- Support for 100+ languages with automatic translation to English

**RAG Implementation**:
- In-memory vector store with cosine similarity search for semantic retrieval
- Azure OpenAI text-embedding-3-large for high-quality embeddings (3072 dimensions)
- Top-K retrieval with configurable relevance thresholds
- Context-aware Q&A with source attribution and chat history persistence

**Data Architecture**:
- SQLite database with Entity Framework Core for development and POC
- Four core entities: Submissions, ChatMessages, AuditLogs, and Users
- Built-in database migrations for schema versioning
- Optimized for single-server deployment with potential for horizontal scaling

**API Design**:
- RESTful API with standard HTTP verbs and status codes
- JWT-based authentication with role-based authorization (Author/Reviewer)
- Six controller endpoints: Auth, Submissions, Process, Chat, HumanReview, and Health
- OpenAPI/Swagger documentation for API exploration and testing

**UI Architecture**:
- Vue.js 3 Single-Page Application with CDN delivery (no build step required)
- Tailwind CSS for responsive, mobile-first design
- Real-time status updates and progress tracking for document processing
- Role-based UI rendering with separate views for researchers and reviewers

---

## Future Enhancements

### 1. **Repository Pattern Implementation**

**Current State**: Direct Entity Framework Context usage in services

**Proposed Enhancement**: Implement Generic Repository and Unit of Work patterns

**Repository Pattern Interface**:
- Generic repository interface with standard CRUD operations (GetById, GetAll, Add, Update, Delete)
- Support for async operations throughout
- Type-safe implementations for each entity

**Unit of Work Pattern**:
- Centralized transaction management across multiple repositories
- Coordinated SaveChanges for multiple entity updates
- Support for explicit transaction control (Begin, Commit, Rollback)
- Automatic transaction rollback on errors
- Disposed pattern implementation for proper resource cleanup

**Benefits**:
- Better separation of concerns between business logic and data access
- Improved testability with mock repositories
- Centralized data access logic with consistent patterns
- Transaction management across multiple repositories
- Reduced code duplication in service layer
- Easier to swap database providers if needed

---

### 2. **Comprehensive Test Coverage**

**Current Implementation**: The project includes extensive unit and integration tests across all layers

#### Test Architecture
**Testing Framework**: xUnit with FluentAssertions for readable assertions and Moq for mocking dependencies

**Test Database**: In-memory SQLite database for integration tests to avoid external dependencies

**Test Coverage**: The project includes **26 comprehensive test classes** across all architectural layers, providing robust validation of system behavior and quality assurance.

**Key Testing Areas**:
- **Multi-Agent Testing**: 8 test classes covering all AI agents (Extraction, Ingestion, Preprocess, Translation, Validation, Summary, RAG, and Q&A agents) with focus on interface contracts, error handling, and agent lifecycle management
- **Service Layer Testing**: 11 test classes validating business logic including authentication, submission workflow, PDF processing, plagiarism detection, content safety, chat functionality, audit logging, health checks, and human review processes
- **API Endpoint Testing**: 6 controller test classes ensuring proper HTTP request/response handling, authorization, status codes, and endpoint validation for Auth, Submissions, Process, Chat, HumanReview, and Health endpoints
- **Infrastructure Testing**: Orchestration tests for workflow execution, RAG pipeline integration, and vector store operations including embedding storage, cosine similarity search, and concurrent access handling

**Testing Approach**: All tests use xUnit with FluentAssertions for readable assertions, Moq for mocking external dependencies (Azure OpenAI, database), in-memory SQLite for test isolation, and follow Arrange-Act-Assert pattern with comprehensive test organization and documentation.

---

### 3. **File Reprocessing Behavior**

**Current State**: Every uploaded file is treated as new submission with no duplicate detection

**Proposed Enhancement**: Implement intelligent duplicate detection and reprocessing workflow using SHA256 file hashing to identify duplicates and provide users with flexible handling options.

**Key Features**:
- **Duplicate Detection**: Calculate SHA256 hash for each uploaded file and check against existing submissions to identify duplicates, failed processing attempts, or resubmissions of updated versions
- **Flexible Reprocessing Options**: Provide users with choices including CreateNew (always new submission), ResumeIfFailed (retry from failed step), ReplaceIfComplete (replace existing), or VersionControl (maintain version history with parent-child relationships)
- **Version Tracking**: Implement ParentSubmissionId field for lineage tracking, support version comparison, and maintain audit trail of document evolution with metadata for version notes and change descriptions

---

### 4. **Enterprise Authentication with Azure Entra ID**

**Current State**: Basic JWT authentication with hardcoded user credentials

**Proposed Enhancement**: Replace basic authentication with Azure Entra ID (formerly Azure Active Directory) integration for enterprise-grade security and user management.

**Key Features**:
- **Enterprise SSO**: Single Sign-On with organizational accounts, Multi-Factor Authentication (MFA) support, Conditional Access policies, and centralized identity management through Azure AD
- **Group-Based Authorization**: Implement claim-based authorization policies using Azure AD security groups for Author and Reviewer roles, eliminating need for local user management
- **Phased Migration**: Maintain dual authentication support (basic auth for development, Entra ID for production) with configuration-driven approach, allowing gradual migration and testing before full enterprise deployment

---

### 5. **Email Monitoring for Automated Submission**

**Current State**: Manual file upload through web UI only

**Proposed Enhancement**: Add automated email-based submission processing through a background service that monitors a designated inbox and processes PDF attachments.

**Key Features**:
- **Background Email Processing**: Implement EmailMonitoringService as hosted background service with configurable polling interval (default: 5 minutes) to monitor designated inbox (e.g., submissions@university.edu), extract PDF attachments, validate sender authorization, and auto-submit to processing pipeline
- **Integration Options**: Support multiple email sources including Microsoft Graph API for Exchange Online, IMAP/POP3 for general email servers, or Azure Logic Apps for workflow automation with flexible sender authentication via domain whitelisting
- **Automated Notifications**: Send email confirmations at each stage (received, processing, complete) using customizable HTML templates, with metadata extraction from email subject/body for automatic paper classification and tracking

---

### 6. **Intelligent Auto-Approval System**

**Current State**: All submissions require manual reviewer approval

**Proposed Enhancement**: Implement configurable AI-driven auto-approval system with safety guardrails to automatically approve high-quality submissions based on validation scores and business rules.

**Key Features**:
- **Score-Based Decision Engine**: Configure thresholds for overall score (85%), plagiarism score (90%), content safety score (95%), and metadata completeness (80%) with rule-based evaluation to automatically approve submissions meeting all criteria or route to manual review
- **Flexible Exclusion Rules**: Define exclusion policies including author blocklists, first-time submitter review requirements, high-risk domain restrictions, and journal-specific review needs to ensure appropriate human oversight
- **Safety and Audit**: Comprehensive audit trail for all auto-approval decisions, random sampling (10%) for periodic human verification, reviewer override capability, configurable cooling-off periods, and automated compliance reporting with weekly statistics on approval rates and accuracy

---

## Technical Recommendations

### Database Migration Strategy
- Move from SQLite to SQL Server or PostgreSQL for production
- Implement connection pooling and query optimization
- Add database indexes for frequently queried fields
- Set up automated backups and point-in-time recovery

### Scalability Considerations
- Implement Azure Service Bus for async processing queue
- Use Azure Functions for background job processing
- Add Redis cache for frequently accessed data
- Consider horizontal scaling with load balancer

### Monitoring and Observability
- Integrate Application Insights for telemetry
- Set up Azure Monitor alerts for failures
- Implement structured logging with correlation IDs
- Create dashboards for processing metrics

### Security Enhancements
- Implement rate limiting on API endpoints
- Add CORS policies for production deployment
- Enable HTTPS with proper certificate management
- Implement API key rotation strategy
- Add input sanitization for XSS prevention

---

## Deployment Strategy

### Development Environment
- Local development with SQLite and mock services
- Docker Compose for full stack testing
- Automated CI/CD pipeline with GitHub Actions

### Staging Environment
- Azure App Service with SQL Azure
- Azure OpenAI in same region for low latency
- Azure Key Vault for secrets management
- Automated deployment from main branch

### Production Environment
- Blue-green deployment strategy
- Automated rollback on health check failure
- Geographic redundancy for disaster recovery
- 99.9% SLA target with uptime monitoring

---

## Project Deliverables

### Code Repository
- Complete source code with well-documented architecture
- Comprehensive README with setup instructions
- Postman collection for API testing


### Documentation
- Architecture diagrams included in Readme.md(system flow, agent orchestration)
- API documentation Swagger file(endpoints, DTOs, examples)


---

## Contact and Credentials

For access credentials, Azure OpenAI API keys, and project demonstration:

**Contact**: sumeet.sethi@infosys.com

---

## Conclusion

ScholarFlow successfully demonstrates the practical application of multi-agent AI systems using Microsoft Semantic Kernel's Process Framework. The project showcases enterprise-ready patterns for document processing, RAG implementation, and human-in-the-loop workflows.

The proposed future enhancements provide a clear roadmap for transforming this proof-of-concept into a production-ready system capable of handling real-world academic submission workflows at scale.

**Key Learnings**:
- Semantic Kernel's Process Framework significantly reduces boilerplate for workflow orchestration
- RAG pipelines require careful balance between retrieval accuracy and response generation
- Human-in-the-loop design is essential for AI-assisted decision-making systems
- Multi-agent architectures enable separation of concerns and independent testing

---

*March 9, 2026*
