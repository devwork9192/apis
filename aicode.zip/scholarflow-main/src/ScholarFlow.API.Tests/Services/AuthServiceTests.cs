using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using ScholarFlow.API.Configuration;
using ScholarFlow.API.Services;
using Xunit;

namespace ScholarFlow.API.Tests.Services;

public class AuthServiceTests
{
    private readonly Mock<ILogger<AuthService>> _loggerMock;
    private readonly IOptions<JwtSettings> _jwtSettings;
    private readonly IOptions<AuthSettings> _authSettings;
    private readonly AuthService _authService;

    public AuthServiceTests()
    {
        _loggerMock = new Mock<ILogger<AuthService>>();
        
        // Setup test JWT settings
        _jwtSettings = Options.Create(new JwtSettings
        {
            SecretKey = "ThisIsATestSecretKeyWith32CharsMin123456",
            Issuer = "ScholarFlowTest",
            Audience = "ScholarFlowTestAPI",
            ExpirationMinutes = 60
        });

        // Setup test user credentials
        _authSettings = Options.Create(new AuthSettings
        {
            Users = new List<UserConfig>
            {
                new UserConfig
                {
                    Username = "researcher@test.edu",
                    Password = "TestPass123",
                    Role = "Author"
                },
                new UserConfig
                {
                    Username = "admin@test.edu",
                    Password = "AdminPass456",
                    Role = "Reviewer"
                }
            }
        });

        _authService = new AuthService(_jwtSettings, _authSettings, _loggerMock.Object);
    }

    [Fact]
    public async Task AuthenticateAsync_WithValidAuthorCredentials_ReturnsSuccessWithAuthorRole()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "TestPass123";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.NotNull(result);
        Assert.NotNull(result.Token);
        Assert.Equal("Author", result.Role);
        Assert.Equal(username, result.Username);
        Assert.True(result.ExpiresAt > DateTime.UtcNow);
    }

    [Fact]
    public async Task AuthenticateAsync_WithValidReviewerCredentials_ReturnsSuccessWithReviewerRole()
    {
        // Arrange
        var username = "admin@test.edu";
        var password = "AdminPass456";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.NotNull(result);
        Assert.NotNull(result.Token);
        Assert.Equal("Reviewer", result.Role);
        Assert.Equal(username, result.Username);
        Assert.True(result.ExpiresAt > DateTime.UtcNow);
    }

    [Fact]
    public async Task AuthenticateAsync_WithInvalidUsername_ReturnsNull()
    {
        // Arrange
        var username = "nonexistent@test.edu";
        var password = "TestPass123";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task AuthenticateAsync_WithInvalidPassword_ReturnsNull()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "WrongPassword";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task AuthenticateAsync_WithEmptyUsername_ReturnsNull()
    {
        // Arrange
        var username = "";
        var password = "TestPass123";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task AuthenticateAsync_WithEmptyPassword_ReturnsNull()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void ValidateCredentials_WithValidCredentials_ReturnsTrue()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "TestPass123";

        // Act
        var result = _authService.ValidateCredentials(username, password);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void ValidateCredentials_WithInvalidCredentials_ReturnsFalse()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "WrongPassword";

        // Act
        var result = _authService.ValidateCredentials(username, password);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task GeneratedToken_ContainsCorrectClaims()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "TestPass123";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.NotNull(result);
        
        // Parse the JWT token
        var tokenHandler = new JwtSecurityTokenHandler();
        var jwtToken = tokenHandler.ReadJwtToken(result.Token);

        // Verify claims
        Assert.Equal(username, jwtToken.Claims.First(c => c.Type == ClaimTypes.Name).Value);
        Assert.Equal(username, jwtToken.Claims.First(c => c.Type == ClaimTypes.Email).Value);
        Assert.Equal("Author", jwtToken.Claims.First(c => c.Type == ClaimTypes.Role).Value);
        Assert.Equal(username, jwtToken.Claims.First(c => c.Type == JwtRegisteredClaimNames.Sub).Value);
        Assert.NotNull(jwtToken.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Jti));
        Assert.NotNull(jwtToken.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Iat));
    }

    [Fact]
    public async Task GeneratedToken_HasCorrectIssuerAndAudience()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "TestPass123";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.NotNull(result);
        
        // Parse the JWT token
        var tokenHandler = new JwtSecurityTokenHandler();
        var jwtToken = tokenHandler.ReadJwtToken(result.Token);

        // Verify issuer and audience
        Assert.Equal("ScholarFlowTest", jwtToken.Issuer);
        Assert.Contains("ScholarFlowTestAPI", jwtToken.Audiences);
    }

    [Fact]
    public async Task GeneratedToken_ExpirationMatchesConfiguration()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "TestPass123";
        var expectedExpirationMinutes = _jwtSettings.Value.ExpirationMinutes;

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.NotNull(result);
        
        // Parse the JWT token
        var tokenHandler = new JwtSecurityTokenHandler();
        var jwtToken = tokenHandler.ReadJwtToken(result.Token);

        // Verify expiration is approximately correct (within 1 minute tolerance)
        var expectedExpiry = DateTime.UtcNow.AddMinutes(expectedExpirationMinutes);
        var actualExpiry = jwtToken.ValidTo;
        Assert.True(Math.Abs((expectedExpiry - actualExpiry).TotalMinutes) < 1);
    }

    [Fact]
    public async Task AuthenticateAsync_CaseInsensitiveUsername_ReturnsSuccess()
    {
        // Arrange
        var username = "RESEARCHER@TEST.EDU"; // Uppercase
        var password = "TestPass123";

        // Act
        var result = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("Author", result.Role);
    }

    [Fact]
    public async Task MultipleAuthentications_GenerateUniqueTokenIds()
    {
        // Arrange
        var username = "researcher@test.edu";
        var password = "TestPass123";

        // Act
        var result1 = await _authService.AuthenticateAsync(username, password);
        var result2 = await _authService.AuthenticateAsync(username, password);

        // Assert
        Assert.NotNull(result1);
        Assert.NotNull(result2);
        
        var tokenHandler = new JwtSecurityTokenHandler();
        var jwtToken1 = tokenHandler.ReadJwtToken(result1.Token);
        var jwtToken2 = tokenHandler.ReadJwtToken(result2.Token);

        var jti1 = jwtToken1.Claims.First(c => c.Type == JwtRegisteredClaimNames.Jti).Value;
        var jti2 = jwtToken2.Claims.First(c => c.Type == JwtRegisteredClaimNames.Jti).Value;

        Assert.NotEqual(jti1, jti2);
    }
}
