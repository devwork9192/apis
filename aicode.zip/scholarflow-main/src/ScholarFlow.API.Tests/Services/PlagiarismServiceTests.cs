using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Embeddings;
using Moq;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

#pragma warning disable CS0618 // Type or member is obsolete - ITextEmbeddingGenerationService is used for testing

namespace ScholarFlow.API.Tests.Services;

public class PlagiarismServiceTests : IDisposable
{
    private readonly Mock<ITextEmbeddingGenerationService> _mockEmbeddingService;
    private readonly Mock<ILogger<PlagiarismService>> _mockLogger;
    private readonly ScholarFlowDbContext _dbContext;
    private readonly PlagiarismService _service;
    private readonly DbContextOptions<ScholarFlowDbContext> _options;

    public PlagiarismServiceTests()
    {
        _options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: $"PlagiarismServiceTestDb_{Guid.NewGuid()}")
            .Options;

        _dbContext = new ScholarFlowDbContext(_options);
        _mockEmbeddingService = new Mock<ITextEmbeddingGenerationService>();
        _mockLogger = new Mock<ILogger<PlagiarismService>>();

        _service = new PlagiarismService(
            _mockEmbeddingService.Object,
            _dbContext,
            _mockLogger.Object);
    }

    [Fact]
    public async Task CheckPlagiarismAsync_WithEmptyText_ReturnsFailureResult()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        var result = await _service.CheckPlagiarismAsync(string.Empty, submissionId, 0.7);

        // Assert
        result.Should().NotBeNull();
        result.CheckSuccessful.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Text cannot be empty");
    }

    [Fact]
    public async Task CheckPlagiarismAsync_WithNullText_ReturnsFailureResult()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        var result = await _service.CheckPlagiarismAsync(null!, submissionId, 0.7);

        // Assert
        result.Should().NotBeNull();
        result.CheckSuccessful.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Text cannot be empty");
    }

    // Note: The following tests require integration testing since ITextEmbeddingGenerationService
    // uses extension methods that cannot be mocked with Moq.
    // For actual plagiarism detection testing, create integration tests instead.

    [Fact]
    public void PlagiarismService_Constructor_AcceptsAllDependencies()
    {
        // Arrange & Act
        var service = new PlagiarismService(
            _mockEmbeddingService.Object,
            _dbContext,
            _mockLogger.Object);

        // Assert
        service.Should().NotBeNull();
    }

    public void Dispose()
    {
        _dbContext?.Dispose();
    }
}

/*
 * TESTING NOTES:
 * 
 * The PlagiarismService uses ITextEmbeddingGenerationService which CAN be mocked.
 * This is an example of good design - using interfaces instead of sealed classes directly.
 * 
 * Limitations of these unit tests:
 * - Cannot test actual cosine similarity calculations without real embeddings
 * - Cannot test actual Azure OpenAI embedding generation
 * 
 * For comprehensive testing:
 * 1. Unit tests (this file): Test validation, error handling, database queries
 * 2. Integration tests: Test with actual embedding service and similarity calculations
 */
