using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Services;

/// <summary>
/// Tests for SubmissionService using InMemoryDatabase
/// Note: These are closer to integration tests since they test database queries,
/// but they're isolated and don't require external dependencies
/// </summary>
public class SubmissionServiceTests : IDisposable
{
    private readonly ScholarFlowDbContext _dbContext;
    private readonly Mock<ILogger<SubmissionService>> _mockLogger;
    private readonly SubmissionService _submissionService;
    private readonly DbContextOptions<ScholarFlowDbContext> _options;

    public SubmissionServiceTests()
    {
        _options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: $"SubmissionServiceTestDb_{Guid.NewGuid()}")
            .Options;

        _dbContext = new ScholarFlowDbContext(_options);
        _mockLogger = new Mock<ILogger<SubmissionService>>();
        _submissionService = new SubmissionService(_dbContext, _mockLogger.Object);
    }

    [Fact]
    public async Task GetByIdAsync_WhenSubmissionExists_ReturnsSubmissionWithAuditLogs()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            Status = SubmissionStatus.Summarized,
            UploadedAt = DateTime.UtcNow
        };

        var auditLog = new AuditLog
        {
            Id = Guid.NewGuid(),
            SubmissionId = submissionId,
            Action = "FileUploaded",
            Timestamp = DateTime.UtcNow,
            PerformedBy = "testuser"
        };

        _dbContext.Submissions.Add(submission);
        _dbContext.AuditLogs.Add(auditLog);
        await _dbContext.SaveChangesAsync();

        // Act
        var result = await _submissionService.GetByIdAsync(submissionId);

        // Assert
        result.Should().NotBeNull();
        result!.Id.Should().Be(submissionId);
        result.FileName.Should().Be("test.pdf");
        result.AuditLogs.Should().HaveCount(1);
        result.AuditLogs.First().Action.Should().Be("FileUploaded");
    }

    [Fact]
    public async Task GetByIdAsync_WhenSubmissionNotFound_ReturnsNull()
    {
        // Arrange
        var nonExistentId = Guid.NewGuid();

        // Act
        var result = await _submissionService.GetByIdAsync(nonExistentId);

        // Assert
        result.Should().BeNull();
    }

    [Fact]
    public async Task GetStatusAsync_WhenSubmissionExists_ReturnsStatusResponse()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            Status = SubmissionStatus.Summarized,
            CurrentStage = ProcessingStage.Summary,
            DetectedLanguage = "English",
            PageCount = 10,
            WasTranslated = false,
            Title = "Test Title",
            Authors = "John Doe",
            Summary = "Test summary",
            UploadedAt = DateTime.UtcNow,
            ProcessedAt = DateTime.UtcNow
        };

        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var result = await _submissionService.GetStatusAsync(submissionId);

        // Assert
        result.Should().NotBeNull();
        result!.Id.Should().Be(submissionId);
        result.FileName.Should().Be("test.pdf");
        result.Status.Should().Be("Summarized");
        result.CurrentStage.Should().Be("Summary");
        result.DetectedLanguage.Should().Be("English");
        result.PageCount.Should().Be(10);
        result.WasTranslated.Should().BeFalse();
        result.Title.Should().Be("Test Title");
        result.Authors.Should().Be("John Doe");
        result.Summary.Should().Be("Test summary");
    }

    [Fact]
    public async Task GetStatusAsync_WhenSubmissionNotFound_ReturnsNull()
    {
        // Arrange
        var nonExistentId = Guid.NewGuid();

        // Act
        var result = await _submissionService.GetStatusAsync(nonExistentId);

        // Assert
        result.Should().BeNull();
    }

    [Fact]
    public async Task GetAllAsync_ReturnsAllSubmissionsOrderedByUploadDateDescending()
    {
        // Arrange
        var oldDate = DateTime.UtcNow.AddDays(-2);
        var recentDate = DateTime.UtcNow.AddDays(-1);
        var newestDate = DateTime.UtcNow;

        var submissions = new[]
        {
            new Submission
            {
                Id = Guid.NewGuid(),
                FileName = "old.pdf",
                Status = SubmissionStatus.Summarized,
                UploadedAt = oldDate,
                PageCount = 10,
                DetectedLanguage = "English",
                UploadedBy = "user1"
            },
            new Submission
            {
                Id = Guid.NewGuid(),
                FileName = "recent.pdf",
                Status = SubmissionStatus.Preprocessing,
                UploadedAt = recentDate,
                PageCount = 15,
                DetectedLanguage = "Spanish",
                UploadedBy = "user2"
            },
            new Submission
            {
                Id = Guid.NewGuid(),
                FileName = "newest.pdf",
                Status = SubmissionStatus.Uploaded,
                UploadedAt = newestDate,
                PageCount = 20,
                UploadedBy = "user3"
            }
        };

        _dbContext.Submissions.AddRange(submissions);
        await _dbContext.SaveChangesAsync();

        // Act
        var result = await _submissionService.GetAllAsync();

        // Assert
        result.Should().HaveCount(3);
        result[0].FileName.Should().Be("newest.pdf");
        result[1].FileName.Should().Be("recent.pdf");
        result[2].FileName.Should().Be("old.pdf");
        
        // Verify all fields are mapped correctly
        result[0].Status.Should().Be("Uploaded");
        result[0].PageCount.Should().Be(20);
        result[0].UploadedBy.Should().Be("user3");
        
        result[1].DetectedLanguage.Should().Be("Spanish");
        result[1].PageCount.Should().Be(15);
    }

    [Fact]
    public async Task GetAllAsync_WhenNoSubmissions_ReturnsEmptyList()
    {
        // Act
        var result = await _submissionService.GetAllAsync();

        // Assert
        result.Should().BeEmpty();
    }

    [Fact]
    public async Task GetAllAsync_IncludesErrorMessages()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            FileName = "failed.pdf",
            Status = SubmissionStatus.Failed,
            ErrorMessage = "Processing failed due to invalid format",
            UploadedAt = DateTime.UtcNow
        };

        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var result = await _submissionService.GetAllAsync();

        // Assert
        result.Should().HaveCount(1);
        result[0].ErrorMessage.Should().Be("Processing failed due to invalid format");
        result[0].Status.Should().Be("Failed");
    }

    [Fact]
    public async Task GetAuditLogsAsync_ReturnsLogsOrderedByTimestamp()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var oldTime = DateTime.UtcNow.AddMinutes(-10);
        var recentTime = DateTime.UtcNow.AddMinutes(-5);
        var newestTime = DateTime.UtcNow;

        var auditLogs = new[]
        {
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = submissionId,
                Action = "ProcessingCompleted",
                Timestamp = newestTime,
                PerformedBy = "system"
            },
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = submissionId,
                Action = "FileUploaded",
                Timestamp = oldTime,
                PerformedBy = "testuser"
            },
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = submissionId,
                Action = "ProcessingStarted",
                Timestamp = recentTime,
                PerformedBy = "system"
            }
        };

        _dbContext.AuditLogs.AddRange(auditLogs);
        await _dbContext.SaveChangesAsync();

        // Act
        var result = await _submissionService.GetAuditLogsAsync(submissionId);

        // Assert
        result.Should().HaveCount(3);
        result[0].Action.Should().Be("FileUploaded");
        result[1].Action.Should().Be("ProcessingStarted");
        result[2].Action.Should().Be("ProcessingCompleted");
    }

    [Fact]
    public async Task GetAuditLogsAsync_FiltersBySubmissionId()
    {
        // Arrange
        var targetSubmissionId = Guid.NewGuid();
        var otherSubmissionId = Guid.NewGuid();

        var auditLogs = new[]
        {
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = targetSubmissionId,
                Action = "Action1",
                Timestamp = DateTime.UtcNow,
                PerformedBy = "user1"
            },
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = otherSubmissionId,
                Action = "Action2",
                Timestamp = DateTime.UtcNow,
                PerformedBy = "user2"
            },
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = targetSubmissionId,
                Action = "Action3",
                Timestamp = DateTime.UtcNow,
                PerformedBy = "user1"
            }
        };

        _dbContext.AuditLogs.AddRange(auditLogs);
        await _dbContext.SaveChangesAsync();

        // Act
        var result = await _submissionService.GetAuditLogsAsync(targetSubmissionId);

        // Assert
        result.Should().HaveCount(2);
        result.All(log => log.SubmissionId == targetSubmissionId).Should().BeTrue();
    }

    [Fact]
    public async Task GetAuditLogsAsync_WhenNoLogs_ReturnsEmptyList()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        var result = await _submissionService.GetAuditLogsAsync(submissionId);

        // Assert
        result.Should().BeEmpty();
    }

    public void Dispose()
    {
        _dbContext.Database.EnsureDeleted();
        _dbContext.Dispose();
    }
}
