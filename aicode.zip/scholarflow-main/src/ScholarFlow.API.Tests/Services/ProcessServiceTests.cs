using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Services;

public class ProcessServiceTests : IDisposable
{
    private readonly Mock<IIngestionAgent> _mockIngestionAgent;
    private readonly Mock<IProcessOrchestrator> _mockProcessOrchestrator;
    private readonly ScholarFlowDbContext _dbContext;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<ProcessService>> _mockLogger;
    private readonly ProcessService _processService;
    private readonly DbContextOptions<ScholarFlowDbContext> _options;

    public ProcessServiceTests()
    {
        // Use InMemoryDatabase for DbContext (required for tracking entities)
        _options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: $"ProcessServiceTestDb_{Guid.NewGuid()}")
            .Options;

        _dbContext = new ScholarFlowDbContext(_options);
        _mockIngestionAgent = new Mock<IIngestionAgent>();
        _mockProcessOrchestrator = new Mock<IProcessOrchestrator>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<ProcessService>>();

        _processService = new ProcessService(
            _mockIngestionAgent.Object,
            _mockProcessOrchestrator.Object,
            _dbContext,
            _mockAuditService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task ProcessSubmissionAsync_WithValidFile_ReturnsSuccessfulResponse()
    {
        // Arrange
        var file = CreateMockFile("test.pdf");
        var uploadedBy = "testuser";
        var submissionId = Guid.NewGuid();

        var ingestionResult = new IngestionResult
        {
            Success = true,
            SubmissionId = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            PageCount = 10
        };

        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            Status = SubmissionStatus.Uploaded,
            UploadedAt = DateTime.UtcNow
        };

        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        var processingResult = new ProcessingResult
        {
            Success = true,
            DetectedLanguage = "English",
            TranslatedText = null,
            IsValid = true,
            ValidationResult = null,
            Summary = "Test summary"
        };

        _mockIngestionAgent
            .Setup(x => x.IngestSubmissionAsync(file, uploadedBy))
            .ReturnsAsync(ingestionResult);

        _mockProcessOrchestrator
            .Setup(x => x.ExecuteWorkflowAsync(It.IsAny<Submission>()))
            .ReturnsAsync(processingResult);

        _mockAuditService
            .Setup(x => x.LogActionAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _processService.ProcessSubmissionAsync(file, uploadedBy);

        // Assert
        result.Should().NotBeNull();
        result.Id.Should().Be(submissionId);
        result.Status.Should().Be("PendingReview");
        result.Stage.Should().Be("HumanReview");
        result.Message.Should().Contain("pending human review");

        _mockIngestionAgent.Verify(x => x.IngestSubmissionAsync(file, uploadedBy), Times.Once);
        _mockProcessOrchestrator.Verify(x => x.ExecuteWorkflowAsync(It.IsAny<Submission>()), Times.Once);
        _mockAuditService.Verify(x => x.LogActionAsync(
            submissionId, "ProcessingStarted", It.IsAny<string>(), uploadedBy, null, ProcessingStage.Preprocess), Times.Once);
        _mockAuditService.Verify(x => x.LogActionAsync(
            submissionId, "ProcessingCompleted", It.IsAny<string>(), uploadedBy, null, ProcessingStage.HumanReview), Times.Once);
    }

    [Fact]
    public async Task ProcessSubmissionAsync_WithNullFile_ThrowsArgumentException()
    {
        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await _processService.ProcessSubmissionAsync(null!, "testuser"));

        _mockIngestionAgent.Verify(x => x.IngestSubmissionAsync(It.IsAny<IFormFile>(), It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task ProcessSubmissionAsync_WhenIngestionFails_ThrowsInvalidOperationException()
    {
        // Arrange
        var file = CreateMockFile("test.pdf");
        var errorMessage = "Invalid PDF format";

        var ingestionResult = new IngestionResult
        {
            Success = false,
            ErrorMessage = errorMessage
        };

        _mockIngestionAgent
            .Setup(x => x.IngestSubmissionAsync(file, It.IsAny<string>()))
            .ReturnsAsync(ingestionResult);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
            await _processService.ProcessSubmissionAsync(file, "testuser"));

        exception.Message.Should().Be(errorMessage);
        _mockProcessOrchestrator.Verify(x => x.ExecuteWorkflowAsync(It.IsAny<Submission>()), Times.Never);
    }

    [Fact]
    public async Task ProcessSubmissionAsync_WhenSubmissionNotFoundAfterIngestion_ThrowsInvalidOperationException()
    {
        // Arrange
        var file = CreateMockFile("test.pdf");
        var nonExistentId = Guid.NewGuid();

        var ingestionResult = new IngestionResult
        {
            Success = true,
            SubmissionId = nonExistentId
        };

        _mockIngestionAgent
            .Setup(x => x.IngestSubmissionAsync(file, It.IsAny<string>()))
            .ReturnsAsync(ingestionResult);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
            await _processService.ProcessSubmissionAsync(file, "testuser"));

        exception.Message.Should().Be("Submission record not found after ingestion");
    }

    [Fact]
    public async Task ProcessSubmissionAsync_WhenProcessingFails_UpdatesStatusAndThrows()
    {
        // Arrange
        var file = CreateMockFile("test.pdf");
        var uploadedBy = "testuser";
        var submissionId = Guid.NewGuid();
        var errorMessage = "Validation failed";

        var ingestionResult = new IngestionResult
        {
            Success = true,
            SubmissionId = submissionId
        };

        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            Status = SubmissionStatus.Uploaded,
            UploadedAt = DateTime.UtcNow
        };

        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        var processingResult = new ProcessingResult
        {
            Success = false,
            ErrorMessage = errorMessage
        };

        _mockIngestionAgent
            .Setup(x => x.IngestSubmissionAsync(file, uploadedBy))
            .ReturnsAsync(ingestionResult);

        _mockProcessOrchestrator
            .Setup(x => x.ExecuteWorkflowAsync(It.IsAny<Submission>()))
            .ReturnsAsync(processingResult);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(async () =>
            await _processService.ProcessSubmissionAsync(file, uploadedBy));

        exception.Message.Should().Be(errorMessage);

        // Verify submission status was updated to Failed
        var updatedSubmission = await _dbContext.Submissions.FindAsync(submissionId);
        updatedSubmission!.Status.Should().Be(SubmissionStatus.Failed);
        updatedSubmission.ErrorMessage.Should().Be(errorMessage);

        _mockAuditService.Verify(x => x.LogActionAsync(
            submissionId, "ProcessingFailed", errorMessage, uploadedBy, null, ProcessingStage.Preprocess), Times.Once);
    }

    [Fact]
    public async Task ProcessSubmissionAsync_UpdatesSubmissionStatusThroughoutPipeline()
    {
        // Arrange
        var file = CreateMockFile("test.pdf");
        var uploadedBy = "testuser";
        var submissionId = Guid.NewGuid();

        var ingestionResult = new IngestionResult
        {
            Success = true,
            SubmissionId = submissionId
        };

        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            Status = SubmissionStatus.Uploaded,
            UploadedAt = DateTime.UtcNow
        };

        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        var processingResult = new ProcessingResult
        {
            Success = true,
            DetectedLanguage = "Spanish",
            TranslatedText = "Translated text",
            IsValid = true,
            Summary = "Generated summary"
        };

        _mockIngestionAgent
            .Setup(x => x.IngestSubmissionAsync(file, uploadedBy))
            .ReturnsAsync(ingestionResult);

        _mockProcessOrchestrator
            .Setup(x => x.ExecuteWorkflowAsync(It.IsAny<Submission>()))
            .Callback<Submission, CancellationToken>((sub, ct) =>
            {
                // Simulate what ValidationStep does - update submission directly
                sub.IsValid = true;
            })
            .ReturnsAsync(processingResult);

        // Act
        await _processService.ProcessSubmissionAsync(file, uploadedBy);

        // Assert
        var updatedSubmission = await _dbContext.Submissions.FindAsync(submissionId);
        updatedSubmission.Should().NotBeNull();
        updatedSubmission!.Status.Should().Be(SubmissionStatus.PendingReview);
        updatedSubmission.CurrentStage.Should().Be(ProcessingStage.HumanReview);
        updatedSubmission.DetectedLanguage.Should().Be("Spanish");
        updatedSubmission.TranslatedText.Should().Be("Translated text");
        updatedSubmission.IsValid.Should().BeTrue();
        updatedSubmission.Summary.Should().Be("Generated summary");
        updatedSubmission.ProcessedAt.Should().NotBeNull();
        updatedSubmission.ProcessedAt!.Value.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));
    }

    public void Dispose()
    {
        _dbContext.Database.EnsureDeleted();
        _dbContext.Dispose();
    }

    private static IFormFile CreateMockFile(string fileName)
    {
        var fileMock = new Mock<IFormFile>();
        fileMock.Setup(f => f.FileName).Returns(fileName);
        fileMock.Setup(f => f.Length).Returns(1024);
        return fileMock.Object;
    }
}
