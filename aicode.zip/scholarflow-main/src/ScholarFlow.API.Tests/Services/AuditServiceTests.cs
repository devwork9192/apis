using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Services;

public class AuditServiceTests : IDisposable
{
    private readonly ScholarFlowDbContext _dbContext;
    private readonly Mock<ILogger<AuditService>> _mockLogger;
    private readonly AuditService _auditService;
    private readonly DbContextOptions<ScholarFlowDbContext> _options;

    public AuditServiceTests()
    {
        _options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: $"AuditTestDb_{Guid.NewGuid()}")
            .Options;

        _dbContext = new ScholarFlowDbContext(_options);
        _mockLogger = new Mock<ILogger<AuditService>>();
        _auditService = new AuditService(_dbContext, _mockLogger.Object);
    }

    [Fact]
    public async Task LogActionAsync_WithAllParameters_CreatesAuditLogSuccessfully()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var action = "FileUploaded";
        var details = "File: test.pdf, Size: 1024 bytes";
        var performedBy = "testuser";
        var agentName = "PreprocessAgent";
        var stage = ProcessingStage.Preprocess;

        // Act
        await _auditService.LogActionAsync(submissionId, action, details, performedBy, agentName, stage);

        // Assert
        var auditLog = await _dbContext.AuditLogs.FirstOrDefaultAsync();
        auditLog.Should().NotBeNull();
        auditLog!.SubmissionId.Should().Be(submissionId);
        auditLog.Action.Should().Be(action);
        auditLog.Details.Should().Be(details);
        auditLog.PerformedBy.Should().Be(performedBy);
        auditLog.AgentName.Should().Be(agentName);
        auditLog.Stage.Should().Be(stage);
        auditLog.Timestamp.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));
    }

    [Fact]
    public async Task LogActionAsync_WithMinimalParameters_UsesDefaultValues()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var action = "TestAction";

        // Act
        await _auditService.LogActionAsync(submissionId, action);

        // Assert
        var auditLog = await _dbContext.AuditLogs.FirstOrDefaultAsync();
        auditLog.Should().NotBeNull();
        auditLog!.SubmissionId.Should().Be(submissionId);
        auditLog.Action.Should().Be(action);
        auditLog.Details.Should().BeNull();
        auditLog.PerformedBy.Should().Be(AppConstants.Users.System);
        auditLog.AgentName.Should().BeNull();
        auditLog.Stage.Should().BeNull();
    }

    [Fact]
    public async Task LogActionAsync_CreatesUniqueGuidForEachLog()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        await _auditService.LogActionAsync(submissionId, "Action1");
        await _auditService.LogActionAsync(submissionId, "Action2");
        await _auditService.LogActionAsync(submissionId, "Action3");

        // Assert
        var logs = await _dbContext.AuditLogs.ToListAsync();
        logs.Should().HaveCount(3);
        logs.Select(l => l.Id).Should().OnlyHaveUniqueItems();
        logs.All(l => l.Id != Guid.Empty).Should().BeTrue();
    }

    [Fact]
    public async Task LogActionAsync_SetsTimestampInUtc()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var beforeCall = DateTime.UtcNow;

        // Act
        await _auditService.LogActionAsync(submissionId, "TestAction");

        // Assert
        var afterCall = DateTime.UtcNow;
        var auditLog = await _dbContext.AuditLogs.FirstOrDefaultAsync();
        auditLog.Should().NotBeNull();
        auditLog!.Timestamp.Kind.Should().Be(DateTimeKind.Utc);
        auditLog.Timestamp.Should().BeOnOrAfter(beforeCall).And.BeOnOrBefore(afterCall);
    }

    [Fact]
    public async Task LogActionAsync_WithMultipleLogs_PreservesAllEntries()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        await _auditService.LogActionAsync(submissionId, "FileUploaded", performedBy: "user1");
        await _auditService.LogActionAsync(submissionId, "PreprocessingStarted", agentName: "PreprocessAgent");
        await _auditService.LogActionAsync(submissionId, "PreprocessingCompleted", agentName: "PreprocessAgent");

        // Assert
        var logs = await _dbContext.AuditLogs
            .Where(l => l.SubmissionId == submissionId)
            .OrderBy(l => l.Timestamp)
            .ToListAsync();

        logs.Should().HaveCount(3);
        logs[0].Action.Should().Be("FileUploaded");
        logs[0].PerformedBy.Should().Be("user1");
        logs[1].Action.Should().Be("PreprocessingStarted");
        logs[1].AgentName.Should().Be("PreprocessAgent");
        logs[2].Action.Should().Be("PreprocessingCompleted");
    }

    [Fact]
    public async Task LogActionAsync_WithDifferentStages_RecordsCorrectStage()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        await _auditService.LogActionAsync(submissionId, "Upload", stage: ProcessingStage.Upload);
        await _auditService.LogActionAsync(submissionId, "Preprocess", stage: ProcessingStage.Preprocess);
        await _auditService.LogActionAsync(submissionId, "Translate", stage: ProcessingStage.Translation);

        // Assert
        var logs = await _dbContext.AuditLogs
            .Where(l => l.SubmissionId == submissionId)
            .OrderBy(l => l.Timestamp)
            .ToListAsync();

        logs.Should().HaveCount(3);
        logs[0].Stage.Should().Be(ProcessingStage.Upload);
        logs[1].Stage.Should().Be(ProcessingStage.Preprocess);
        logs[2].Stage.Should().Be(ProcessingStage.Translation);
    }

    [Fact]
    public async Task LogActionAsync_WithNullDetails_HandlesGracefully()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        await _auditService.LogActionAsync(submissionId, "TestAction", details: null);

        // Assert
        var auditLog = await _dbContext.AuditLogs.FirstOrDefaultAsync();
        auditLog.Should().NotBeNull();
        auditLog!.Details.Should().BeNull();
    }

    [Fact]
    public async Task LogActionAsync_WithLongDetails_StoresFullText()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var longDetails = new string('A', 5000); // 5000 character string

        // Act
        await _auditService.LogActionAsync(submissionId, "TestAction", details: longDetails);

        // Assert
        var auditLog = await _dbContext.AuditLogs.FirstOrDefaultAsync();
        auditLog.Should().NotBeNull();
        auditLog!.Details.Should().Be(longDetails);
        auditLog.Details!.Length.Should().Be(5000);
    }

    [Fact]
    public async Task LogActionAsync_LogsInformationMessage()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var action = "TestAction";

        // Act
        await _auditService.LogActionAsync(submissionId, action);

        // Assert - Verify that LogInformation was called
        _mockLogger.Verify(
            x => x.Log(
                LogLevel.Information,
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => v.ToString()!.Contains(action) && v.ToString()!.Contains(submissionId.ToString())),
                null,
                It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
            Times.Once);
    }

    [Fact]
    public async Task LogActionAsync_SupportsMultipleSubmissions()
    {
        // Arrange
        var submission1 = Guid.NewGuid();
        var submission2 = Guid.NewGuid();
        var submission3 = Guid.NewGuid();

        // Act
        await _auditService.LogActionAsync(submission1, "Action1");
        await _auditService.LogActionAsync(submission2, "Action2");
        await _auditService.LogActionAsync(submission3, "Action3");
        await _auditService.LogActionAsync(submission1, "Action1B");

        // Assert
        var logs1 = await _dbContext.AuditLogs.Where(l => l.SubmissionId == submission1).ToListAsync();
        var logs2 = await _dbContext.AuditLogs.Where(l => l.SubmissionId == submission2).ToListAsync();
        var logs3 = await _dbContext.AuditLogs.Where(l => l.SubmissionId == submission3).ToListAsync();

        logs1.Should().HaveCount(2);
        logs2.Should().HaveCount(1);
        logs3.Should().HaveCount(1);
    }

    public void Dispose()
    {
        _dbContext?.Dispose();
    }
}
