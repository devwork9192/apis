using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Common;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Services;

public class PdfServiceTests
{
    private readonly Mock<ILogger<PdfService>> _mockLogger;
    private readonly PdfService _pdfService;

    public PdfServiceTests()
    {
        _mockLogger = new Mock<ILogger<PdfService>>();
        _pdfService = new PdfService(_mockLogger.Object);
    }

    #region ValidateFile Tests

    [Fact]
    public async Task ValidateFile_WithValidPdf_ReturnsTrue()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", AppConstants.FileConstraints.MaxFileSizeBytes - 1000, "application/pdf");

        // Act
        var result = _pdfService.ValidateFile(file, out var errorMessage);

        // Assert
        result.Should().BeTrue();
        errorMessage.Should().BeEmpty();
    }

    [Fact]
    public async Task ValidateFile_WithNullFile_ReturnsFalse()
    {
        // Act
        var result = _pdfService.ValidateFile(null!, out var errorMessage);

        // Assert
        result.Should().BeFalse();
        errorMessage.Should().Be(AppConstants.Messages.FileIsEmptyOrNull);
    }

    [Fact]
    public async Task ValidateFile_WithEmptyFile_ReturnsFalse()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", 0, "application/pdf");

        // Act
        var result = _pdfService.ValidateFile(file, out var errorMessage);

        // Assert
        result.Should().BeFalse();
        errorMessage.Should().Be(AppConstants.Messages.FileIsEmptyOrNull);
    }

    [Fact]
    public async Task ValidateFile_WithFileTooLarge_ReturnsFalse()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", AppConstants.FileConstraints.MaxFileSizeBytes + 1, "application/pdf");

        // Act
        var result = _pdfService.ValidateFile(file, out var errorMessage);

        // Assert
        result.Should().BeFalse();
        errorMessage.Should().Contain($"{AppConstants.FileConstraints.MaxFileSizeMB}MB");
    }

    [Fact]
    public async Task ValidateFile_WithNonPdfExtension_ReturnsFalse()
    {
        // Arrange
        var file = CreateMockFile("test.txt", 1024, "text/plain");

        // Act
        var result = _pdfService.ValidateFile(file, out var errorMessage);

        // Assert
        result.Should().BeFalse();
        errorMessage.Should().Be(AppConstants.Messages.OnlyPdfFilesSupported);
    }

    [Fact]
    public async Task ValidateFile_WithWrongContentType_StillPassesIfExtensionIsCorrect()
    {
        // Arrange
        // Note: The service only checks extension, not content type
        var file = CreateMockFile("test.pdf", 1024, "text/plain");

        // Act
        var result = _pdfService.ValidateFile(file, out var errorMessage);

        // Assert
        result.Should().BeTrue(); // Passes because extension is .pdf
        errorMessage.Should().BeEmpty();
    }

    [Theory]
    [InlineData("Document.PDF")]
    [InlineData("report.Pdf")]
    [InlineData("file.pDf")]
    public async Task ValidateFile_WithVariousPdfExtensions_ReturnsTrue(string fileName)
    {
        // Arrange
        var file = CreateMockFile(fileName, 1024, "application/pdf");

        // Act
        var result = _pdfService.ValidateFile(file, out var errorMessage);

        // Assert
        result.Should().BeTrue();
        errorMessage.Should().BeEmpty();
    }

    [Fact]
    public async Task ValidateFile_WithExactMaxSize_ReturnsTrue()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", AppConstants.FileConstraints.MaxFileSizeBytes, "application/pdf");

        // Act
        var result = _pdfService.ValidateFile(file, out var errorMessage);

        // Assert
        result.Should().BeTrue();
        errorMessage.Should().BeEmpty();
    }

    #endregion

    #region Helper Methods

    private static IFormFile CreateMockFile(string fileName, long length, string contentType)
    {
        var fileMock = new Mock<IFormFile>();
        fileMock.Setup(f => f.FileName).Returns(fileName);
        fileMock.Setup(f => f.Length).Returns(length);
        fileMock.Setup(f => f.ContentType).Returns(contentType);
        return fileMock.Object;
    }

    #endregion
}
