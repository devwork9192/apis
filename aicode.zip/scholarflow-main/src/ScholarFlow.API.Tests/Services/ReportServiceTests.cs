using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using ScholarFlow.API.Services;
using ScholarFlow.API.Database;
using ScholarFlow.API.Models;
using Microsoft.EntityFrameworkCore;

namespace ScholarFlow.API.Tests.Services;

public class ReportServiceTests : IDisposable
{
    private readonly ScholarFlowDbContext _dbContext;
    private readonly Mock<ILogger<ReportService>> _mockLogger;
    private readonly ReportService _service;

    public ReportServiceTests()
    {
        // Setup in-memory database
        var options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _dbContext = new ScholarFlowDbContext(options);

        _mockLogger = new Mock<ILogger<ReportService>>();
        
        _service = new ReportService(
            _dbContext,
            _mockLogger.Object);
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithCompleteSubmission_ReturnsReport()
    {
        // Arrange
        var submission = CreateTestSubmission();
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.SubmissionId.Should().Be(submission.Id);
        report.MetadataValidation.Should().NotBeNull();
        report.ContentValidation.Should().NotBeNull();
        report.QualityChecks.Should().NotBeNull();
        report.PlagiarismCheck.Should().NotBeNull();
        report.ToxicityCheck.Should().NotBeNull();
        report.Summary.Should().NotBeNullOrEmpty();
        report.Recommendations.Should().NotBeEmpty();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithNonExistentSubmission_ReturnsNull()
    {
        // Arrange
        var nonExistentId = Guid.NewGuid();

        // Act
        var report = await _service.GenerateValidationReportAsync(nonExistentId);

        // Assert
        report.Should().BeNull();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithCompleteMetadata_PassesMetadataValidation()
    {
        // Arrange
        var submission = CreateTestSubmission();
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.MetadataValidation.HasTitle.Should().BeTrue();
        report.MetadataValidation.HasAuthors.Should().BeTrue();
        report.MetadataValidation.HasAbstract.Should().BeTrue();
        report.MetadataValidation.Status.Should().Be("Pass");
        report.MetadataValidation.Issues.Should().BeEmpty();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithMissingMetadata_FailsMetadataValidation()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.Title = null;
        submission.Authors = null;
        submission.Abstract = null;
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.MetadataValidation.HasTitle.Should().BeFalse();
        report.MetadataValidation.HasAuthors.Should().BeFalse();
        report.MetadataValidation.HasAbstract.Should().BeFalse();
        report.MetadataValidation.Status.Should().Be("Fail");
        report.MetadataValidation.Issues.Should().HaveCount(3);
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithValidPageCount_PassesContentValidation()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PageCount = 15; // Within 8-25 range
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.ContentValidation.PageCount.Should().Be(15);
        report.ContentValidation.PageCountValid.Should().BeTrue();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithInvalidPageCount_FailsContentValidation()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PageCount = 5; // Below minimum (8)
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.ContentValidation.PageCount.Should().Be(5);
        report.ContentValidation.PageCountValid.Should().BeFalse();
        report.ContentValidation.Issues.Should().Contain(i => i.Contains("Page count"));
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithHighPlagiarismScore_FailsPlagiarismCheck()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.92; // Above 85% threshold
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.PlagiarismCheck.Checked.Should().BeTrue();
        report.PlagiarismCheck.Score.Should().Be(0.92);
        report.PlagiarismCheck.IsAboveThreshold.Should().BeTrue();
        report.PlagiarismCheck.Status.Should().Be("Fail");
        report.PlagiarismCheck.Issues.Should().NotBeEmpty();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithLowPlagiarismScore_PassesPlagiarismCheck()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.35; // Well below threshold
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.PlagiarismCheck.Checked.Should().BeTrue();
        report.PlagiarismCheck.Score.Should().Be(0.35);
        report.PlagiarismCheck.IsAboveThreshold.Should().BeFalse();
        report.PlagiarismCheck.Status.Should().Be("Pass");
        report.PlagiarismCheck.Issues.Should().BeEmpty();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithModeratePlagiarismScore_ReturnsWarning()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.75; // Between 70% and 85%
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.PlagiarismCheck.Checked.Should().BeTrue();
        report.PlagiarismCheck.Score.Should().Be(0.75);
        report.PlagiarismCheck.IsAboveThreshold.Should().BeFalse();
        report.PlagiarismCheck.Status.Should().Be("Warning");
        report.PlagiarismCheck.Issues.Should().NotBeEmpty();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithoutPlagiarismCheck_MarksNotChecked()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = null; // Not checked yet
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.PlagiarismCheck.Checked.Should().BeFalse();
        report.PlagiarismCheck.Status.Should().Be("Not Checked");
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithHighToxicityScore_FailsToxicityCheck()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.ToxicityScore = 0.85; // Above 70% threshold
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.ToxicityCheck.Checked.Should().BeTrue();
        report.ToxicityCheck.Score.Should().Be(0.85);
        report.ToxicityCheck.IsAboveThreshold.Should().BeTrue();
        report.ToxicityCheck.Status.Should().Be("Fail");
        report.ToxicityCheck.Issues.Should().NotBeEmpty();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithLowToxicityScore_PassesToxicityCheck()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.ToxicityScore = 0.15; // Well below threshold
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.ToxicityCheck.Checked.Should().BeTrue();
        report.ToxicityCheck.Score.Should().Be(0.15);
        report.ToxicityCheck.IsAboveThreshold.Should().BeFalse();
        report.ToxicityCheck.Status.Should().Be("Pass");
        report.ToxicityCheck.Issues.Should().BeEmpty();
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithOverallPass_ReturnsPassStatus()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.2;
        submission.ToxicityScore = 0.1;
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.OverallStatus.Should().Be("Pass");
        report.Summary.Should().Contain("passed");
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithFailures_ReturnsFailStatus()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.95; // High plagiarism
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.OverallStatus.Should().Be("Fail");
        report.Summary.Should().Contain("failed");
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithWarnings_ReturnsReviewStatus()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.75; // Moderate similarity (warning)
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.OverallStatus.Should().Be("Review");
        report.Summary.Should().Contain("requires human review");
    }

    [Fact]
    public async Task GenerateValidationReportAsync_GeneratesAppropriateRecommendations()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.Title = null; // Missing metadata
        submission.PageCount = 30; // Over maximum
        submission.PlagiarismScore = 0.9; // High plagiarism
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.Recommendations.Should().NotBeEmpty();
        report.Recommendations.Should().Contain(r => r.Contains("metadata"));
        report.Recommendations.Should().Contain(r => r.Contains("page count"));
        report.Recommendations.Should().Contain(r => r.Contains("similarity") || r.Contains("plagiarism"));
    }

    [Fact]
    public async Task GenerateValidationReportAsync_WithPassingSubmission_RecommendsProceed()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.2;
        submission.ToxicityScore = 0.1;
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.Recommendations.Should().Contain(r => r.Contains("Proceed") || r.Contains("meets"));
    }

    [Fact]
    public async Task GenerateValidationReportHtmlAsync_WithValidSubmission_ReturnsHtml()
    {
        // Arrange
        var submission = CreateTestSubmission();
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var html = await _service.GenerateValidationReportHtmlAsync(submission.Id);

        // Assert
        html.Should().NotBeNullOrEmpty();
        html.Should().Contain("<!DOCTYPE html>");
        html.Should().Contain("<html");
        html.Should().Contain("Validation Report");
        html.Should().Contain(submission.Id.ToString());
    }

    [Fact]
    public async Task GenerateValidationReportHtmlAsync_WithNonExistentSubmission_ReturnsNull()
    {
        // Arrange
        var nonExistentId = Guid.NewGuid();

        // Act
        var html = await _service.GenerateValidationReportHtmlAsync(nonExistentId);

        // Assert
        html.Should().BeNull();
    }

    [Fact]
    public async Task GenerateValidationReportHtmlAsync_IncludesAllSections()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.PlagiarismScore = 0.75;
        submission.ToxicityScore = 0.6;
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var html = await _service.GenerateValidationReportHtmlAsync(submission.Id);

        // Assert
        html.Should().NotBeNullOrEmpty();
        html.Should().Contain("Metadata Validation");
        html.Should().Contain("Content Validation");
        html.Should().Contain("Quality Checks");
        html.Should().Contain("Plagiarism Check");
        html.Should().Contain("Toxicity Check");
        html.Should().Contain("Recommendations");
        html.Should().Contain("Summary");
    }

    [Fact]
    public async Task GenerateValidationReportAsync_CalculatesWordCount()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.TranslatedText = "This is a test document with exactly ten words for counting.";
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.QualityChecks.WordCount.Should().BeGreaterThan(0);
    }

    [Fact]
    public async Task GenerateValidationReportAsync_DetectsFoundSections()
    {
        // Arrange
        var submission = CreateTestSubmission();
        submission.TranslatedText = "Introduction section describes the research. Methodology explains the approach. Results show findings. Conclusion summarizes everything.";
        _dbContext.Submissions.Add(submission);
        await _dbContext.SaveChangesAsync();

        // Act
        var report = await _service.GenerateValidationReportAsync(submission.Id);

        // Assert
        report.Should().NotBeNull();
        report!.ContentValidation.FoundSections.Should().NotBeEmpty();
        report.ContentValidation.FoundSections.Should().Contain("introduction");
        report.ContentValidation.FoundSections.Should().Contain("methodology");
        report.ContentValidation.FoundSections.Should().Contain("results");
        report.ContentValidation.FoundSections.Should().Contain("conclusion");
    }

    private Submission CreateTestSubmission()
    {
        return new Submission
        {
            Id = Guid.NewGuid(),
            UploadedBy = "test-user",
            FileName = "test.pdf",
            Title = "Test Research Paper on Machine Learning",
            Authors = "John Doe, Jane Smith",
            Abstract = "This is a comprehensive abstract describing the research paper. It contains enough detail to demonstrate completeness and quality of the submission.",
            RawText = "Introduction section describes the research problem. Methodology explains the approach taken. Results show the findings from experiments. Conclusion summarizes the research outcomes.",
            TranslatedText = "Introduction section describes the research problem. Methodology explains the approach taken. Results show the findings from experiments. Conclusion summarizes the research outcomes.",
            PageCount = 15,
            Status = SubmissionStatus.Summarized,
            IsScanned = false,
            RequiresHumanReview = false,
            UploadedAt = DateTime.UtcNow
        };
    }

    public void Dispose()
    {
        _dbContext.Database.EnsureDeleted();
        _dbContext.Dispose();
    }
}
