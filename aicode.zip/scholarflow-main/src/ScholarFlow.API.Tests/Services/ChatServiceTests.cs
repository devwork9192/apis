using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using ScholarFlow.API.Services;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Chat;
using ScholarFlow.API.Models;
using Microsoft.EntityFrameworkCore;

namespace ScholarFlow.API.Tests.Services;

public class ChatServiceTests : IDisposable
{
    private readonly Mock<IQAAgent> _mockQAAgent;
    private readonly ScholarFlowDbContext _context;
    private readonly Mock<ILogger<ChatService>> _mockLogger;
    private readonly ChatService _service;

    public ChatServiceTests()
    {
        var options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _context = new ScholarFlowDbContext(options);

        _mockQAAgent = new Mock<IQAAgent>();
        _mockLogger = new Mock<ILogger<ChatService>>();

        _service = new ChatService(_mockQAAgent.Object, _context, _mockLogger.Object);
    }

    public void Dispose()
    {
        _context.Database.EnsureDeleted();
        _context.Dispose();
    }

    [Fact]
    public async Task AskQuestionAsync_ValidRequest_SavesChatHistory()
    {
        // Arrange
        var request = new ChatRequest
        {
            Query = "What is neural network?",
            Language = "en",
            TopK = 5
        };

        var response = new ChatResponse
        {
            Answer = "A neural network is...",
            DetectedLanguage = "en",
            Sources = new List<SourceReference>
            {
                new SourceReference { SubmissionId = Guid.NewGuid(), Title = "Paper 1" }
            },
            CitedSubmissions = new List<Guid> { Guid.NewGuid() }
        };

        _mockQAAgent.Setup(x => x.AnswerQuestionAsync(
            request.Query, request.Language, request.TopK, request.SubmissionId))
            .ReturnsAsync(response);

        // Act
        var result = await _service.AskQuestionAsync(request);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(response.Answer, result.Answer);
        
        // Verify chat messages were saved
        var messages = await _context.ChatMessages.ToListAsync();
        Assert.Equal(2, messages.Count); // User message + Assistant message
        
        var userMsg = messages.First(m => m.Role == "user");
        Assert.Equal(request.Query, userMsg.Content);
        Assert.Equal("en", userMsg.Language);
        
        var assistantMsg = messages.First(m => m.Role == "assistant");
        Assert.Equal(response.Answer, assistantMsg.Content);
        Assert.NotEmpty(assistantMsg.CitedSubmissions);
    }

    [Fact]
    public async Task AskQuestionAsync_WithSubmissionId_AssociatesMessagesWithSubmission()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new ChatRequest
        {
            Query = "Explain this paper",
            SubmissionId = submissionId
        };

        var response = new ChatResponse
        {
            Answer = "This paper discusses...",
            DetectedLanguage = "en",
            Sources = new List<SourceReference>(),
            CitedSubmissions = new List<Guid> { submissionId }
        };

        _mockQAAgent.Setup(x => x.AnswerQuestionAsync(
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), submissionId))
            .ReturnsAsync(response);

        // Act
        var result = await _service.AskQuestionAsync(request);

        // Assert
        var messages = await _context.ChatMessages.Where(m => m.SubmissionId == submissionId).ToListAsync();
        Assert.Equal(2, messages.Count);
        Assert.All(messages, m => Assert.Equal(submissionId, m.SubmissionId));
    }

    [Fact]
    public async Task GetChatHistoryAsync_ReturnsMessagesInOrder()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var messages = new List<ChatMessage>
        {
            new ChatMessage
            {
                SubmissionId = submissionId,
                Role = "user",
                Content = "First question",
                Language = "en",
                Timestamp = DateTime.UtcNow.AddMinutes(-10)
            },
            new ChatMessage
            {
                SubmissionId = submissionId,
                Role = "assistant",
                Content = "First answer",
                Language = "en",
                Timestamp = DateTime.UtcNow.AddMinutes(-9)
            },
            new ChatMessage
            {
                SubmissionId = submissionId,
                Role = "user",
                Content = "Second question",
                Language = "en",
                Timestamp = DateTime.UtcNow.AddMinutes(-5)
            },
            new ChatMessage
            {
                SubmissionId = submissionId,
                Role = "assistant",
                Content = "Second answer",
                Language = "en",
                Timestamp = DateTime.UtcNow.AddMinutes(-4)
            }
        };

        await _context.ChatMessages.AddRangeAsync(messages);
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetChatHistoryAsync(submissionId);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(submissionId, result.SubmissionId);
        Assert.Equal(4, result.Messages.Count);
        Assert.Equal("First question", result.Messages[0].Content);
        Assert.Equal("user", result.Messages[0].Role);
        Assert.Equal("First answer", result.Messages[1].Content);
        Assert.Equal("assistant", result.Messages[1].Role);
    }

    [Fact]
    public async Task GetChatHistoryAsync_EmptyHistory_ReturnsEmptyList()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act
        var result = await _service.GetChatHistoryAsync(submissionId);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(submissionId, result.SubmissionId);
        Assert.Empty(result.Messages);
    }

    [Fact]
    public async Task GetChatHistoryAsync_WithCitedSubmissions_ParsesCorrectly()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var citedId1 = Guid.NewGuid();
        var citedId2 = Guid.NewGuid();
        
        var message = new ChatMessage
        {
            SubmissionId = submissionId,
            Role = "assistant",
            Content = "Answer with citations",
            Language = "en",
            CitedSubmissions = $"{citedId1},{citedId2}",
            Timestamp = DateTime.UtcNow
        };

        await _context.ChatMessages.AddAsync(message);
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetChatHistoryAsync(submissionId);

        // Assert
        Assert.Single(result.Messages);
        Assert.Equal(2, result.Messages[0].CitedSubmissions.Count);
        Assert.Contains(citedId1, result.Messages[0].CitedSubmissions);
        Assert.Contains(citedId2, result.Messages[0].CitedSubmissions);
    }

    [Fact]
    public async Task DeleteChatHistoryAsync_RemovesAllMessagesForSubmission()
    {
        // Arrange
        var submissionId1 = Guid.NewGuid();
        var submissionId2 = Guid.NewGuid();

        var messages = new List<ChatMessage>
        {
            new ChatMessage { SubmissionId = submissionId1, Role = "user", Content = "Q1", Timestamp = DateTime.UtcNow },
            new ChatMessage { SubmissionId = submissionId1, Role = "assistant", Content = "A1", Timestamp = DateTime.UtcNow },
            new ChatMessage { SubmissionId = submissionId2, Role = "user", Content = "Q2", Timestamp = DateTime.UtcNow },
            new ChatMessage { SubmissionId = submissionId2, Role = "assistant", Content = "A2", Timestamp = DateTime.UtcNow }
        };

        await _context.ChatMessages.AddRangeAsync(messages);
        await _context.SaveChangesAsync();

        // Act
        await _service.DeleteChatHistoryAsync(submissionId1);

        // Assert
        var remainingMessages = await _context.ChatMessages.ToListAsync();
        Assert.Equal(2, remainingMessages.Count);
        Assert.All(remainingMessages, m => Assert.Equal(submissionId2, m.SubmissionId));
    }

    [Fact]
    public async Task DeleteChatHistoryAsync_NonExistentSubmission_DoesNotThrow()
    {
        // Arrange
        var submissionId = Guid.NewGuid();

        // Act & Assert
        await _service.DeleteChatHistoryAsync(submissionId); // Should not throw
    }

    [Fact]
    public async Task AskQuestionAsync_WithMultilingualQuery_SavesCorrectLanguage()
    {
        // Arrange
        var request = new ChatRequest
        {
            Query = "¿Qué es la inteligencia artificial?",
            Language = "es"
        };

        var response = new ChatResponse
        {
            Answer = "La inteligencia artificial es...",
            DetectedLanguage = "es",
            Sources = new List<SourceReference>(),
            CitedSubmissions = new List<Guid>()
        };

        _mockQAAgent.Setup(x => x.AnswerQuestionAsync(
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<Guid?>()))
            .ReturnsAsync(response);

        // Act
        var result = await _service.AskQuestionAsync(request);

        // Assert
        var messages = await _context.ChatMessages.ToListAsync();
        Assert.All(messages, m => Assert.Equal("es", m.Language));
    }

    [Fact]
    public async Task GetChatHistoryAsync_FiltersOnlySpecifiedSubmission()
    {
        // Arrange
        var submissionId1 = Guid.NewGuid();
        var submissionId2 = Guid.NewGuid();

        await _context.ChatMessages.AddRangeAsync(new List<ChatMessage>
        {
            new ChatMessage { SubmissionId = submissionId1, Role = "user", Content = "Q1", Timestamp = DateTime.UtcNow },
            new ChatMessage { SubmissionId = submissionId1, Role = "assistant", Content = "A1", Timestamp = DateTime.UtcNow },
            new ChatMessage { SubmissionId = submissionId2, Role = "user", Content = "Q2", Timestamp = DateTime.UtcNow },
            new ChatMessage { SubmissionId = submissionId2, Role = "assistant", Content = "A2", Timestamp = DateTime.UtcNow }
        });
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetChatHistoryAsync(submissionId1);

        // Assert
        Assert.Equal(2, result.Messages.Count);
        Assert.All(result.Messages, m => Assert.True(
            m.Content == "Q1" || m.Content == "A1"));
    }
}
