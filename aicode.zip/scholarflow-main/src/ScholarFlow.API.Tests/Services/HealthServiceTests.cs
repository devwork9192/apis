using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using Moq;
using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Health;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Services;

/// <summary>
/// Tests for HealthService
/// Note: These are integration-style tests because Kernel is sealed and cannot be mocked with Moq.
/// A real Kernel instance is required for testing.
/// </summary>
public class HealthServiceTests : IDisposable
{
    private readonly ScholarFlowDbContext _dbContext;
    private readonly ILogger<HealthService> _logger;
    private readonly DbContextOptions<ScholarFlowDbContext> _options;

    public HealthServiceTests()
    {
        // Create in-memory database for testing
        _options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: $"TestDb_{Guid.NewGuid()}")
            .Options;

        _dbContext = new ScholarFlowDbContext(_options);
        _logger = Mock.Of<ILogger<HealthService>>();
    }

    [Fact]
    public async Task CheckHealthAsync_WithHealthyDatabase_ReturnsHealthyDatabaseStatus()
    {
        // Arrange
        var kernel = CreateTestKernel();
        var healthService = new HealthService(_dbContext, kernel, _logger);

        // Act
        var result = await healthService.CheckHealthAsync();

        // Assert
        result.Should().NotBeNull();
        result.Status.Should().NotBeNullOrEmpty();
        result.Components.Should().ContainKey(AppConstants.HealthComponents.Database);
        result.Components[AppConstants.HealthComponents.Database].Status.Should().Be(AppConstants.Status.Healthy);
        result.Components[AppConstants.HealthComponents.Database].ResponseTimeMs.Should().BeGreaterThanOrEqualTo(0);
    }

    [Fact]
    public async Task CheckHealthAsync_WithSeededData_ReportsSubmissionCount()
    {
        // Arrange
        var kernel = CreateTestKernel();
        
        // Seed some test data
        _dbContext.Submissions.AddRange(
            new Submission { Id = Guid.NewGuid(), FileName = "test1.pdf", Status = SubmissionStatus.Uploaded, UploadedAt = DateTime.UtcNow },
            new Submission { Id = Guid.NewGuid(), FileName = "test2.pdf", Status = SubmissionStatus.Uploaded, UploadedAt = DateTime.UtcNow }
        );
        await _dbContext.SaveChangesAsync();

        var healthService = new HealthService(_dbContext, kernel, _logger);

        // Act
        var result = await healthService.CheckHealthAsync();

        // Assert
        result.Components[AppConstants.HealthComponents.Database].Status.Should().Be(AppConstants.Status.Healthy);
        result.Components[AppConstants.HealthComponents.Database].Message.Should().Contain("2");
    }

    [Fact]
    public async Task CheckHealthAsync_IncludesAIServiceCheck()
    {
        // Arrange
        var kernel = CreateTestKernel();
        var healthService = new HealthService(_dbContext, kernel, _logger);

        // Act
        var result = await healthService.CheckHealthAsync();

        // Assert
        result.Components.Should().ContainKey(AppConstants.HealthComponents.AIService);
        result.Components[AppConstants.HealthComponents.AIService].ResponseTimeMs.Should().HaveValue();
    }

    [Fact]
    public async Task CheckHealthAsync_ReturnsTimestampInUtc()
    {
        // Arrange
        var kernel = CreateTestKernel();
        var healthService = new HealthService(_dbContext, kernel, _logger);
        var beforeCall = DateTime.UtcNow;

        // Act
        var result = await healthService.CheckHealthAsync();

        // Assert
        var afterCall = DateTime.UtcNow;
        result.Timestamp.Should().BeOnOrAfter(beforeCall).And.BeOnOrBefore(afterCall);
        result.Timestamp.Kind.Should().Be(DateTimeKind.Utc);
    }

    [Fact]
    public async Task CheckHealthAsync_TracksResponseTimes()
    {
        // Arrange
        var kernel = CreateTestKernel();
        var healthService = new HealthService(_dbContext, kernel, _logger);

        // Act
        var result = await healthService.CheckHealthAsync();

        // Assert
        result.Components[AppConstants.HealthComponents.Database].ResponseTimeMs.Should().HaveValue();
        result.Components[AppConstants.HealthComponents.Database].ResponseTimeMs.Should().BeGreaterThanOrEqualTo(0);
        
        if (result.Components.ContainsKey(AppConstants.HealthComponents.AIService))
        {
            result.Components[AppConstants.HealthComponents.AIService].ResponseTimeMs.Should().HaveValue();
            result.Components[AppConstants.HealthComponents.AIService].ResponseTimeMs.Should().BeGreaterThanOrEqualTo(0);
        }
    }

    [Fact]
    public async Task CheckHealthAsync_DeterminesOverallStatusCorrectly()
    {
        // Arrange
        var kernel = CreateTestKernel();
        var healthService = new HealthService(_dbContext, kernel, _logger);

        // Act
        var result = await healthService.CheckHealthAsync();

        // Assert
        result.Status.Should().BeOneOf(AppConstants.Status.Healthy, AppConstants.Status.Unhealthy);
        
        // If all components are healthy, overall should be healthy
        if (result.Components.Values.All(c => c.Status == AppConstants.Status.Healthy))
        {
            result.Status.Should().Be(AppConstants.Status.Healthy);
        }
        else
        {
            result.Status.Should().Be(AppConstants.Status.Unhealthy);
        }
    }

    #region Helper Methods

    /// <summary>
    /// Creates a test Kernel instance for testing.
    /// Note: This creates a real Kernel with Azure OpenAI configuration from environment/test settings.
    /// If Azure OpenAI is not configured, the AI health check will fail (which is expected behavior).
    /// </summary>
    private Kernel CreateTestKernel()
    {
        var services = new ServiceCollection();
        
        // Add configuration
        var configuration = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["AzureOpenAI:Endpoint"] = "https://test.openai.azure.com",
                ["AzureOpenAI:ApiKey"] = "test-key-for-unit-tests",
                ["AzureOpenAI:ChatDeploymentName"] = "gpt-35-turbo"
            })
            .Build();

        services.AddSingleton<IConfiguration>(configuration);

        // Build a basic kernel without Azure OpenAI (to avoid real API calls in tests)
        var builder = Kernel.CreateBuilder();
        
        // Note: Not adding Azure OpenAI here to avoid real API calls during tests
        // This means AI health checks will fail, but that's acceptable for unit tests
        
        return builder.Build();
    }

    #endregion

    public void Dispose()
    {
        _dbContext?.Dispose();
    }
}
