using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.HumanReview;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;
using System.Text.Json;

namespace ScholarFlow.API.Tests.Services;

public class HumanReviewServiceTests : IDisposable
{
    private readonly ScholarFlowDbContext _context;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<HumanReviewService>> _mockLogger;
    private readonly HumanReviewService _service;

    public HumanReviewServiceTests()
    {
        var options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _context = new ScholarFlowDbContext(options);
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<HumanReviewService>>();
        _service = new HumanReviewService(_context, _mockAuditService.Object, _mockLogger.Object);
    }

    public void Dispose()
    {
        _context.Database.EnsureDeleted();
        _context.Dispose();
    }

    [Fact]
    public async Task GetPendingReviewsAsync_ReturnsPendingSubmissions()
    {
        // Arrange
        var submission1 = new Submission
        {
            Id = Guid.NewGuid(),
            FileName = "test1.pdf",
            FilePath = "/uploads/test1.pdf",
            Status = SubmissionStatus.PendingReview,
            RequiresHumanReview = true,
            PlagiarismScore = 0.65,
            IsValid = false
        };
        var submission2 = new Submission
        {
            Id = Guid.NewGuid(),
            FileName = "test2.pdf",
            FilePath = "/uploads/test2.pdf",
            Status = SubmissionStatus.Summarized,  // Different status but still requires review
            RequiresHumanReview = true,
            ToxicityScore = 0.50
        };
        var submission3 = new Submission
        {
            Id = Guid.NewGuid(),
            FileName = "approved.pdf",
            FilePath = "/uploads/approved.pdf",
            Status = SubmissionStatus.Approved,
            RequiresHumanReview = false  // Already approved, should not be included
        };
        var submission4 = new Submission
        {
            Id = Guid.NewGuid(),
            FileName = "rejected.pdf",
            FilePath = "/uploads/rejected.pdf",
            Status = SubmissionStatus.Rejected,
            RequiresHumanReview = true  // Even if true, rejected should not be included
        };

        _context.Submissions.AddRange(submission1, submission2, submission3, submission4);
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetPendingReviewsAsync();

        // Assert
        result.Should().HaveCount(2);
        result.Should().Contain(r => r.SubmissionId == submission1.Id);
        result.Should().Contain(r => r.SubmissionId == submission2.Id);
        result.Should().NotContain(r => r.SubmissionId == submission3.Id);
        result.Should().NotContain(r => r.SubmissionId == submission4.Id);
    }

    [Fact]
    public async Task GetReviewSummaryAsync_WithValidId_ReturnsSummary()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            Status = SubmissionStatus.PendingReview,
            RequiresHumanReview = true,
            Title = "Test Paper",
            Authors = "John Doe",
            PlagiarismScore = 0.65,
            ToxicityScore = 0.45,
            ValidationErrors = JsonSerializer.Serialize(new List<string> { "Error 1", "Error 2" }),
            ValidationWarnings = JsonSerializer.Serialize(new List<string> { "Warning 1" })
        };
        _context.Submissions.Add(submission);
        await _context.SaveChangesAsync();

        // Act
        var result = await _service.GetReviewSummaryAsync(submissionId);

        // Assert
        result.Should().NotBeNull();
        result!.SubmissionId.Should().Be(submissionId);
        result.FileName.Should().Be("test.pdf");
        result.Title.Should().Be("Test Paper");
        result.PlagiarismScore.Should().Be(0.65);
        result.ToxicityScore.Should().Be(0.45);
        result.Errors.Should().HaveCount(2);
        result.Warnings.Should().HaveCount(1);
    }

    [Fact]
    public async Task GetReviewSummaryAsync_WithInvalidId_ReturnsNull()
    {
        // Act
        var result = await _service.GetReviewSummaryAsync(Guid.NewGuid());

        // Assert
        result.Should().BeNull();
    }

    [Fact]
    public async Task ApproveSubmissionAsync_UpdatesStatusAndLogsAudit()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            Status = SubmissionStatus.PendingReview,
            RequiresHumanReview = true
        };
        _context.Submissions.Add(submission);
        await _context.SaveChangesAsync();

        var request = new ApproveRequest
        {
            ReviewedBy = "admin@test.com",
            Notes = "Looks good"
        };

        // Act
        var result = await _service.ApproveSubmissionAsync(submissionId, request);

        // Assert
        result.Should().NotBeNull();
        result!.Status.Should().Be(SubmissionStatus.Approved);
        result.ReviewedBy.Should().Be("admin@test.com");

        var updatedSubmission = await _context.Submissions.FindAsync(submissionId);
        updatedSubmission!.Status.Should().Be(SubmissionStatus.Approved);
        updatedSubmission.RequiresHumanReview.Should().BeFalse();
        updatedSubmission.ReviewedBy.Should().Be("admin@test.com");
        updatedSubmission.ReviewedAt.Should().NotBeNull();
        updatedSubmission.RejectionReason.Should().BeNull();

        _mockAuditService.Verify(
            a => a.LogActionAsync(
                submissionId,
                "Approved",
                It.IsAny<string>(),
                "admin@test.com",
                "HumanReview",
                ProcessingStage.HumanReview),
            Times.Once);
    }

    [Fact]
    public async Task RejectSubmissionAsync_UpdatesStatusWithReason()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            Status = SubmissionStatus.PendingReview,
            RequiresHumanReview = true
        };
        _context.Submissions.Add(submission);
        await _context.SaveChangesAsync();

        var request = new RejectRequest
        {
            ReviewedBy = "admin@test.com",
            RejectionReason = "High plagiarism detected"
        };

        // Act
        var result = await _service.RejectSubmissionAsync(submissionId, request);

        // Assert
        result.Should().NotBeNull();
        result!.Status.Should().Be(SubmissionStatus.Rejected);

        var updatedSubmission = await _context.Submissions.FindAsync(submissionId);
        updatedSubmission!.Status.Should().Be(SubmissionStatus.Rejected);
        updatedSubmission.RequiresHumanReview.Should().BeFalse();
        updatedSubmission.RejectionReason.Should().Be("High plagiarism detected");
        updatedSubmission.ReviewedBy.Should().Be("admin@test.com");

        _mockAuditService.Verify(
            a => a.LogActionAsync(
                submissionId,
                "Rejected",
                It.IsAny<string>(),
                "admin@test.com",
                "HumanReview",
                ProcessingStage.HumanReview),
            Times.Once);
    }

    [Fact]
    public async Task OverrideValidationAsync_UpdatesPlagiarismScore()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            Status = SubmissionStatus.PendingReview,
            RequiresHumanReview = true,
            PlagiarismScore = 0.90
        };
        _context.Submissions.Add(submission);
        await _context.SaveChangesAsync();

        var request = new OverrideRequest
        {
            ReviewedBy = "admin@test.com",
            OverridePlagiarismScore = 0.30,
            OverrideReason = "False positive - common terminology"
        };

        // Act
        var result = await _service.OverrideValidationAsync(submissionId, request);

        // Assert
        result.Should().NotBeNull();
        
        var updatedSubmission = await _context.Submissions.FindAsync(submissionId);
        updatedSubmission!.PlagiarismScore.Should().Be(0.30);
        updatedSubmission.RequiresHumanReview.Should().BeFalse();
        updatedSubmission.ReviewedBy.Should().Be("admin@test.com");

        _mockAuditService.Verify(
            a => a.LogActionAsync(
                submissionId,
                "ValidationOverride",
                It.IsAny<string>(),
                "admin@test.com",
                "HumanReview",
                ProcessingStage.HumanReview),
            Times.Once);
    }

    [Fact]
    public async Task OverrideValidationAsync_WithApproveAnyway_MarksAsValid()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            Status = SubmissionStatus.PendingReview,
            RequiresHumanReview = true,
            IsValid = false
        };
        _context.Submissions.Add(submission);
        await _context.SaveChangesAsync();

        var request = new OverrideRequest
        {
            ReviewedBy = "admin@test.com",
            ApproveAnyway = true,
            OverrideReason = "Executive decision"
        };

        // Act
        var result = await _service.OverrideValidationAsync(submissionId, request);

        // Assert
        var updatedSubmission = await _context.Submissions.FindAsync(submissionId);
        updatedSubmission!.IsValid.Should().BeTrue();
        updatedSubmission.Status.Should().Be(SubmissionStatus.Approved);
    }

    [Fact]
    public async Task OverrideValidationAsync_UpdatesBothScores()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            FilePath = "/uploads/test.pdf",
            Status = SubmissionStatus.PendingReview,
            RequiresHumanReview = true,
            PlagiarismScore = 0.70,
            ToxicityScore = 0.60
        };
        _context.Submissions.Add(submission);
        await _context.SaveChangesAsync();

        var request = new OverrideRequest
        {
            ReviewedBy = "admin@test.com",
            OverridePlagiarismScore = 0.20,
            OverrideToxicityScore = 0.10,
            OverrideReason = "Manual review confirmed both are acceptable"
        };

        // Act
        var result = await _service.OverrideValidationAsync(submissionId, request);

        // Assert
        var updatedSubmission = await _context.Submissions.FindAsync(submissionId);
        updatedSubmission!.PlagiarismScore.Should().Be(0.20);
        updatedSubmission!.ToxicityScore.Should().Be(0.10);
    }
}
