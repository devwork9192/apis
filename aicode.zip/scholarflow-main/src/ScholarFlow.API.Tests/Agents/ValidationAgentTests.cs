using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Configuration;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;
using ScholarFlow.API.DTOs.Agents;

namespace ScholarFlow.API.Tests.Agents;

public class ValidationAgentTests
{
    private readonly Mock<ILogger<ValidationAgent>> _mockLogger;
    private readonly Mock<IPlagiarismService> _mockPlagiarismService;
    private readonly Mock<IContentSafetyService> _mockContentSafetyService;
    private readonly ValidationAgent _agent;
    private readonly ValidationRulesSettings _rules;

    public ValidationAgentTests()
    {
        _mockLogger = new Mock<ILogger<ValidationAgent>>();
        _mockPlagiarismService = new Mock<IPlagiarismService>();
        _mockContentSafetyService = new Mock<IContentSafetyService>();
        
        _rules = new ValidationRulesSettings
        {
            MinPageCount = 5,
            MaxPageCount = 50,
            HumanReviewThreshold = 0.7,
            RequiredSections = new List<string> { "introduction", "method", "result", "conclusion" }
        };

        var mockOptions = new Mock<IOptions<ValidationRulesSettings>>();
        mockOptions.Setup(o => o.Value).Returns(_rules);

        _agent = new ValidationAgent(
            mockOptions.Object, 
            _mockLogger.Object,
            _mockPlagiarismService.Object,
            _mockContentSafetyService.Object);
        
        // Setup default returns for plagiarism and content safety services
        _mockPlagiarismService
            .Setup(x => x.CheckPlagiarismAsync(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<double>()))
            .ReturnsAsync(new PlagiarismCheckResult 
            { 
                CheckSuccessful = true, 
                PlagiarismScore = 0.2, 
                IsAboveThreshold = false 
            });
        
        _mockContentSafetyService
            .Setup(x => x.AnalyzeTextAsync(It.IsAny<string>(), It.IsAny<double>()))
            .ReturnsAsync(new ContentSafetyResult 
            { 
                CheckSuccessful = true, 
                ToxicityScore = 0.1, 
                IsAboveThreshold = false 
            });
    }

    [Fact]
    public async Task ValidateAsync_WithValidSubmission_ReturnsValidResult()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Machine Learning in Healthcare",
            Authors = "John Doe, Jane Smith",
            Abstract = "This paper explores the application of machine learning techniques in healthcare diagnostics.",
            Keywords = "machine learning, healthcare, diagnostics",
            Affiliations = "MIT, Stanford",
            PageCount = 10,
            RawText = "Introduction... Method... Result... Conclusion... References...",
            IsScanned = false
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.IsValid.Should().BeTrue();
        result.HasTitle.Should().BeTrue();
        result.HasAuthors.Should().BeTrue();
        result.HasAbstract.Should().BeTrue();
        result.PageCountValid.Should().BeTrue();
        result.ContainsRequiredSections.Should().BeTrue();
        result.Errors.Should().BeEmpty();
    }

    [Fact]
    public async Task ValidateAsync_WithMissingTitle_ReturnsInvalid()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = null,
            Authors = "John Doe",
            Abstract = "Abstract text",
            PageCount = 10,
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeFalse();
        result.HasTitle.Should().BeFalse();
        result.Errors.Should().Contain(e => e.Contains("Title"));
    }

    [Fact]
    public async Task ValidateAsync_WithMissingAuthors_ReturnsInvalid()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title",
            Authors = null,
            Abstract = "Abstract text",
            PageCount = 10,
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeFalse();
        result.HasAuthors.Should().BeFalse();
        result.Errors.Should().Contain(e => e.Contains("Authors"));
    }

    [Fact]
    public async Task ValidateAsync_WithMissingAbstract_ReturnsInvalid()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title",
            Authors = "John Doe",
            Abstract = null,
            PageCount = 10,
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeFalse();
        result.HasAbstract.Should().BeFalse();
        result.Errors.Should().Contain(e => e.Contains("Abstract"));
    }

    [Fact]
    public async Task ValidateAsync_WithPageCountBelowMinimum_ReturnsInvalid()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title",
            Authors = "John Doe",
            Abstract = "Abstract text here",
            PageCount = 3, // Below minimum of 5
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeFalse();
        result.PageCountValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.Contains("below minimum"));
    }

    [Fact]
    public async Task ValidateAsync_WithPageCountAboveMaximum_ReturnsInvalid()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title",
            Authors = "John Doe",
            Abstract = "Abstract text here",
            PageCount = 100, // Above maximum of 50
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeFalse();
        result.PageCountValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.Contains("exceeds maximum"));
    }

    [Fact]
    public async Task ValidateAsync_WithScannedDocument_AddsWarning()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title",
            Authors = "John Doe",
            Abstract = "Abstract text here",
            PageCount = 10,
            RawText = "Content",
            IsScanned = true
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.PageCountValid.Should().BeTrue();
        result.Warnings.Should().Contain(w => w.Contains("scanned"));
    }

    [Fact]
    public async Task ValidateAsync_WithMissingSections_AddsWarning()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title",
            Authors = "John Doe",
            Abstract = "Abstract text here",
            PageCount = 10,
            RawText = "Some content but no clear sections" // Missing required sections
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeTrue(); // Sections are warnings, not errors
        result.ContainsRequiredSections.Should().BeFalse();
        result.Warnings.Should().Contain(w => w.Contains("sections"));
    }

    [Fact]
    public async Task ValidateAsync_WithShortTitle_AddsWarning()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Short", // Less than 10 characters
            Authors = "John Doe",
            Abstract = "Abstract text here",
            PageCount = 10,
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeTrue();
        result.HasTitle.Should().BeTrue();
        result.Warnings.Should().Contain(w => w.Contains("Title is very short"));
    }

    [Fact]
    public async Task ValidateAsync_WithShortAbstract_AddsWarning()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title Here",
            Authors = "John Doe",
            Abstract = "Too short", // Less than 100 characters
            PageCount = 10,
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeTrue();
        result.HasAbstract.Should().BeTrue();
        result.Warnings.Should().Contain(w => w.Contains("Abstract is very short"));
    }

    [Fact]
    public async Task ValidateAsync_WithManyAuthors_AddsWarning()
    {
        // Arrange
        var manyAuthors = string.Join(", ", Enumerable.Range(1, 25).Select(i => $"Author{i}"));
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title Here",
            Authors = manyAuthors,
            Abstract = "Abstract text here with sufficient length",
            PageCount = 10,
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeTrue();
        result.HasAuthors.Should().BeTrue();
        result.Warnings.Should().Contain(w => w.Contains("Unusually high number of authors"));
    }

    [Fact]
    public async Task ValidateAsync_WithMissingMetadata_RequiresHumanReview()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = null,
            Authors = null,
            Abstract = null,
            PageCount = 10,
            RawText = "Content"
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeFalse();
        result.RequiresHumanReview.Should().BeTrue();
    }

    [Fact]
    public async Task ValidateAsync_WithManyWarnings_RequiresHumanReview()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "T", // Warning 1: Short title
            Authors = "A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U", // Warning 2: Many authors
            Abstract = "Short", // Warning 3: Short abstract
            Affiliations = null, // Warning 4: Missing affiliations
            Keywords = null, // Warning 5: Missing keywords
            PageCount = 10,
            RawText = "Content", // Warning 6: Missing sections
            IsScanned = true // Warning 7: Scanned
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.Warnings.Should().HaveCountGreaterThanOrEqualTo(5);
        result.RequiresHumanReview.Should().BeTrue();
    }

    [Fact]
    public async Task ValidateAsync_WhenExceptionOccurs_ReturnsFailureResult()
    {
        // Arrange - submission with null text to trigger exception
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test",
            Authors = "Test",
            Abstract = "Test",
            PageCount = 10,
            RawText = null,
            TranslatedText = null,
            WasTranslated = true // Will try to use TranslatedText which is null
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert - handles gracefully
        result.Should().NotBeNull();
    }

    [Fact]
    public async Task ValidateAsync_WithGoodMetadata_SkipsWordCountValidation()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Research Paper Title",
            Authors = "John Doe",
            Abstract = new string('x', 250), // Long abstract indicates good extraction
            PageCount = 10,
            RawText = "Short text" // Would normally trigger warning
        };

        // Act
        var result = await _agent.ValidateAsync(submission);

        // Assert
        result.IsValid.Should().BeTrue();
        // Should not have word count warning due to good metadata
    }
}
