using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Common;

namespace ScholarFlow.API.Tests.Agents;

/// <summary>
/// Unit tests for PreprocessAgent
/// </summary>
public class PreprocessAgentTests
{
    private readonly Mock<ILogger<PreprocessAgent>> _mockLogger;

    public PreprocessAgentTests()
    {
        _mockLogger = new Mock<ILogger<PreprocessAgent>>();
    }

    [Fact]
    public void PreprocessAgent_Constructor_AcceptsKernelAndLogger()
    {
        // Arrange & Act
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);

        // Assert
        agent.Should().NotBeNull();
        agent.Should().BeAssignableTo<IPreprocessAgent>();
    }

    [Fact]
    public void PreprocessAgent_ImplementsIPreprocessAgent()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        
        // Act
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);

        // Assert
        agent.Should().BeAssignableTo<IPreprocessAgent>();
    }

    [Fact]
    public async Task ProcessAsync_WithEmptyText_ReturnsUnknownLanguage()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        var emptyText = "";
        var pageCount = 5;

        // Act
        var result = await agent.ProcessAsync(emptyText, pageCount);

        // Assert
        result.Should().NotBeNull();
        result.DetectedLanguage.Should().Be(AppConstants.LanguageDetection.UnknownLanguage);
    }

    [Fact]
    public async Task ProcessAsync_WithShortText_ReturnsUnknownLanguage()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        var shortText = "Hi"; // Less than 50 characters
        var pageCount = 1;

        // Act
        var result = await agent.ProcessAsync(shortText, pageCount);

        // Assert
        result.Should().NotBeNull();
        result.DetectedLanguage.Should().Be(AppConstants.LanguageDetection.UnknownLanguage);
    }

    [Fact]
    public async Task ProcessAsync_WithNullText_HandlesGracefully()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        string? nullText = null;
        var pageCount = 0;

        // Act
        var result = await agent.ProcessAsync(nullText!, pageCount);

        // Assert
        result.Should().NotBeNull();
        result.DetectedLanguage.Should().Be(AppConstants.LanguageDetection.UnknownLanguage);
    }

    [Fact]
    public async Task ProcessAsync_CalculatesWordCount()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        // 55 characters, enough to attempt language detection
        var text = "This is a test document with enough words to count properly.";
        var pageCount = 1;

        // Act
        var result = await agent.ProcessAsync(text, pageCount);

        // Assert
        result.Should().NotBeNull();
        // Word count should be calculated (11 words in the text)
        // Note: Actual word count would be in PreprocessResult properties if exposed
    }

    [Fact]
    public async Task ProcessAsync_DetectsScannedDocument()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        // Very short text for 10 pages indicates scanned document
        var minimalText = "Page 1... Page 2... Page 3..."; // ~30 chars for 10 pages
        var pageCount = 10;

        // Act
        var result = await agent.ProcessAsync(minimalText, pageCount);

        // Assert
        result.Should().NotBeNull();
        result.IsScanned.Should().BeTrue();
    }

    [Fact]
    public async Task ProcessAsync_WithSufficientText_NotScanned()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        // Generate sufficient text for 10 pages (at least 2500 chars)
        var sufficientText = string.Join(" ", Enumerable.Repeat(
            "This is a typical paragraph in a research paper with normal text extraction.", 40));
        var pageCount = 10;

        // Act
        var result = await agent.ProcessAsync(sufficientText, pageCount);

        // Assert
        result.Should().NotBeNull();
        result.IsScanned.Should().BeFalse();
    }

    [Fact]
    public async Task ProcessAsync_WithZeroPageCount_HandlesGracefully()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        var text = "Sample text with enough characters to process for language detection purposes.";
        var pageCount = 0;

        // Act
        var result = await agent.ProcessAsync(text, pageCount);

        // Assert
        result.Should().NotBeNull();
        // Should handle division by zero in avg calculations
    }

    [Fact]
    public async Task DetectLanguageAsync_WithValidText_DoesNotThrow()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new PreprocessAgent(kernel, _mockLogger.Object);
        var text = "This is a research paper written in English language with sufficient content.";

        // Act
        var act = async () => await agent.DetectLanguageAsync(text);

        // Assert
        // Without real Azure OpenAI, this may fail, but shouldn't throw ArgumentNullException
        await act.Should().NotThrowAsync<ArgumentNullException>();
    }

    private Kernel CreateMinimalKernel()
    {
        var builder = Kernel.CreateBuilder();
        return builder.Build();
    }
}

/*
 * TESTING NOTES FOR PreprocessAgent:
 * 
 * What CAN be tested in unit tests:
 * ✓ Constructor and interface implementation
 * ✓ Empty/null text handling
 * ✓ Short text handling (< 50 chars)
 * ✓ Scanned document detection heuristics
 * ✓ Word count calculations
 * ✓ Character per page calculations
 * ✓ Zero page count handling
 * 
 * What NEEDS integration tests:
 * - Actual language detection with LLM
 * - Accuracy of language detection for various languages
 * - Performance with large documents
 * - Edge cases with multilingual documents
 * 
 * Key Business Logic (testable without LLM):
 * - isScanned detection based on avgCharsPerPage and avgWordsPerPage
 * - Uses heuristics: < 50 words/page or < ~250 chars/page suggests scanned
 * 
 * Integration Test Example:
 * 
 * [Theory]
 * [InlineData("This is English text", "English")]
 * [InlineData("Ceci est un texte français", "French")]
 * [InlineData("Dies ist deutscher Text", "German")]
 * public async Task DetectLanguageAsync_DetectsLanguageCorrectly(string text, string expected)
 * {
 *     var agent = _factory.Services.GetService<IPreprocessAgent>();
 *     var result = await agent.DetectLanguageAsync(text);
 *     result.Should().Be(expected);
 * }
 */
