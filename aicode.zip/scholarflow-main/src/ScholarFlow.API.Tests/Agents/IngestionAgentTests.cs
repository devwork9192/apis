using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Agents;

public class IngestionAgentTests : IDisposable
{
    private readonly Mock<IPdfService> _mockPdfService;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<IConfiguration> _mockConfiguration;
    private readonly Mock<ILogger<IngestionAgent>> _mockLogger;
    private readonly ScholarFlowDbContext _dbContext;
    private readonly IngestionAgent _agent;
    private readonly DbContextOptions<ScholarFlowDbContext> _options;

    public IngestionAgentTests()
    {
        _options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: $"IngestionAgentTestDb_{Guid.NewGuid()}")
            .Options;

        _dbContext = new ScholarFlowDbContext(_options);
        _mockPdfService = new Mock<IPdfService>();
        _mockAuditService = new Mock<IAuditService>();
        _mockConfiguration = new Mock<IConfiguration>();
        _mockLogger = new Mock<ILogger<IngestionAgent>>();

        _mockConfiguration.Setup(c => c[AppConstants.ConfigKeys.StorageUploadPath])
            .Returns("uploads");

        _agent = new IngestionAgent(
            _dbContext,
            _mockPdfService.Object,
            _mockAuditService.Object,
            _mockConfiguration.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task IngestSubmissionAsync_WithValidFile_ReturnsSuccessResult()
    {
        // Arrange
        var mockFile = CreateMockFile("test.pdf", 1024);
        var uploadedBy = "test@example.com";
        var expectedFilePath = "uploads/test.pdf";
        var expectedText = "Sample PDF text content";
        var expectedPageCount = 10;

        _mockPdfService.Setup(s => s.ValidateFile(mockFile.Object, out It.Ref<string>.IsAny))
            .Returns(true);
        _mockPdfService.Setup(s => s.SaveFileAsync(mockFile.Object, "uploads"))
            .ReturnsAsync(expectedFilePath);
        _mockPdfService.Setup(s => s.ExtractTextAsync(expectedFilePath))
            .ReturnsAsync((expectedText, expectedPageCount));
        _mockAuditService.Setup(s => s.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _agent.IngestSubmissionAsync(mockFile.Object, uploadedBy);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeTrue();
        result.SubmissionId.Should().NotBeEmpty();
        result.FilePath.Should().Be(expectedFilePath);
        result.FileName.Should().Be("test.pdf");
        result.FileSizeBytes.Should().Be(1024);
        result.PageCount.Should().Be(expectedPageCount);
        result.RawText.Should().Be(expectedText);

        var submission = await _dbContext.Submissions.FirstOrDefaultAsync(s => s.Id == result.SubmissionId);
        submission.Should().NotBeNull();
        submission!.FileName.Should().Be("test.pdf");
        submission.Status.Should().Be(SubmissionStatus.Uploaded);
        submission.CurrentStage.Should().Be(ProcessingStage.Upload);
        submission.UploadedBy.Should().Be(uploadedBy);

        _mockAuditService.Verify(s => s.LogActionAsync(
            result.SubmissionId,
            "FileIngested",
            It.IsAny<string>(),
            uploadedBy,
            "IngestionAgent",
            ProcessingStage.Upload), Times.Once);
    }

    [Fact]
    public async Task IngestSubmissionAsync_WithInvalidFile_ReturnsFailureResult()
    {
        // Arrange
        var mockFile = CreateMockFile("test.txt", 1024);
        var uploadedBy = "test@example.com";
        var errorMessage = "File is not a valid PDF";

        _mockPdfService.Setup(s => s.ValidateFile(mockFile.Object, out errorMessage))
            .Returns(false);

        // Act
        var result = await _agent.IngestSubmissionAsync(mockFile.Object, uploadedBy);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Be(errorMessage);
        result.FileName.Should().Be("test.txt");
        result.SubmissionId.Should().BeEmpty();

        var submissions = await _dbContext.Submissions.ToListAsync();
        submissions.Should().BeEmpty();

        _mockPdfService.Verify(s => s.SaveFileAsync(It.IsAny<IFormFile>(), It.IsAny<string>()), Times.Never);
        _mockAuditService.Verify(s => s.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()), Times.Never);
    }

    [Fact]
    public async Task IngestSubmissionAsync_WhenSaveFileFails_ReturnsFailureResult()
    {
        // Arrange
        var mockFile = CreateMockFile("test.pdf", 1024);
        var uploadedBy = "test@example.com";

        _mockPdfService.Setup(s => s.ValidateFile(mockFile.Object, out It.Ref<string>.IsAny))
            .Returns(true);
        _mockPdfService.Setup(s => s.SaveFileAsync(mockFile.Object, "uploads"))
            .ThrowsAsync(new IOException("Disk full"));

        // Act
        var result = await _agent.IngestSubmissionAsync(mockFile.Object, uploadedBy);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Disk full");
        result.FileName.Should().Be("test.pdf");

        var submissions = await _dbContext.Submissions.ToListAsync();
        submissions.Should().BeEmpty();
    }

    [Fact]
    public async Task IngestSubmissionAsync_WhenTextExtractionFails_ReturnsFailureResult()
    {
        // Arrange
        var mockFile = CreateMockFile("test.pdf", 1024);
        var uploadedBy = "test@example.com";
        var expectedFilePath = "uploads/test.pdf";

        _mockPdfService.Setup(s => s.ValidateFile(mockFile.Object, out It.Ref<string>.IsAny))
            .Returns(true);
        _mockPdfService.Setup(s => s.SaveFileAsync(mockFile.Object, "uploads"))
            .ReturnsAsync(expectedFilePath);
        _mockPdfService.Setup(s => s.ExtractTextAsync(expectedFilePath))
            .ThrowsAsync(new InvalidOperationException("Cannot extract text from encrypted PDF"));

        // Act
        var result = await _agent.IngestSubmissionAsync(mockFile.Object, uploadedBy);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Cannot extract text from encrypted PDF");
    }

    [Fact]
    public async Task IngestSubmissionAsync_WithEmptyText_StillCreatesSubmission()
    {
        // Arrange
        var mockFile = CreateMockFile("test.pdf", 1024);
        var uploadedBy = "test@example.com";
        var expectedFilePath = "uploads/test.pdf";
        var emptyText = string.Empty;
        var pageCount = 5;

        _mockPdfService.Setup(s => s.ValidateFile(mockFile.Object, out It.Ref<string>.IsAny))
            .Returns(true);
        _mockPdfService.Setup(s => s.SaveFileAsync(mockFile.Object, "uploads"))
            .ReturnsAsync(expectedFilePath);
        _mockPdfService.Setup(s => s.ExtractTextAsync(expectedFilePath))
            .ReturnsAsync((emptyText, pageCount));
        _mockAuditService.Setup(s => s.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _agent.IngestSubmissionAsync(mockFile.Object, uploadedBy);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeTrue();
        result.RawText.Should().BeEmpty();
        result.PageCount.Should().Be(pageCount);

        var submission = await _dbContext.Submissions.FirstOrDefaultAsync(s => s.Id == result.SubmissionId);
        submission.Should().NotBeNull();
        submission!.RawText.Should().BeEmpty();
    }

    [Fact]
    public async Task IngestSubmissionAsync_UsesConfiguredUploadPath()
    {
        // Arrange
        var customPath = "custom/path";
        _mockConfiguration.Setup(c => c[AppConstants.ConfigKeys.StorageUploadPath])
            .Returns(customPath);

        var agent = new IngestionAgent(
            _dbContext,
            _mockPdfService.Object,
            _mockAuditService.Object,
            _mockConfiguration.Object,
            _mockLogger.Object);

        var mockFile = CreateMockFile("test.pdf", 1024);
        var expectedFilePath = "custom/path/test.pdf";

        _mockPdfService.Setup(s => s.ValidateFile(mockFile.Object, out It.Ref<string>.IsAny))
            .Returns(true);
        _mockPdfService.Setup(s => s.SaveFileAsync(mockFile.Object, customPath))
            .ReturnsAsync(expectedFilePath);
        _mockPdfService.Setup(s => s.ExtractTextAsync(expectedFilePath))
            .ReturnsAsync(("text", 1));
        _mockAuditService.Setup(s => s.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await agent.IngestSubmissionAsync(mockFile.Object, "user@test.com");

        // Assert
        result.Success.Should().BeTrue();
        _mockPdfService.Verify(s => s.SaveFileAsync(mockFile.Object, customPath), Times.Once);
    }

    [Fact]
    public async Task IngestSubmissionAsync_UsesDefaultPathWhenConfigNotSet()
    {
        // Arrange
        _mockConfiguration.Setup(c => c[AppConstants.ConfigKeys.StorageUploadPath])
            .Returns((string?)null);

        var agent = new IngestionAgent(
            _dbContext,
            _mockPdfService.Object,
            _mockAuditService.Object,
            _mockConfiguration.Object,
            _mockLogger.Object);

        var mockFile = CreateMockFile("test.pdf", 1024);

        _mockPdfService.Setup(s => s.ValidateFile(mockFile.Object, out It.Ref<string>.IsAny))
            .Returns(true);
        _mockPdfService.Setup(s => s.SaveFileAsync(mockFile.Object, AppConstants.Paths.DefaultUploadPath))
            .ReturnsAsync("uploads/test.pdf");
        _mockPdfService.Setup(s => s.ExtractTextAsync(It.IsAny<string>()))
            .ReturnsAsync(("text", 1));
        _mockAuditService.Setup(s => s.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await agent.IngestSubmissionAsync(mockFile.Object, "user@test.com");

        // Assert
        result.Success.Should().BeTrue();
        _mockPdfService.Verify(s => s.SaveFileAsync(
            mockFile.Object, AppConstants.Paths.DefaultUploadPath), Times.Once);
    }

    private Mock<IFormFile> CreateMockFile(string fileName, long length)
    {
        var mockFile = new Mock<IFormFile>();
        mockFile.Setup(f => f.FileName).Returns(fileName);
        mockFile.Setup(f => f.Length).Returns(length);
        mockFile.Setup(f => f.ContentType).Returns("application/pdf");
        return mockFile;
    }

    public void Dispose()
    {
        _dbContext?.Dispose();
    }
}
