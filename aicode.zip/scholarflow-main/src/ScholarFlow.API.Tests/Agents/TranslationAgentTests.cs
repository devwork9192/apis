using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using Moq;
using ScholarFlow.API.Agents;

namespace ScholarFlow.API.Tests.Agents;

/// <summary>
/// Unit tests for TranslationAgent
/// </summary>
public class TranslationAgentTests
{
    private readonly Mock<ILogger<TranslationAgent>> _mockLogger;

    public TranslationAgentTests()
    {
        _mockLogger = new Mock<ILogger<TranslationAgent>>();
    }

    [Fact]
    public void TranslationAgent_Constructor_AcceptsKernelAndLogger()
    {
        // Arrange & Act
        var kernel = CreateMinimalKernel();
        var agent = new TranslationAgent(kernel, _mockLogger.Object);

        // Assert
        agent.Should().NotBeNull();
        agent.Should().BeAssignableTo<ITranslationAgent>();
    }

    [Fact]
    public void TranslationAgent_ImplementsITranslationAgent()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        
        // Act
        var agent = new TranslationAgent(kernel, _mockLogger.Object);

        // Assert
        agent.Should().BeAssignableTo<ITranslationAgent>();
    }

    [Fact]
    public async Task TranslateIfNeededAsync_WithEnglishText_ReturnsOriginalText()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new TranslationAgent(kernel, _mockLogger.Object);
        var text = "This is an English research paper";
        var detectedLanguage = "English";

        // Act
        var result = await agent.TranslateIfNeededAsync(text, detectedLanguage);

        // Assert
        result.Should().Be(text);
    }

    [Fact]
    public async Task TranslateIfNeededAsync_WithEnglishLanguage_CaseInsensitive()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new TranslationAgent(kernel, _mockLogger.Object);
        var text = "English paper content";
        
        // Act & Assert
        var result1 = await agent.TranslateIfNeededAsync(text, "english");
        result1.Should().Be(text);
        
        var result2 = await agent.TranslateIfNeededAsync(text, "ENGLISH");
        result2.Should().Be(text);
        
        var result3 = await agent.TranslateIfNeededAsync(text, "English");
        result3.Should().Be(text);
    }

    [Fact]
    public async Task TranslateToEnglishAsync_WithValidParameters_DoesNotThrowNullException()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new TranslationAgent(kernel, _mockLogger.Object);
        var text = "Bonjour, ceci est un article de recherche";
        var sourceLanguage = "French";

        // Act
        var act = async () => await agent.TranslateToEnglishAsync(text, sourceLanguage);

        // Assert
        // Without real Azure OpenAI, this may fail, but shouldn't throw ArgumentNullException
        await act.Should().NotThrowAsync<ArgumentNullException>();
    }

    private Kernel CreateMinimalKernel()
    {
        var builder = Kernel.CreateBuilder();
        return builder.Build();
    }
}

/*
 * TESTING NOTES FOR TranslationAgent:
 * 
 * What CAN be tested in unit tests:
 * ✓ Constructor dependency injection
 * ✓ Interface implementation
 * ✓ TranslateIfNeededAsync logic for English text (no LLM call)
 * ✓ Case-insensitive language detection
 * 
 * What NEEDS integration tests:
 * - Actual translation from non-English to English
 * - Translation quality and accuracy
 * - Error handling for unsupported languages
 * - Large text translation (chunking if implemented)
 * 
 * Integration Test Example:
 * 
 * [Fact]
 * public async Task TranslateToEnglishAsync_TranslatesFrenchToEnglish()
 * {
 *     var agent = _factory.Services.GetService<ITranslationAgent>();
 *     var frenchText = "Bonjour le monde";
 *     
 *     var result = await agent.TranslateToEnglishAsync(frenchText, "French");
 *     
 *     result.Should().Contain("Hello");
 * }
 * 
 * Alternative: Mock through interface in orchestration tests
 * Mock<ITranslationAgent> mockAgent = new Mock<ITranslationAgent>();
 * mockAgent.Setup(a => a.TranslateIfNeededAsync(text, "French"))
 *          .ReturnsAsync("Translated text");
 */
