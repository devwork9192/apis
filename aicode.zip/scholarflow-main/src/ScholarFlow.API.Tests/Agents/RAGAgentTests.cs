using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Memory;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Tests.Agents;

public class RAGAgentTests
{
    private readonly Mock<IEmbeddingService> _mockEmbeddingService;
    private readonly Mock<IVectorStoreService> _mockVectorStoreService;
    private readonly Mock<ILogger<RAGAgent>> _mockLogger;
    private readonly RAGAgent _agent;

    public RAGAgentTests()
    {
        _mockEmbeddingService = new Mock<IEmbeddingService>();
        _mockVectorStoreService = new Mock<IVectorStoreService>();
        _mockLogger = new Mock<ILogger<RAGAgent>>();
        _agent = new RAGAgent(_mockEmbeddingService.Object, _mockVectorStoreService.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task StoreDocumentAsync_WithValidSubmission_ReturnsSuccess()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "This is a research paper about machine learning.",
            Title = "ML Research",
            Authors = "John Doe",
            DetectedLanguage = "en",
            WasTranslated = false
        };

        var mockEmbedding = new float[1536];
        _mockEmbeddingService.Setup(x => x.GenerateEmbeddingAsync(It.IsAny<string>()))
            .ReturnsAsync(mockEmbedding);

        _mockVectorStoreService.Setup(x => x.StoreDocumentAsync(
            It.IsAny<Guid>(),
            It.IsAny<string>(),
            It.IsAny<float[]>(),
            It.IsAny<Dictionary<string, object>>()))
            .Returns(Task.CompletedTask);

        _mockVectorStoreService.Setup(x => x.SearchByEmbeddingAsync(It.IsAny<float[]>(), It.IsAny<int>()))
            .ReturnsAsync(new List<SearchResult>());

        // Act
        var result = await _agent.StoreDocumentAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.StoredSuccessfully.Should().BeTrue();
        result.ErrorMessage.Should().BeNull();
        
        _mockEmbeddingService.Verify(x => x.GenerateEmbeddingAsync(It.IsAny<string>()), Times.Once);
        _mockVectorStoreService.Verify(x => x.StoreDocumentAsync(
            submission.Id,
            It.IsAny<string>(),
            mockEmbedding,
            It.IsAny<Dictionary<string, object>>()), Times.Once);
    }

    [Fact]
    public async Task StoreDocumentAsync_WithTranslatedSubmission_UsesTranslatedText()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "原文テキスト",
            TranslatedText = "Translated English text",
            WasTranslated = true,
            Title = "Research Paper",
            DetectedLanguage = "ja"
        };

        var mockEmbedding = new float[1536];
        _mockEmbeddingService.Setup(x => x.GenerateEmbeddingAsync("Translated English text"))
            .ReturnsAsync(mockEmbedding);

        _mockVectorStoreService.Setup(x => x.StoreDocumentAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<float[]>(), It.IsAny<Dictionary<string, object>>()))
            .Returns(Task.CompletedTask);

        _mockVectorStoreService.Setup(x => x.SearchByEmbeddingAsync(It.IsAny<float[]>(), It.IsAny<int>()))
            .ReturnsAsync(new List<SearchResult>());

        // Act
        var result = await _agent.StoreDocumentAsync(submission);

        // Assert
        result.StoredSuccessfully.Should().BeTrue();
        _mockEmbeddingService.Verify(x => x.GenerateEmbeddingAsync("Translated English text"), Times.Once);
    }

    [Fact]
    public async Task StoreDocumentAsync_WithNoText_ReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = null,
            TranslatedText = null
        };

        // Act
        var result = await _agent.StoreDocumentAsync(submission);

        // Assert
        result.StoredSuccessfully.Should().BeFalse();
        result.ErrorMessage.Should().Contain("No text content available");
        _mockEmbeddingService.Verify(x => x.GenerateEmbeddingAsync(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task StoreDocumentAsync_WithRelatedDocuments_ReturnsRelatedIds()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var relatedId1 = Guid.NewGuid();
        var relatedId2 = Guid.NewGuid();

        var submission = new Submission
        {
            Id = submissionId,
            RawText = "Research about AI",
            Title = "AI Research"
        };

        var mockEmbedding = new float[1536];
        _mockEmbeddingService.Setup(x => x.GenerateEmbeddingAsync(It.IsAny<string>()))
            .ReturnsAsync(mockEmbedding);

        _mockVectorStoreService.Setup(x => x.StoreDocumentAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<float[]>(), It.IsAny<Dictionary<string, object>>()))
            .Returns(Task.CompletedTask);

        var searchResults = new List<SearchResult>
        {
            new SearchResult { SubmissionId = submissionId, Score = 1.0f }, // Self (should be excluded)
            new SearchResult { SubmissionId = relatedId1, Score = 0.95f },
            new SearchResult { SubmissionId = relatedId2, Score = 0.90f }
        };

        _mockVectorStoreService.Setup(x => x.SearchByEmbeddingAsync(mockEmbedding, 5))
            .ReturnsAsync(searchResults);

        // Act
        var result = await _agent.StoreDocumentAsync(submission);

        // Assert
        result.StoredSuccessfully.Should().BeTrue();
        result.RelatedDocumentsCount.Should().Be(2); // Excludes self
        result.RelatedSubmissionIds.Should().Contain(relatedId1);
        result.RelatedSubmissionIds.Should().Contain(relatedId2);
        result.RelatedSubmissionIds.Should().NotContain(submissionId);
    }

    [Fact]
    public async Task StoreDocumentAsync_WhenEmbeddingFails_ReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        _mockEmbeddingService.Setup(x => x.GenerateEmbeddingAsync(It.IsAny<string>()))
            .ThrowsAsync(new Exception("Embedding generation failed"));

        // Act
        var result = await _agent.StoreDocumentAsync(submission);

        // Assert
        result.StoredSuccessfully.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Embedding generation failed");
    }

    [Fact]
    public async Task StoreDocumentAsync_TruncatesLongText()
    {
        // Arrange
        var longText = new string('x', 35000); // 35k characters
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = longText
        };

        var mockEmbedding = new float[1536];
        string? capturedText = null;
        
        _mockEmbeddingService.Setup(x => x.GenerateEmbeddingAsync(It.IsAny<string>()))
            .Callback<string>(text => capturedText = text)
            .ReturnsAsync(mockEmbedding);

        _mockVectorStoreService.Setup(x => x.StoreDocumentAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<float[]>(), It.IsAny<Dictionary<string, object>>()))
            .Returns(Task.CompletedTask);

        _mockVectorStoreService.Setup(x => x.SearchByEmbeddingAsync(It.IsAny<float[]>(), It.IsAny<int>()))
            .ReturnsAsync(new List<SearchResult>());

        // Act
        var result = await _agent.StoreDocumentAsync(submission);

        // Assert
        result.StoredSuccessfully.Should().BeTrue();
        capturedText.Should().NotBeNull();
        capturedText!.Length.Should().Be(30000); // Truncated to 30k
    }
}
