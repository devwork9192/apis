using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using ScholarFlow.API.Agents;
using ScholarFlow.API.DTOs.Chat;
using ScholarFlow.API.Memory;
using ScholarFlow.API.Database;
using ScholarFlow.API.Models;
using Microsoft.EntityFrameworkCore;

namespace ScholarFlow.API.Tests.Agents;

public class QAAgentTests : IDisposable
{
    private readonly Mock<IVectorStoreService> _mockVectorStore;
    private readonly Mock<IPreprocessAgent> _mockPreprocessAgent;
    private readonly Mock<ITranslationAgent> _mockTranslationAgent;
    private readonly ScholarFlowDbContext _context;
    private readonly Mock<ILogger<QAAgent>> _mockLogger;
    private readonly QAAgent _agent;

    public QAAgentTests()
    {
        // Setup in-memory database
        var options = new DbContextOptionsBuilder<ScholarFlowDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        _context = new ScholarFlowDbContext(options);

        var kernel = Kernel.CreateBuilder().Build();
        _mockVectorStore = new Mock<IVectorStoreService>();
        _mockPreprocessAgent = new Mock<IPreprocessAgent>();
        _mockTranslationAgent = new Mock<ITranslationAgent>();
        _mockLogger = new Mock<ILogger<QAAgent>>();

        _agent = new QAAgent(
            kernel,
            _mockVectorStore.Object,
            _mockPreprocessAgent.Object,
            _mockTranslationAgent.Object,
            _context,
            _mockLogger.Object);
    }

    public void Dispose()
    {
        _context.Database.EnsureDeleted();
        _context.Dispose();
    }

    [Fact]
    public async Task AnswerQuestionAsync_WithNoResults_ReturnsNoResultsMessage()
    {
        // Arrange
        var query = "Non-existent topic";

        _mockPreprocessAgent.Setup(x => x.DetectLanguageAsync(query))
            .ReturnsAsync("en");

        _mockVectorStore.Setup(x => x.SearchAsync(It.IsAny<string>(), It.IsAny<int>()))
            .ReturnsAsync(new List<SearchResult>());

        // Act
        var result = await _agent.AnswerQuestionAsync(query);

        // Assert
        Assert.NotNull(result);
        Assert.Contains("couldn't find any relevant research papers", result.Answer);
        Assert.Empty(result.Sources);
        Assert.Empty(result.CitedSubmissions);
        Assert.False(result.WasTranslated);
    }

    [Fact]
    public async Task AnswerQuestionAsync_WithNoResults_TranslatesNoResultsMessageWhenNotEnglish()
    {
        // Arrange
        var query = "Topic inexistant";
        var translatedNoResultMsg = "Je n'ai trouvé aucun article de recherche pertinent...";

        _mockPreprocessAgent.Setup(x => x.DetectLanguageAsync(query))
            .ReturnsAsync("fr");

        _mockTranslationAgent.Setup(x => x.TranslateToEnglishAsync(query, "fr"))
            .ReturnsAsync("Non-existent topic");

        _mockVectorStore.Setup(x => x.SearchAsync(It.IsAny<string>(), It.IsAny<int>()))
            .ReturnsAsync(new List<SearchResult>());

        _mockTranslationAgent.Setup(x => x.TranslateFromEnglishAsync(It.IsAny<string>(), "fr"))
            .ReturnsAsync(translatedNoResultMsg);

        // Act
        var result = await _agent.AnswerQuestionAsync(query);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(translatedNoResultMsg, result.Answer);
        Assert.Equal("fr", result.DetectedLanguage);
        Assert.True(result.WasTranslated);
        Assert.Empty(result.Sources);
    }

    [Fact]
    public async Task AnswerQuestionAsync_WithProvidedLanguage_SkipsLanguageDetection()
    {
        // Arrange
        var query = "What is deep learning?";
        var language = "en";

        _mockVectorStore.Setup(x => x.SearchAsync(It.IsAny<string>(), It.IsAny<int>()))
            .ReturnsAsync(new List<SearchResult>());

        // Act
        var result = await _agent.AnswerQuestionAsync(query, language);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("en", result.DetectedLanguage);
        
        // Verify language detection was NOT called
        _mockPreprocessAgent.Verify(x => x.DetectLanguageAsync(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task AnswerQuestionAsync_CallsSearchWithCorrectTopK()
    {
        // Arrange
        var query = "What is AI?";
        var topK = 10;

        _mockPreprocessAgent.Setup(x => x.DetectLanguageAsync(query))
            .ReturnsAsync("en");

        _mockVectorStore.Setup(x => x.SearchAsync(It.IsAny<string>(), topK))
            .ReturnsAsync(new List<SearchResult>());

        // Act
        var result = await _agent.AnswerQuestionAsync(query, topK: topK);

        // Assert
        _mockVectorStore.Verify(x => x.SearchAsync(It.IsAny<string>(), topK), Times.Once);
    }

    [Fact]
    public async Task AnswerQuestionAsync_TranslatesQueryToEnglishForNonEnglishLanguage()
    {
        // Arrange
        var query = "¿Qué es inteligencia artificial?";
        var englishQuery = "What is AI?";

        _mockPreprocessAgent.Setup(x => x.DetectLanguageAsync(query))
            .ReturnsAsync("es");

        _mockTranslationAgent.Setup(x => x.TranslateToEnglishAsync(query, "es"))
            .ReturnsAsync(englishQuery);

        _mockVectorStore.Setup(x => x.SearchAsync(It.IsAny<string>(), It.IsAny<int>()))
            .ReturnsAsync(new List<SearchResult>());

        _mockTranslationAgent.Setup(x => x.TranslateFromEnglishAsync(It.IsAny<string>(), "es"))
            .ReturnsAsync("No encontré artículos relevantes.");

        // Act
        var result = await _agent.AnswerQuestionAsync(query);

        // Assert
        Assert.True(result.WasTranslated);
        Assert.Equal("es", result.DetectedLanguage);
        Assert.Equal(englishQuery, result.TranslatedQuery);
        _mockTranslationAgent.Verify(x => x.TranslateToEnglishAsync(query, "es"), Times.Once);
    }
}
