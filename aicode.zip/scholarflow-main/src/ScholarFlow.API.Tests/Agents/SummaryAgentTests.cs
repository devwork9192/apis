using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Tests.Agents;

/// <summary>
/// Unit tests for SummaryAgent
/// Testing strategy: Focus on validation and business logic.
/// For actual LLM summary generation, use integration tests.
/// </summary>
public class SummaryAgentTests
{
    private readonly Mock<ILogger<SummaryAgent>> _mockLogger;

    public SummaryAgentTests()
    {
        _mockLogger = new Mock<ILogger<SummaryAgent>>();
    }

    [Fact]
    public void SummaryAgent_Constructor_AcceptsKernelAndLogger()
    {
        // Arrange & Act
        var kernel = CreateMinimalKernel();
        var agent = new SummaryAgent(kernel, _mockLogger.Object);

        // Assert
        agent.Should().NotBeNull();
        agent.Should().BeAssignableTo<ISummaryAgent>();
    }

    [Fact]
    public void SummaryAgent_ImplementsISummaryAgent()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        
        // Act
        var agent = new SummaryAgent(kernel, _mockLogger.Object);

        // Assert
        agent.Should().BeAssignableTo<ISummaryAgent>();
    }

    [Fact]
    public async Task GenerateSummaryAsync_WithMissingTitle_ReturnsFailureResult()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new SummaryAgent(kernel, _mockLogger.Object);
        
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = null, // Missing title
            Abstract = "Some abstract",
            RawText = "Paper content"
        };

        // Act
        var result = await agent.GenerateSummaryAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.SummarySuccessful.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Title");
    }

    [Fact]
    public async Task GenerateSummaryAsync_WithMissingAbstract_ReturnsFailureResult()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new SummaryAgent(kernel, _mockLogger.Object);
        
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Research Title",
            Abstract = null, // Missing abstract
            RawText = "Paper content"
        };

        // Act
        var result = await agent.GenerateSummaryAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.SummarySuccessful.Should().BeFalse();
        result.ErrorMessage.Should().Contain("abstract");
    }

    [Fact]
    public async Task GenerateSummaryAsync_WithEmptyTitle_ReturnsFailureResult()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new SummaryAgent(kernel, _mockLogger.Object);
        
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "   ", // Empty/whitespace title
            Abstract = "Some abstract",
            RawText = "Paper content"
        };

        // Act
        var result = await agent.GenerateSummaryAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.SummarySuccessful.Should().BeFalse();
    }

    [Fact]
    public async Task GenerateSummaryAsync_WithEmptyAbstract_ReturnsFailureResult()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new SummaryAgent(kernel, _mockLogger.Object);
        
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Research Title",
            Abstract = "", // Empty abstract
            RawText = "Paper content"
        };

        // Act
        var result = await agent.GenerateSummaryAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.SummarySuccessful.Should().BeFalse();
    }

    [Fact]
    public async Task GenerateSummaryAsync_WithValidSubmission_CallsKernel()
    {
        // Arrange
        var kernel = CreateMinimalKernel();
        var agent = new SummaryAgent(kernel, _mockLogger.Object);
        
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Machine Learning in Healthcare",
            Authors = "John Doe",
            Abstract = "This paper explores ML applications in healthcare.",
            Keywords = "machine learning, healthcare",
            RawText = "Full paper text content here...",
            PageCount = 10
        };

        // Act
        var act = async () => await agent.GenerateSummaryAsync(submission);

        // Assert
        // Without real Azure OpenAI, this will fail, but shouldn't throw ArgumentException
        await act.Should().NotThrowAsync<ArgumentNullException>();
        await act.Should().NotThrowAsync<ArgumentException>();
    }

    private Kernel CreateMinimalKernel()
    {
        var builder = Kernel.CreateBuilder();
        return builder.Build();
    }
}

/*
 * TESTING APPROACH FOR SummaryAgent:
 * 
 * Unit Tests (this file):
 * ✓ Test input validation (missing title, abstract)
 * ✓ Test constructor and interface implementation
 * ✓ Test error handling
 * 
 * Integration Tests (recommended separate file):
 * - Test with real Azure OpenAI endpoint
 * - Validate summary quality (length, content)
 * - Test translated vs. raw text handling
 * - Example:
 *   [Fact]
 *   public async Task GenerateSummaryAsync_ProducesSummaryWithinWordCount()
 *   {
 *       var agent = _factory.Services.GetService<ISummaryAgent>();
 *       var submission = CreateTestSubmission();
 *       var result = await agent.GenerateSummaryAsync(submission);
 *       result.SummarySuccessful.Should().BeTrue();
 *       result.SummaryWordCount.Should().BeInRange(200, 300);
 *   }
 * 
 * Orchestration Tests:
 * - In SummaryGenerationStepTests, mock ISummaryAgent
 * - This avoids Kernel dependency entirely
 */
