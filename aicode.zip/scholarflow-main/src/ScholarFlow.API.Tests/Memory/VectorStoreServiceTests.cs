using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ScholarFlow.API.Configuration;
using ScholarFlow.API.Memory;

namespace ScholarFlow.API.Tests.Memory;

public class VectorStoreServiceTests
{
    private readonly Mock<ILogger<VectorStoreService>> _mockLogger;
    private readonly Mock<IEmbeddingService> _mockEmbeddingService;
    private readonly MemorySettings _settings;
    private readonly VectorStoreService _service;

    public VectorStoreServiceTests()
    {
        _mockLogger = new Mock<ILogger<VectorStoreService>>();
        _mockEmbeddingService = new Mock<IEmbeddingService>();
        _settings = new MemorySettings { EmbeddingDimensions = 1536 };
        var options = Options.Create(_settings);
        _service = new VectorStoreService(options, _mockLogger.Object, _mockEmbeddingService.Object);
        
        // Clear the static store before each test for isolation
        _service.ClearAsync().Wait();
    }

    [Fact]
    public async Task StoreDocumentAsync_WithValidInput_StoresSuccessfully()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var text = "Test document content";
        var embedding = new float[1536];
        var metadata = new Dictionary<string, object> { ["title"] = "Test" };

        // Act
        await _service.StoreDocumentAsync(submissionId, text, embedding, metadata);

        // No exception means success
        // Verify by searching
        var searchEmbedding = new float[1536];
        var results = await _service.SearchByEmbeddingAsync(searchEmbedding, 5);

        // Assert
        results.Should().NotBeEmpty();
        results.Should().ContainSingle(r => r.SubmissionId == submissionId);
    }

    [Fact]
    public async Task StoreDocumentAsync_WithWrongDimensions_ThrowsException()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var text = "Test document";
        var embedding = new float[128]; // Wrong dimensions

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await _service.StoreDocumentAsync(submissionId, text, embedding));
    }

    [Fact]
    public async Task SearchByEmbeddingAsync_WithEmptyStore_ReturnsEmpty()
    {
        // Arrange
        var queryEmbedding = new float[1536];

        // Act
        var results = await _service.SearchByEmbeddingAsync(queryEmbedding, 5);

        // Assert
        results.Should().BeEmpty();
    }

    [Fact]
    public async Task SearchByEmbeddingAsync_ReturnsTopKResults()
    {
        // Arrange
        var id1 = Guid.NewGuid();
        var id2 = Guid.NewGuid();
        var id3 = Guid.NewGuid();

        var embedding1 = CreateEmbedding(1.0f);
        var embedding2 = CreateEmbedding(0.5f);
        var embedding3 = CreateEmbedding(0.2f);

        await _service.StoreDocumentAsync(id1, "Doc1", embedding1);
        await _service.StoreDocumentAsync(id2, "Doc2", embedding2);
        await _service.StoreDocumentAsync(id3, "Doc3", embedding3);

        // Query with embedding similar to embedding1
        var queryEmbedding = CreateEmbedding(0.95f);

        // Act
        var results = (await _service.SearchByEmbeddingAsync(queryEmbedding, 2)).ToList();

        // Assert
        results.Should().HaveCount(2);
        results[0].Score.Should().BeGreaterThan(results[1].Score);
    }

    [Fact]
    public async Task SearchAsync_GeneratesEmbeddingAndSearches()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var embedding = new float[1536];
        await _service.StoreDocumentAsync(submissionId, "Test doc", embedding);

        var queryEmbedding = new float[1536];
        _mockEmbeddingService.Setup(x => x.GenerateEmbeddingAsync("test query"))
            .ReturnsAsync(queryEmbedding);

        // Act
        var results = await _service.SearchAsync("test query", 5);

        // Assert
        results.Should().NotBeNull();
        _mockEmbeddingService.Verify(x => x.GenerateEmbeddingAsync("test query"), Times.Once);
    }

    [Fact]
    public async Task DeleteDocumentAsync_RemovesDocument()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var embedding = new float[1536];
        await _service.StoreDocumentAsync(submissionId, "Test", embedding);

        // Verify it's stored
        var beforeDelete = await _service.SearchByEmbeddingAsync(embedding, 5);
        beforeDelete.Should().ContainSingle(r => r.SubmissionId == submissionId);

        // Act
        await _service.DeleteDocumentAsync(submissionId);

        // Assert
        var afterDelete = await _service.SearchByEmbeddingAsync(embedding, 5);
        afterDelete.Should().NotContain(r => r.SubmissionId == submissionId);
    }

    [Fact]
    public async Task DeleteDocumentAsync_WithNonExistentId_DoesNotThrow()
    {
        // Arrange
        var nonExistentId = Guid.NewGuid();

        // Act & Assert (should not throw)
        await _service.DeleteDocumentAsync(nonExistentId);
    }

    [Fact]
    public async Task StoreDocumentAsync_UpdatesExistingDocument()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var embedding1 = new float[1536];
        var embedding2 = new float[1536];
        embedding2[0] = 1.0f; // Make it different

        await _service.StoreDocumentAsync(submissionId, "First version", embedding1);

        // Act - Store again with same ID
        await _service.StoreDocumentAsync(submissionId, "Second version", embedding2);

        // Assert - Should only have one document
        var results = (await _service.SearchByEmbeddingAsync(embedding2, 10)).ToList();
        var matchingDocs = results.Where(r => r.SubmissionId == submissionId).ToList();
        matchingDocs.Should().ContainSingle();
        matchingDocs[0].Text.Should().Be("Second version");
    }

    private static float[] CreateEmbedding(float value)
    {
        var embedding = new float[1536];
        for (int i = 0; i < embedding.Length; i++)
        {
            embedding[i] = value;
        }
        return embedding;
    }
}
