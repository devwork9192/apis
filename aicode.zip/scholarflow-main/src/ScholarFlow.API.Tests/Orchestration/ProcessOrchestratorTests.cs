using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Orchestration;

public class ProcessOrchestratorTests
{
    private readonly Mock<IServiceProvider> _mockServiceProvider;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<ProcessOrchestrator>> _mockLogger;
    private readonly ProcessOrchestrator _orchestrator;

    public ProcessOrchestratorTests()
    {
        _mockServiceProvider = new Mock<IServiceProvider>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<ProcessOrchestrator>>();

        _mockAuditService.Setup(a => a.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        _orchestrator = new ProcessOrchestrator(
            _mockServiceProvider.Object,
            _mockAuditService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public async Task ExecuteWorkflowAsync_WithAllStepsSuccessful_ReturnsSuccess()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        SetupAllSuccessfulSteps();

        // Act
        var result = await _orchestrator.ExecuteWorkflowAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeTrue();
        result.SubmissionId.Should().Be(submission.Id);

        // Verify workflow started and completed
        _mockAuditService.Verify(a => a.LogActionAsync(
            submission.Id,
            "WorkflowStarted",
            It.IsAny<string>(),
            It.IsAny<string>(),
            "ProcessOrchestrator",
            ProcessingStage.Preprocess), Times.Once);

        _mockAuditService.Verify(a => a.LogActionAsync(
            submission.Id,
            "WorkflowCompleted",
            It.IsAny<string>(),
            It.IsAny<string>(),
            "ProcessOrchestrator",
            ProcessingStage.RAG), Times.Once);
    }

    [Fact]
    public async Task ExecuteWorkflowAsync_WhenStepFails_StopsAndReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        // Setup first step to succeed
        var mockLanguageStep = CreateMockStep("LanguageDetection", true);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(LanguageDetectionStep)))
            .Returns(mockLanguageStep.Object);

        // Setup second step to fail
        var mockTranslationStep = CreateMockStep("Translation", false, "Translation failed");
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(TranslationStep)))
            .Returns(mockTranslationStep.Object);

        // Act
        var result = await _orchestrator.ExecuteWorkflowAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Translation failed");

        _mockAuditService.Verify(a => a.LogActionAsync(
            submission.Id,
            "WorkflowFailed",
            It.Is<string>(s => s.Contains("Translation")),
            It.IsAny<string>(),
            "ProcessOrchestrator",
            ProcessingStage.Preprocess), Times.Once);

        // Verify subsequent steps were not called
        _mockServiceProvider.Verify(sp => sp.GetService(typeof(MetadataExtractionStep)), Times.Never);
    }

    [Fact]
    public async Task ExecuteWorkflowAsync_WhenCancelled_ReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        var cts = new CancellationTokenSource();
        cts.Cancel();

        // Act
        var result = await _orchestrator.ExecuteWorkflowAsync(submission, cts.Token);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("cancelled");
    }

    [Fact]
    public async Task ExecuteWorkflowAsync_WhenStepCannotBeResolved_ReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        _mockServiceProvider.Setup(sp => sp.GetService(typeof(LanguageDetectionStep)))
            .Returns(null!); // Cannot resolve

        // Act
        var result = await _orchestrator.ExecuteWorkflowAsync(submission);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Failed to resolve process step");
    }

    [Fact]
    public async Task ExecuteWorkflowAsync_MapsStateToResult()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        SetupAllSuccessfulSteps();

        // Act
        var result = await _orchestrator.ExecuteWorkflowAsync(submission);

        // Assert
        result.DetectedLanguage.Should().NotBeNull();
        result.TranslatedText.Should().NotBeNull();
        result.ExtractedMetadata.Should().NotBeNull();
        result.IsValid.Should().BeTrue();
        result.Summary.Should().NotBeNull();
    }

    [Fact]
    public async Task ExecuteWorkflowAsync_WhenUnexpectedExceptionOccurs_ReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        var mockStep = new Mock<IProcessStep>();
        mockStep.Setup(s => s.StepName).Returns("LanguageDetection");
        mockStep.Setup(s => s.ExecuteAsync(It.IsAny<ProcessContext>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new Exception("Unexpected error"));

        _mockServiceProvider.Setup(sp => sp.GetService(typeof(LanguageDetectionStep)))
            .Returns(mockStep.Object);

        // Act
        var result = await _orchestrator.ExecuteWorkflowAsync(submission);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Unexpected error");

        _mockAuditService.Verify(a => a.LogActionAsync(
            submission.Id,
            "WorkflowException",
            It.IsAny<string>(),
            It.IsAny<string>(),
            "ProcessOrchestrator",
            ProcessingStage.Preprocess), Times.Once);
    }

    [Fact]
    public async Task ExecuteWorkflowAsync_ExecutesAllFiveStepsInOrder()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        var stepOrder = new List<string>();
        SetupStepToTrackOrder("LanguageDetection", stepOrder);
        SetupStepToTrackOrder("Translation", stepOrder);
        SetupStepToTrackOrder("MetadataExtraction", stepOrder);
        SetupStepToTrackOrder("Validation", stepOrder);
        SetupStepToTrackOrder("SummaryGeneration", stepOrder);
        SetupStepToTrackOrder("RAG", stepOrder);

        _mockServiceProvider.Setup(sp => sp.GetService(typeof(LanguageDetectionStep)))
            .Returns(CreateMockStep("LanguageDetection", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(TranslationStep)))
            .Returns(CreateMockStep("Translation", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(MetadataExtractionStep)))
            .Returns(CreateMockStep("MetadataExtraction", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(ValidationStep)))
            .Returns(CreateMockStep("Validation", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(SummaryGenerationStep)))
            .Returns(CreateMockStep("SummaryGeneration", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(RAGStep)))
            .Returns(CreateMockStep("RAG", true).Object);

        // Act
        var result = await _orchestrator.ExecuteWorkflowAsync(submission);

        // Assert
        result.Success.Should().BeTrue();
        _mockServiceProvider.Verify(sp => sp.GetService(typeof(LanguageDetectionStep)), Times.Once);
        _mockServiceProvider.Verify(sp => sp.GetService(typeof(TranslationStep)), Times.Once);
        _mockServiceProvider.Verify(sp => sp.GetService(typeof(MetadataExtractionStep)), Times.Once);
        _mockServiceProvider.Verify(sp => sp.GetService(typeof(ValidationStep)), Times.Once);
        _mockServiceProvider.Verify(sp => sp.GetService(typeof(SummaryGenerationStep)), Times.Once);
        _mockServiceProvider.Verify(sp => sp.GetService(typeof(RAGStep)), Times.Once);
    }

    private void SetupAllSuccessfulSteps()
    {
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(LanguageDetectionStep)))
            .Returns(CreateMockStep("LanguageDetection", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(TranslationStep)))
            .Returns(CreateMockStep("Translation", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(MetadataExtractionStep)))
            .Returns(CreateMockStep("MetadataExtraction", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(ValidationStep)))
            .Returns(CreateMockStep("Validation", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(SummaryGenerationStep)))
            .Returns(CreateMockStep("SummaryGeneration", true).Object);
        _mockServiceProvider.Setup(sp => sp.GetService(typeof(RAGStep)))
            .Returns(CreateMockStep("RAG", true).Object);
    }

    private Mock<IProcessStep> CreateMockStep(string stepName, bool success, string? errorMessage = null)
    {
        var mockStep = new Mock<IProcessStep>();
        mockStep.Setup(s => s.StepName).Returns(stepName);
        mockStep.Setup(s => s.ExecuteAsync(It.IsAny<ProcessContext>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProcessContext ctx, CancellationToken ct) =>
            {
                // Simulate updating context
                if (stepName == "LanguageDetection") ctx.State.DetectedLanguage = "English";
                if (stepName == "Translation") ctx.State.TranslatedText = "Translated";
                if (stepName == "MetadataExtraction") ctx.State.ExtractedMetadata = "{}";
                if (stepName == "Validation") ctx.State.IsValid = true;
                if (stepName == "SummaryGeneration") ctx.State.Summary = "Summary";
                if (stepName == "RAG") 
                {
                    ctx.State.Metadata["RagStored"] = true;
                    ctx.State.Metadata["RelatedDocumentsCount"] = 0;
                }

                return new StepResult
                {
                    Success = success,
                    ErrorMessage = errorMessage
                };
            });
        return mockStep;
    }

    private void SetupStepToTrackOrder(string stepName, List<string> orderList)
    {
        // This is just a placeholder - actual tracking would need proper setup
        orderList.Add(stepName);
    }
}
