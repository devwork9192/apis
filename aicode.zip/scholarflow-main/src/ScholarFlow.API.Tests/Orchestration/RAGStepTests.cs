using Xunit;
using Moq;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Services;
using ScholarFlow.API.Models;
using ScholarFlow.API.DTOs.Agents;

namespace ScholarFlow.API.Tests.Orchestration;

public class RAGStepTests
{
    private readonly Mock<IRAGAgent> _mockRagAgent;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<RAGStep>> _mockLogger;
    private readonly RAGStep _step;

    public RAGStepTests()
    {
        _mockRagAgent = new Mock<IRAGAgent>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<RAGStep>>();
        _step = new RAGStep(_mockRagAgent.Object, _mockAuditService.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task ExecuteAsync_WithSuccessfulStorage_ReturnsSuccess()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        var context = new ProcessContext
        {
            SubmissionId = submission.Id,
            Submission = submission,
            State = new ProcessState()
        };

        var ragResult = new RAGResult
        {
            StoredSuccessfully = true,
            RelatedDocumentsCount = 2,
            RelatedSubmissionIds = new List<Guid> { Guid.NewGuid(), Guid.NewGuid() }
        };

        _mockRagAgent.Setup(x => x.StoreDocumentAsync(submission))
            .ReturnsAsync(ragResult);

        _mockAuditService.Setup(x => x.LogActionAsync(
            It.IsAny<Guid>(),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeTrue();
        result.Data.Should().ContainKey("StoredSuccessfully");
        result.Data["StoredSuccessfully"].Should().Be(true);
        result.Data["RelatedDocumentsCount"].Should().Be(2);
        
        context.State.Metadata.Should().ContainKey("RagStored");
        context.State.Metadata["RagStored"].Should().Be(true);
        context.State.Metadata["RelatedDocumentsCount"].Should().Be(2);

        _mockAuditService.Verify(x => x.LogActionAsync(
            submission.Id,
            "RAGStored",
            It.Is<string>(s => s.Contains("2 related documents")),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            ProcessingStage.RAG), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WhenStorageFails_ReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        var context = new ProcessContext
        {
            SubmissionId = submission.Id,
            Submission = submission,
            State = new ProcessState()
        };

        var ragResult = new RAGResult
        {
            StoredSuccessfully = false,
            ErrorMessage = "Storage failed"
        };

        _mockRagAgent.Setup(x => x.StoreDocumentAsync(submission))
            .ReturnsAsync(ragResult);

        _mockAuditService.Setup(x => x.LogActionAsync(
            It.IsAny<Guid>(),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Be("Storage failed");

        _mockAuditService.Verify(x => x.LogActionAsync(
            submission.Id,
            "RAGStorageFailed",
            It.Is<string>(s => s.Contains("Storage failed")),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            ProcessingStage.RAG), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WhenExceptionOccurs_ReturnsFailure()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            RawText = "Test content"
        };

        var context = new ProcessContext
        {
            SubmissionId = submission.Id,
            Submission = submission,
            State = new ProcessState()
        };

        _mockRagAgent.Setup(x => x.StoreDocumentAsync(submission))
            .ThrowsAsync(new Exception("Unexpected error"));

        _mockAuditService.Setup(x => x.LogActionAsync(
            It.IsAny<Guid>(),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Unexpected error");

        _mockAuditService.Verify(x => x.LogActionAsync(
            submission.Id,
            "RAGException",
            It.Is<string>(s => s.Contains("Unexpected error")),
            It.IsAny<string>(),
            It.IsAny<string?>(),
            ProcessingStage.RAG), Times.Once);
    }

    [Fact]
    public void StepName_ReturnsCorrectName()
    {
        // Assert
        _step.StepName.Should().Be("RAG");
    }
}
