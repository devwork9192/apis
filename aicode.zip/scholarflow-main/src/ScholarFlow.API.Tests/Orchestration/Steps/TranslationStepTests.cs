using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Orchestration.Steps;

public class TranslationStepTests
{
    private readonly Mock<ITranslationAgent> _mockTranslationAgent;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<TranslationStep>> _mockLogger;
    private readonly TranslationStep _step;

    public TranslationStepTests()
    {
        _mockTranslationAgent = new Mock<ITranslationAgent>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<TranslationStep>>();

        _mockAuditService.Setup(a => a.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        _step = new TranslationStep(
            _mockTranslationAgent.Object,
            _mockAuditService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public void StepName_ReturnsTranslation()
    {
        _step.StepName.Should().Be("Translation");
    }

    [Fact]
    public async Task ExecuteAsync_WithEnglishText_SkipsTranslation()
    {
        // Arrange
        var context = CreateContext("English text", "English");

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        result.Data!["Translated"].Should().Be(false);
        context.State.TranslatedText.Should().Be(context.State.RawText);

        _mockTranslationAgent.Verify(a => a.TranslateToEnglishAsync(
            It.IsAny<string>(), It.IsAny<string>()), Times.Never);

        _mockAuditService.Verify(a => a.LogActionAsync(
            context.SubmissionId,
            "TranslationSkipped",
            "Document already in English",
            It.IsAny<string>(),
            "TranslationAgent",
            ProcessingStage.Translation), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WithNonEnglishText_TranslatesText()
    {
        // Arrange
        var context = CreateContext("Texto en español", "Spanish");
        var translatedText = "Text in English";

        _mockTranslationAgent.Setup(a => a.TranslateToEnglishAsync(
            It.IsAny<string>(), "Spanish"))
            .ReturnsAsync(translatedText);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        result.Data!["Translated"].Should().Be(true);
        context.State.TranslatedText.Should().Be(translatedText);

        _mockTranslationAgent.Verify(a => a.TranslateToEnglishAsync(
            context.State.RawText, "Spanish"), Times.Once);

        _mockAuditService.Verify(a => a.LogActionAsync(
            context.SubmissionId,
            "TranslationCompleted",
            "Translated from Spanish to English",
            It.IsAny<string>(),
            "TranslationAgent",
            ProcessingStage.Translation), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WithCaseInsensitiveEnglish_SkipsTranslation()
    {
        // Arrange
        var context = CreateContext("English text", "english"); // lowercase

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        result.Data!["Translated"].Should().Be(false);
        _mockTranslationAgent.Verify(a => a.TranslateToEnglishAsync(
            It.IsAny<string>(), It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task ExecuteAsync_WhenTranslationFails_ReturnsFailure()
    {
        // Arrange
        var context = CreateContext("Text", "French");

        _mockTranslationAgent.Setup(a => a.TranslateToEnglishAsync(
            It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(new Exception("Translation service error"));

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Translation service error");
    }

    [Fact]
    public async Task ExecuteAsync_WithNullOrEmptyLanguage_SkipsTranslation()
    {
        // Arrange
        var context = CreateContext("Text", null);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        result.Data!["Translated"].Should().Be(false);
        context.State.TranslatedText.Should().Be(context.State.RawText);
    }

    private ProcessContext CreateContext(string rawText, string? detectedLanguage)
    {
        return new ProcessContext
        {
            SubmissionId = Guid.NewGuid(),
            Submission = new Submission { Id = Guid.NewGuid() },
            State = new ProcessState
            {
                SubmissionId = Guid.NewGuid(),
                RawText = rawText,
                DetectedLanguage = detectedLanguage
            }
        };
    }
}
