using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Orchestration.Steps;

public class MetadataExtractionStepTests
{
    private readonly Mock<IExtractionAgent> _mockExtractionAgent;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<MetadataExtractionStep>> _mockLogger;
    private readonly MetadataExtractionStep _step;

    public MetadataExtractionStepTests()
    {
        _mockExtractionAgent = new Mock<IExtractionAgent>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<MetadataExtractionStep>>();

        _mockAuditService.Setup(a => a.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        _step = new MetadataExtractionStep(
            _mockExtractionAgent.Object,
            _mockAuditService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public void StepName_ReturnsMetadataExtraction()
    {
        _step.StepName.Should().Be("MetadataExtraction");
    }

    [Fact]
    public async Task ExecuteAsync_ExtractsAndUpdatesSubmission()
    {
        // Arrange
        var context = CreateContext("Research paper text", null);
        var extractionResult = new ExtractionResult
        {
            ExtractionSuccessful = true,
            Title = "Machine Learning Research",
            Authors = "John Doe, Jane Smith",
            Abstract = "This paper explores ML techniques",
            Keywords = "machine learning, AI",
            PublicationYear = 2024,
            Journal = "AI Journal"
        };

        _mockExtractionAgent.Setup(a => a.ExtractMetadataAsync(It.IsAny<string>()))
            .ReturnsAsync(extractionResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        context.Submission.Title.Should().Be("Machine Learning Research");
        context.Submission.Authors.Should().Be("John Doe, Jane Smith");
        context.Submission.Abstract.Should().Be("This paper explores ML techniques");
        context.Submission.Keywords.Should().Be("machine learning, AI");
        context.Submission.PublicationYear.Should().Be(2024);
        context.Submission.Journal.Should().Be("AI Journal");
        context.State.ExtractedMetadata.Should().NotBeNullOrEmpty();

        _mockAuditService.Verify(a => a.LogActionAsync(
            context.SubmissionId,
            "MetadataExtracted",
            It.IsAny<string>(),
            It.IsAny<string>(),
            "ExtractionAgent",
            ProcessingStage.Extraction), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_UsesTranslatedText_WhenAvailable()
    {
        // Arrange
        var translatedText = "Translated content";
        var context = CreateContext("Original", translatedText);
        var extractionResult = new ExtractionResult
        {
            ExtractionSuccessful = true,
            Title = "Title"
        };

        _mockExtractionAgent.Setup(a => a.ExtractMetadataAsync(translatedText))
            .ReturnsAsync(extractionResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        _mockExtractionAgent.Verify(a => a.ExtractMetadataAsync(translatedText), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_UsesRawText_WhenTranslatedNotAvailable()
    {
        // Arrange
        var rawText = "Raw content";
        var context = CreateContext(rawText, null);
        var extractionResult = new ExtractionResult
        {
            ExtractionSuccessful = true,
            Title = "Title"
        };

        _mockExtractionAgent.Setup(a => a.ExtractMetadataAsync(rawText))
            .ReturnsAsync(extractionResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        _mockExtractionAgent.Verify(a => a.ExtractMetadataAsync(rawText), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WhenExtractionFails_ReturnsFailure()
    {
        // Arrange
        var context = CreateContext("Text", null);

        _mockExtractionAgent.Setup(a => a.ExtractMetadataAsync(It.IsAny<string>()))
            .ThrowsAsync(new Exception("Extraction error"));

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Extraction error");
    }

    [Fact]
    public async Task ExecuteAsync_WithNullAuthors_HandlesGracefully()
    {
        // Arrange
        var context = CreateContext("Text", null);
        var extractionResult = new ExtractionResult
        {
            ExtractionSuccessful = true,
            Title = "Title",
            Authors = null
        };

        _mockExtractionAgent.Setup(a => a.ExtractMetadataAsync(It.IsAny<string>()))
            .ReturnsAsync(extractionResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        context.Submission.Authors.Should().BeNull();
    }

    [Fact]
    public async Task ExecuteAsync_WithNullKeywords_HandlesGracefully()
    {
        // Arrange
        var context = CreateContext("Text", null);
        var extractionResult = new ExtractionResult
        {
            ExtractionSuccessful = true,
            Title = "Title",
            Keywords = null
        };

        _mockExtractionAgent.Setup(a => a.ExtractMetadataAsync(It.IsAny<string>()))
            .ReturnsAsync(extractionResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        context.Submission.Keywords.Should().BeNull();
    }

    private ProcessContext CreateContext(string rawText, string? translatedText)
    {
        return new ProcessContext
        {
            SubmissionId = Guid.NewGuid(),
            Submission = new Submission { Id = Guid.NewGuid() },
            State = new ProcessState
            {
                SubmissionId = Guid.NewGuid(),
                RawText = rawText,
                TranslatedText = translatedText
            }
        };
    }
}
