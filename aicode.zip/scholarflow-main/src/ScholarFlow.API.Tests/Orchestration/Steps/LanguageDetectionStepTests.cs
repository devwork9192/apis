using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Orchestration.Steps;

public class LanguageDetectionStepTests
{
    private readonly Mock<IPreprocessAgent> _mockPreprocessAgent;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<LanguageDetectionStep>> _mockLogger;
    private readonly LanguageDetectionStep _step;

    public LanguageDetectionStepTests()
    {
        _mockPreprocessAgent = new Mock<IPreprocessAgent>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<LanguageDetectionStep>>();

        _mockAuditService.Setup(a => a.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        _step = new LanguageDetectionStep(
            _mockPreprocessAgent.Object,
            _mockAuditService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public void StepName_ReturnsLanguageDetection()
    {
        _step.StepName.Should().Be("LanguageDetection");
    }

    [Fact]
    public async Task ExecuteAsync_WithValidContext_DetectsLanguage()
    {
        // Arrange
        var context = CreateContext("Test document text in English");
        var expectedLanguage = "English";

        _mockPreprocessAgent.Setup(a => a.DetectLanguageAsync(It.IsAny<string>()))
            .ReturnsAsync(expectedLanguage);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Should().NotBeNull();
        result.Success.Should().BeTrue();
        context.State.DetectedLanguage.Should().Be(expectedLanguage);
        result.Data.Should().ContainKey("Language");
        result.Data!["Language"].Should().Be(expectedLanguage);

        _mockPreprocessAgent.Verify(a => a.DetectLanguageAsync(
            context.State.RawText), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_LogsAuditAction()
    {
        // Arrange
        var context = CreateContext("Test text");
        var language = "Spanish";

        _mockPreprocessAgent.Setup(a => a.DetectLanguageAsync(It.IsAny<string>()))
            .ReturnsAsync(language);

        // Act
        await _step.ExecuteAsync(context);

        // Assert
        _mockAuditService.Verify(a => a.LogActionAsync(
            context.SubmissionId,
            "LanguageDetected",
            $"Language: {language}",
            It.IsAny<string>(),
            "PreprocessAgent",
            ProcessingStage.Preprocess), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WhenAgentFails_ReturnsFailure()
    {
        // Arrange
        var context = CreateContext("Test text");

        _mockPreprocessAgent.Setup(a => a.DetectLanguageAsync(It.IsAny<string>()))
            .ThrowsAsync(new Exception("AI service unavailable"));

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("AI service unavailable");
    }

    [Fact]
    public async Task ExecuteAsync_WithCancellationToken_PassesThrough()
    {
        // Arrange
        var context = CreateContext("Test text");
        var cts = new CancellationTokenSource();

        _mockPreprocessAgent.Setup(a => a.DetectLanguageAsync(It.IsAny<string>()))
            .ReturnsAsync("English");

        // Act
        var result = await _step.ExecuteAsync(context, cts.Token);

        // Assert
        result.Success.Should().BeTrue();
    }

    private ProcessContext CreateContext(string rawText)
    {
        return new ProcessContext
        {
            SubmissionId = Guid.NewGuid(),
            Submission = new Submission { Id = Guid.NewGuid() },
            State = new ProcessState
            {
                SubmissionId = Guid.NewGuid(),
                RawText = rawText
            }
        };
    }
}
