using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Orchestration.Steps;

public class SummaryGenerationStepTests
{
    private readonly Mock<ISummaryAgent> _mockSummaryAgent;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<SummaryGenerationStep>> _mockLogger;
    private readonly SummaryGenerationStep _step;

    public SummaryGenerationStepTests()
    {
        _mockSummaryAgent = new Mock<ISummaryAgent>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<SummaryGenerationStep>>();

        _mockAuditService.Setup(a => a.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        _step = new SummaryGenerationStep(
            _mockSummaryAgent.Object,
            _mockAuditService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public void StepName_ReturnsSummaryGeneration()
    {
        _step.StepName.Should().Be("SummaryGeneration");
    }

    [Fact]
    public async Task ExecuteAsync_WithSuccessfulGeneration_ReturnsSummary()
    {
        // Arrange
        var context = CreateContext();
        var summaryResult = new SummaryResult
        {
            SummarySuccessful = true,
            Summary = "This research paper explores novel applications of machine learning in healthcare diagnostics.",
            SummaryWordCount = 12
        };

        _mockSummaryAgent.Setup(a => a.GenerateSummaryAsync(It.IsAny<Submission>()))
            .ReturnsAsync(summaryResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        context.State.Summary.Should().Be(summaryResult.Summary);
        result.Data!["Summary"].Should().Be(summaryResult.Summary);
        result.Data["WordCount"].Should().Be(12);

        _mockAuditService.Verify(a => a.LogActionAsync(
            context.SubmissionId,
            "SummaryGenerated",
            "Summary created (12 words)",
            It.IsAny<string>(),
            "SummaryAgent",
            ProcessingStage.Summary), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WhenGenerationFails_ReturnsFailure()
    {
        // Arrange
        var context = CreateContext();

        _mockSummaryAgent.Setup(a => a.GenerateSummaryAsync(It.IsAny<Submission>()))
            .ThrowsAsync(new Exception("Summary generation error"));

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Summary generation error");
    }

    [Fact]
    public async Task ExecuteAsync_PassesSubmissionToAgent()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Research Title",
            Abstract = "Abstract text"
        };
        var context = new ProcessContext
        {
            SubmissionId = submission.Id,
            Submission = submission,
            State = new ProcessState { SubmissionId = submission.Id }
        };

        var summaryResult = new SummaryResult
        {
            SummarySuccessful = true,
            Summary = "Summary",
            SummaryWordCount = 1
        };

        _mockSummaryAgent.Setup(a => a.GenerateSummaryAsync(submission))
            .ReturnsAsync(summaryResult);

        // Act
        await _step.ExecuteAsync(context);

        // Assert
        _mockSummaryAgent.Verify(a => a.GenerateSummaryAsync(submission), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WithNullSummary_HandlesGracefully()
    {
        // Arrange
        var context = CreateContext();
        var summaryResult = new SummaryResult
        {
            SummarySuccessful = true,
            Summary = null,
            SummaryWordCount = 0
        };

        _mockSummaryAgent.Setup(a => a.GenerateSummaryAsync(It.IsAny<Submission>()))
            .ReturnsAsync(summaryResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        context.State.Summary.Should().BeNull();
        result.Data!["Summary"].Should().Be(string.Empty);
    }

    [Fact]
    public async Task ExecuteAsync_WithCancellationToken_PassesThrough()
    {
        // Arrange
        var context = CreateContext();
        var cts = new CancellationTokenSource();
        var summaryResult = new SummaryResult
        {
            SummarySuccessful = true,
            Summary = "Summary",
            SummaryWordCount = 1
        };

        _mockSummaryAgent.Setup(a => a.GenerateSummaryAsync(It.IsAny<Submission>()))
            .ReturnsAsync(summaryResult);

        // Act
        var result = await _step.ExecuteAsync(context, cts.Token);

        // Assert
        result.Success.Should().BeTrue();
    }

    private ProcessContext CreateContext()
    {
        return new ProcessContext
        {
            SubmissionId = Guid.NewGuid(),
            Submission = new Submission
            {
                Id = Guid.NewGuid(),
                Title = "Test Title",
                Abstract = "Test Abstract"
            },
            State = new ProcessState { SubmissionId = Guid.NewGuid() }
        };
    }
}
