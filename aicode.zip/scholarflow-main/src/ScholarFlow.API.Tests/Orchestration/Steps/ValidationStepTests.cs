using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Agents;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Orchestration.Steps;

public class ValidationStepTests
{
    private readonly Mock<IValidationAgent> _mockValidationAgent;
    private readonly Mock<IAuditService> _mockAuditService;
    private readonly Mock<ILogger<ValidationStep>> _mockLogger;
    private readonly ValidationStep _step;

    public ValidationStepTests()
    {
        _mockValidationAgent = new Mock<IValidationAgent>();
        _mockAuditService = new Mock<IAuditService>();
        _mockLogger = new Mock<ILogger<ValidationStep>>();

        _mockAuditService.Setup(a => a.LogActionAsync(
            It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(),
            It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ProcessingStage?>()))
            .Returns(Task.CompletedTask);

        _step = new ValidationStep(
            _mockValidationAgent.Object,
            _mockAuditService.Object,
            _mockLogger.Object);
    }

    [Fact]
    public void StepName_ReturnsValidation()
    {
        _step.StepName.Should().Be("Validation");
    }

    [Fact]
    public async Task ExecuteAsync_WithValidSubmission_ReturnsSuccess()
    {
        // Arrange
        var context = CreateContext();
        var validationResult = new ValidationResult
        {
            IsValid = true,
            Errors = new List<string>()
        };

        _mockValidationAgent.Setup(a => a.ValidateAsync(It.IsAny<Submission>()))
            .ReturnsAsync(validationResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        context.State.IsValid.Should().BeTrue();
        context.State.ValidationResult.Should().Be("Valid");
        result.Data!["IsValid"].Should().Be(true);

        _mockAuditService.Verify(a => a.LogActionAsync(
            context.SubmissionId,
            "ValidationPassed",
            "All validation checks passed",
            It.IsAny<string>(),
            "ValidationAgent",
            ProcessingStage.Validation), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WithInvalidSubmission_ReturnsSuccessButMarksInvalid()
    {
        // Arrange
        var context = CreateContext();
        var validationResult = new ValidationResult
        {
            IsValid = false,
            Errors = new List<string> { "Missing title", "Missing abstract" }
        };

        _mockValidationAgent.Setup(a => a.ValidateAsync(It.IsAny<Submission>()))
            .ReturnsAsync(validationResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue(); // Step succeeds even if validation fails
        context.State.IsValid.Should().BeFalse();
        context.State.ValidationResult.Should().Contain("Missing title");
        context.State.ValidationResult.Should().Contain("Missing abstract");
        result.Data!["IsValid"].Should().Be(false);

        _mockAuditService.Verify(a => a.LogActionAsync(
            context.SubmissionId,
            "ValidationFailed",
            It.Is<string>(s => s.Contains("Missing title")),
            It.IsAny<string>(),
            "ValidationAgent",
            ProcessingStage.Validation), Times.Once);
    }

    [Fact]
    public async Task ExecuteAsync_WhenValidationThrows_ReturnsFailure()
    {
        // Arrange
        var context = CreateContext();

        _mockValidationAgent.Setup(a => a.ValidateAsync(It.IsAny<Submission>()))
            .ThrowsAsync(new Exception("Validation agent error"));

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeFalse();
        result.ErrorMessage.Should().Contain("Validation agent error");
    }

    [Fact]
    public async Task ExecuteAsync_WithNullErrors_HandlesGracefully()
    {
        // Arrange
        var context = CreateContext();
        var validationResult = new ValidationResult
        {
            IsValid = false,
            Errors = null!
        };

        _mockValidationAgent.Setup(a => a.ValidateAsync(It.IsAny<Submission>()))
            .ReturnsAsync(validationResult);

        // Act
        var result = await _step.ExecuteAsync(context);

        // Assert
        result.Success.Should().BeTrue();
        context.State.IsValid.Should().BeFalse();
    }

    [Fact]
    public async Task ExecuteAsync_PassesSubmissionToAgent()
    {
        // Arrange
        var submission = new Submission
        {
            Id = Guid.NewGuid(),
            Title = "Test Title"
        };
        var context = new ProcessContext
        {
            SubmissionId = submission.Id,
            Submission = submission,
            State = new ProcessState { SubmissionId = submission.Id }
        };

        var validationResult = new ValidationResult { IsValid = true };
        _mockValidationAgent.Setup(a => a.ValidateAsync(submission))
            .ReturnsAsync(validationResult);

        // Act
        await _step.ExecuteAsync(context);

        // Assert
        _mockValidationAgent.Verify(a => a.ValidateAsync(submission), Times.Once);
    }

    private ProcessContext CreateContext()
    {
        return new ProcessContext
        {
            SubmissionId = Guid.NewGuid(),
            Submission = new Submission { Id = Guid.NewGuid() },
            State = new ProcessState { SubmissionId = Guid.NewGuid() }
        };
    }
}
