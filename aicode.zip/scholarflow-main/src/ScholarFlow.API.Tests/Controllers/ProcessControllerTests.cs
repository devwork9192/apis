using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Common;
using ScholarFlow.API.Controllers;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Controllers;

public class ProcessControllerTests
{
    private readonly Mock<IProcessService> _mockProcessService;
    private readonly Mock<ILogger<ProcessController>> _mockLogger;
    private readonly ProcessController _controller;

    public ProcessControllerTests()
    {
        _mockProcessService = new Mock<IProcessService>();
        _mockLogger = new Mock<ILogger<ProcessController>>();
        _controller = new ProcessController(_mockProcessService.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task ProcessSubmission_WithValidFile_ReturnsOkWithSubmissionResponse()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", 1024);
        var uploadedBy = "testuser";
        var expectedResponse = new SubmissionResponse
        {
            Id = Guid.NewGuid(),
            Status = "Summarized",
            Stage = "Summary",
            Message = "Submission processed successfully"
        };

        _mockProcessService
            .Setup(x => x.ProcessSubmissionAsync(file, uploadedBy))
            .ReturnsAsync(expectedResponse);

        // Act
        var result = await _controller.ProcessSubmission(file, uploadedBy);

        // Assert
        result.Result.Should().BeOfType<OkObjectResult>();
        var okResult = result.Result as OkObjectResult;
        var response = okResult!.Value as SubmissionResponse;
        response.Should().BeEquivalentTo(expectedResponse);

        _mockProcessService.Verify(x => x.ProcessSubmissionAsync(file, uploadedBy), Times.Once);
    }

    [Fact]
    public async Task ProcessSubmission_WithNullFile_ReturnsBadRequest()
    {
        // Act
        var result = await _controller.ProcessSubmission(null!, "testuser");

        // Assert
        result.Result.Should().BeOfType<BadRequestObjectResult>();
        var badRequestResult = result.Result as BadRequestObjectResult;
        badRequestResult!.Value.Should().BeEquivalentTo(new { error = AppConstants.Messages.NoFileProvided });

        _mockProcessService.Verify(x => x.ProcessSubmissionAsync(It.IsAny<IFormFile>(), It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task ProcessSubmission_WithNullUploadedBy_UsesSystemDefault()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", 1024);
        var expectedResponse = new SubmissionResponse
        {
            Id = Guid.NewGuid(),
            Status = "Summarized",
            Stage = "Summary",
            Message = "Submission processed successfully"
        };

        _mockProcessService
            .Setup(x => x.ProcessSubmissionAsync(file, AppConstants.Users.System))
            .ReturnsAsync(expectedResponse);

        // Act
        var result = await _controller.ProcessSubmission(file, null);

        // Assert
        result.Result.Should().BeOfType<OkObjectResult>();
        _mockProcessService.Verify(x => x.ProcessSubmissionAsync(file, AppConstants.Users.System), Times.Once);
    }

    [Fact]
    public async Task ProcessSubmission_WhenServiceThrowsArgumentException_ReturnsBadRequest()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", 1024);
        var errorMessage = "Invalid file format";

        _mockProcessService
            .Setup(x => x.ProcessSubmissionAsync(file, It.IsAny<string>()))
            .ThrowsAsync(new ArgumentException(errorMessage));

        // Act
        var result = await _controller.ProcessSubmission(file, "testuser");

        // Assert
        result.Result.Should().BeOfType<BadRequestObjectResult>();
        var badRequestResult = result.Result as BadRequestObjectResult;
        badRequestResult!.Value.Should().BeEquivalentTo(new { error = errorMessage });
    }

    [Fact]
    public async Task ProcessSubmission_WhenServiceThrowsInvalidOperationException_ReturnsInternalServerError()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", 1024);
        var errorMessage = "Processing failed";

        _mockProcessService
            .Setup(x => x.ProcessSubmissionAsync(file, It.IsAny<string>()))
            .ThrowsAsync(new InvalidOperationException(errorMessage));

        // Act
        var result = await _controller.ProcessSubmission(file, "testuser");

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
        objectResult.Value.Should().BeEquivalentTo(new { error = errorMessage });
    }

    [Fact]
    public async Task ProcessSubmission_WhenServiceThrowsUnexpectedException_ReturnsInternalServerErrorWithGenericMessage()
    {
        // Arrange
        var file = CreateMockFile("test.pdf", 1024);

        _mockProcessService
            .Setup(x => x.ProcessSubmissionAsync(file, It.IsAny<string>()))
            .ThrowsAsync(new Exception("Unexpected error"));

        // Act
        var result = await _controller.ProcessSubmission(file, "testuser");

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(StatusCodes.Status500InternalServerError);
        objectResult.Value.Should().BeEquivalentTo(new { error = "An error occurred while processing the submission" });
    }

    private static IFormFile CreateMockFile(string fileName, long length)
    {
        var fileMock = new Mock<IFormFile>();
        fileMock.Setup(f => f.FileName).Returns(fileName);
        fileMock.Setup(f => f.Length).Returns(length);
        fileMock.Setup(f => f.ContentType).Returns("application/pdf");
        return fileMock.Object;
    }
}
