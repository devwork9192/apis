using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Common;
using ScholarFlow.API.Controllers;
using ScholarFlow.API.DTOs.Health;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Controllers;

public class HealthControllerTests
{
    private readonly Mock<IHealthService> _mockHealthService;
    private readonly Mock<ILogger<HealthController>> _mockLogger;
    private readonly HealthController _controller;

    public HealthControllerTests()
    {
        _mockHealthService = new Mock<IHealthService>();
        _mockLogger = new Mock<ILogger<HealthController>>();
        _controller = new HealthController(_mockHealthService.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task GetHealth_WhenAllComponentsHealthy_ReturnsOkWithHealthyStatus()
    {
        // Arrange
        var healthResponse = new HealthCheckResponse
        {
            Status = AppConstants.Status.Healthy,
            Timestamp = DateTime.UtcNow,
            Components = new Dictionary<string, ComponentHealth>
            {
                [AppConstants.HealthComponents.Database] = new ComponentHealth
                {
                    Status = AppConstants.Status.Healthy,
                    Message = "Connected"
                },
                [AppConstants.HealthComponents.AIService] = new ComponentHealth
                {
                    Status = AppConstants.Status.Healthy,
                    Message = "Responding"
                }
            }
        };

        _mockHealthService
            .Setup(x => x.CheckHealthAsync())
            .ReturnsAsync(healthResponse);

        // Act
        var result = await _controller.GetHealth();

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(StatusCodes.Status200OK);
        
        var response = objectResult.Value as HealthCheckResponse;
        response!.Status.Should().Be(AppConstants.Status.Healthy);
        response.Components[AppConstants.HealthComponents.Database].Status.Should().Be(AppConstants.Status.Healthy);
        response.Components[AppConstants.HealthComponents.AIService].Status.Should().Be(AppConstants.Status.Healthy);
    }

    [Fact]
    public async Task GetHealth_WhenSomeComponentsUnhealthy_ReturnsServiceUnavailableWithUnhealthyStatus()
    {
        // Arrange
        var healthResponse = new HealthCheckResponse
        {
            Status = AppConstants.Status.Unhealthy,
            Timestamp = DateTime.UtcNow,
            Components = new Dictionary<string, ComponentHealth>
            {
                [AppConstants.HealthComponents.Database] = new ComponentHealth
                {
                    Status = AppConstants.Status.Healthy,
                    Message = "Connected"
                },
                [AppConstants.HealthComponents.AIService] = new ComponentHealth
                {
                    Status = AppConstants.Status.Unhealthy,
                    Message = "Connection failed"
                }
            }
        };

        _mockHealthService
            .Setup(x => x.CheckHealthAsync())
            .ReturnsAsync(healthResponse);

        // Act
        var result = await _controller.GetHealth();

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(StatusCodes.Status503ServiceUnavailable);
        
        var response = objectResult.Value as HealthCheckResponse;
        response!.Status.Should().Be(AppConstants.Status.Unhealthy);
        response.Components[AppConstants.HealthComponents.Database].Status.Should().Be(AppConstants.Status.Healthy);
        response.Components[AppConstants.HealthComponents.AIService].Status.Should().Be(AppConstants.Status.Unhealthy);
    }

    [Fact]
    public async Task GetHealth_WhenExceptionThrown_ReturnsInternalServerError()
    {
        // Arrange
        _mockHealthService
            .Setup(x => x.CheckHealthAsync())
            .ThrowsAsync(new Exception("Health check failed"));

        // Act
        var result = await _controller.GetHealth();

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(AppConstants.HttpStatusCodes.InternalServerError);
        
        var response = objectResult.Value as HealthCheckResponse;
        response!.Status.Should().Be(AppConstants.Status.Unhealthy);
        response.Components[AppConstants.HealthComponents.System].Status.Should().Be(AppConstants.Status.Unhealthy);
    }
}
