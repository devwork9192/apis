using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Controllers;
using ScholarFlow.API.DTOs.HumanReview;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Controllers;

public class HumanReviewControllerTests
{
    private readonly Mock<IHumanReviewService> _mockReviewService;
    private readonly Mock<ILogger<HumanReviewController>> _mockLogger;
    private readonly HumanReviewController _controller;

    public HumanReviewControllerTests()
    {
        _mockReviewService = new Mock<IHumanReviewService>();
        _mockLogger = new Mock<ILogger<HumanReviewController>>();
        _controller = new HumanReviewController(_mockReviewService.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task GetPendingReviews_ReturnsOkWithList()
    {
        // Arrange
        var pendingReviews = new List<ReviewSummaryResponse>
        {
            new ReviewSummaryResponse
            {
                SubmissionId = Guid.NewGuid(),
                FileName = "test.pdf",
                RequiresHumanReview = true,
                PlagiarismScore = 0.65
            }
        };
        _mockReviewService.Setup(s => s.GetPendingReviewsAsync())
            .ReturnsAsync(pendingReviews);

        // Act
        var result = await _controller.GetPendingReviews();

        // Assert
        var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
        var returnedReviews = okResult.Value.Should().BeAssignableTo<List<ReviewSummaryResponse>>().Subject;
        returnedReviews.Should().HaveCount(1);
        returnedReviews[0].PlagiarismScore.Should().Be(0.65);
    }

    [Fact]
    public async Task GetReviewSummary_WithValidId_ReturnsOk()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var summary = new ReviewSummaryResponse
        {
            SubmissionId = submissionId,
            FileName = "test.pdf",
            RequiresHumanReview = true
        };
        _mockReviewService.Setup(s => s.GetReviewSummaryAsync(submissionId))
            .ReturnsAsync(summary);

        // Act
        var result = await _controller.GetReviewSummary(submissionId);

        // Assert
        var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
        var returnedSummary = okResult.Value.Should().BeAssignableTo<ReviewSummaryResponse>().Subject;
        returnedSummary.SubmissionId.Should().Be(submissionId);
    }

    [Fact]
    public async Task GetReviewSummary_WithInvalidId_ReturnsNotFound()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockReviewService.Setup(s => s.GetReviewSummaryAsync(submissionId))
            .ReturnsAsync((ReviewSummaryResponse?)null);

        // Act
        var result = await _controller.GetReviewSummary(submissionId);

        // Assert
        result.Result.Should().BeOfType<NotFoundObjectResult>();
    }

    [Fact]
    public async Task ApproveSubmission_WithValidRequest_ReturnsOk()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new ApproveRequest
        {
            ReviewedBy = "admin@test.com",
            Notes = "Looks good"
        };
        var response = new ReviewResponse
        {
            SubmissionId = submissionId,
            Status = SubmissionStatus.Approved,
            Message = "Submission approved successfully",
            ReviewedBy = "admin@test.com",
            ReviewedAt = DateTime.UtcNow
        };
        _mockReviewService.Setup(s => s.ApproveSubmissionAsync(submissionId, request))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.ApproveSubmission(submissionId, request);

        // Assert
        var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
        var returnedResponse = okResult.Value.Should().BeAssignableTo<ReviewResponse>().Subject;
        returnedResponse.Status.Should().Be(SubmissionStatus.Approved);
        returnedResponse.ReviewedBy.Should().Be("admin@test.com");
    }

    [Fact]
    public async Task ApproveSubmission_WithInvalidId_ReturnsNotFound()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new ApproveRequest { ReviewedBy = "admin@test.com" };
        _mockReviewService.Setup(s => s.ApproveSubmissionAsync(submissionId, request))
            .ReturnsAsync((ReviewResponse?)null);

        // Act
        var result = await _controller.ApproveSubmission(submissionId, request);

        // Assert
        result.Result.Should().BeOfType<NotFoundObjectResult>();
    }

    [Fact]
    public async Task RejectSubmission_WithValidRequest_ReturnsOk()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new RejectRequest
        {
            ReviewedBy = "admin@test.com",
            RejectionReason = "Plagiarism detected in multiple sections"
        };
        var response = new ReviewResponse
        {
            SubmissionId = submissionId,
            Status = SubmissionStatus.Rejected,
            Message = "Submission rejected",
            ReviewedBy = "admin@test.com",
            ReviewedAt = DateTime.UtcNow
        };
        _mockReviewService.Setup(s => s.RejectSubmissionAsync(submissionId, request))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.RejectSubmission(submissionId, request);

        // Assert
        var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
        var returnedResponse = okResult.Value.Should().BeAssignableTo<ReviewResponse>().Subject;
        returnedResponse.Status.Should().Be(SubmissionStatus.Rejected);
    }

    [Fact]
    public async Task OverrideValidation_WithValidScores_ReturnsOk()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new OverrideRequest
        {
            ReviewedBy = "admin@test.com",
            OverridePlagiarismScore = 0.30,
            OverrideToxicityScore = 0.10,
            OverrideReason = "Manual review confirmed originality"
        };
        var response = new ReviewResponse
        {
            SubmissionId = submissionId,
            Status = SubmissionStatus.Validated,
            Message = "Validation overridden",
            ReviewedBy = "admin@test.com",
            ReviewedAt = DateTime.UtcNow
        };
        _mockReviewService.Setup(s => s.OverrideValidationAsync(submissionId, request))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.OverrideValidation(submissionId, request);

        // Assert
        var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
        var returnedResponse = okResult.Value.Should().BeAssignableTo<ReviewResponse>().Subject;
        returnedResponse.ReviewedBy.Should().Be("admin@test.com");
    }

    [Fact]
    public async Task OverrideValidation_WithInvalidPlagiarismScore_ReturnsBadRequest()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new OverrideRequest
        {
            ReviewedBy = "admin@test.com",
            OverridePlagiarismScore = 1.5, // Invalid: > 1
            OverrideReason = "Test reason"
        };

        // Act
        var result = await _controller.OverrideValidation(submissionId, request);

        // Assert
        result.Result.Should().BeOfType<BadRequestObjectResult>();
    }

    [Fact]
    public async Task OverrideValidation_WithInvalidToxicityScore_ReturnsBadRequest()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new OverrideRequest
        {
            ReviewedBy = "admin@test.com",
            OverrideToxicityScore = -0.1, // Invalid: < 0
            OverrideReason = "Test reason"
        };

        // Act
        var result = await _controller.OverrideValidation(submissionId, request);

        // Assert
        result.Result.Should().BeOfType<BadRequestObjectResult>();
    }

    [Fact]
    public async Task OverrideValidation_WithApproveAnyway_ReturnsOk()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new OverrideRequest
        {
            ReviewedBy = "admin@test.com",
            ApproveAnyway = true,
            OverrideReason = "Executive decision to approve"
        };
        var response = new ReviewResponse
        {
            SubmissionId = submissionId,
            Status = SubmissionStatus.Approved,
            Message = "Validation overridden: Marked as valid despite validation errors",
            ReviewedBy = "admin@test.com",
            ReviewedAt = DateTime.UtcNow
        };
        _mockReviewService.Setup(s => s.OverrideValidationAsync(submissionId, request))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.OverrideValidation(submissionId, request);

        // Assert
        var okResult = result.Result.Should().BeOfType<OkObjectResult>().Subject;
        var returnedResponse = okResult.Value.Should().BeAssignableTo<ReviewResponse>().Subject;
        returnedResponse.Status.Should().Be(SubmissionStatus.Approved);
    }
}
