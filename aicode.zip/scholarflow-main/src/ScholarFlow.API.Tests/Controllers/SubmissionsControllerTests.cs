using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Common;
using ScholarFlow.API.Controllers;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Tests.Controllers;

public class SubmissionsControllerTests
{
    private readonly Mock<ISubmissionService> _mockSubmissionService;
    private readonly Mock<IReportService> _mockReportService;
    private readonly Mock<ILogger<SubmissionsController>> _mockLogger;
    private readonly SubmissionsController _controller;

    public SubmissionsControllerTests()
    {
        _mockSubmissionService = new Mock<ISubmissionService>();
        _mockReportService = new Mock<IReportService>();
        _mockLogger = new Mock<ILogger<SubmissionsController>>();
        _controller = new SubmissionsController(
            _mockSubmissionService.Object, 
            _mockReportService.Object,
            _mockLogger.Object);
    }

    #region GetAllSubmissions Tests

    [Fact]
    public async Task GetAllSubmissions_ReturnsOkWithSubmissionsList()
    {
        // Arrange
        var submissions = new List<SubmissionListResponse>
        {
            new SubmissionListResponse
            {
                Id = Guid.NewGuid(),
                FileName = "test1.pdf",
                Status = "Summarized",
                UploadedAt = DateTime.UtcNow
            },
            new SubmissionListResponse
            {
                Id = Guid.NewGuid(),
                FileName = "test2.pdf",
                Status = "Preprocessing",
                UploadedAt = DateTime.UtcNow
            }
        };

        _mockSubmissionService
            .Setup(x => x.GetAllAsync())
            .ReturnsAsync(submissions);

        // Act
        var result = await _controller.GetAllSubmissions();

        // Assert
        result.Result.Should().BeOfType<OkObjectResult>();
        var okResult = result.Result as OkObjectResult;
        var returnedSubmissions = okResult!.Value as List<SubmissionListResponse>;
        returnedSubmissions.Should().HaveCount(2);
        returnedSubmissions.Should().BeEquivalentTo(submissions);

        _mockSubmissionService.Verify(x => x.GetAllAsync(), Times.Once);
    }

    [Fact]
    public async Task GetAllSubmissions_WhenServiceThrowsException_ReturnsInternalServerError()
    {
        // Arrange
        _mockSubmissionService
            .Setup(x => x.GetAllAsync())
            .ThrowsAsync(new Exception("Database error"));

        // Act
        var result = await _controller.GetAllSubmissions();

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(500);
    }

    #endregion

    #region GetSubmissionStatus Tests

    [Fact]
    public async Task GetSubmissionStatus_WhenSubmissionExists_ReturnsOkWithStatus()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var statusResponse = new SubmissionStatusResponse
        {
            Id = submissionId,
            FileName = "test.pdf",
            Status = SubmissionStatus.Uploaded.ToString(),
            CurrentStage = ProcessingStage.Upload.ToString(),
            DetectedLanguage = "English"
        };

        _mockSubmissionService
            .Setup(x => x.GetStatusAsync(submissionId))
            .ReturnsAsync(statusResponse);

        // Act
        var result = await _controller.GetSubmissionStatus(submissionId);

        // Assert
        result.Result.Should().BeOfType<OkObjectResult>();
        var okResult = result.Result as OkObjectResult;
        var response = okResult!.Value as SubmissionStatusResponse;
        response.Should().BeEquivalentTo(statusResponse);

        _mockSubmissionService.Verify(x => x.GetStatusAsync(submissionId), Times.Once);
    }

    [Fact]
    public async Task GetSubmissionStatus_WhenSubmissionNotFound_ReturnsNotFound()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockSubmissionService
            .Setup(x => x.GetStatusAsync(submissionId))
            .ReturnsAsync((SubmissionStatusResponse?)null);

        // Act
        var result = await _controller.GetSubmissionStatus(submissionId);

        // Assert
        result.Result.Should().BeOfType<NotFoundObjectResult>();
        var notFoundResult = result.Result as NotFoundObjectResult;
        notFoundResult!.Value.Should().BeEquivalentTo(new { error = AppConstants.Messages.SubmissionNotFound });
    }

    [Fact]
    public async Task GetSubmissionStatus_WhenServiceThrowsException_ReturnsInternalServerError()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockSubmissionService
            .Setup(x => x.GetStatusAsync(submissionId))
            .ThrowsAsync(new Exception("Database error"));

        // Act
        var result = await _controller.GetSubmissionStatus(submissionId);

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(500);
    }

    #endregion

    #region GetSubmission Tests

    [Fact]
    public async Task GetSubmission_WhenSubmissionExists_ReturnsOkWithSubmission()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission
        {
            Id = submissionId,
            FileName = "test.pdf",
            Status = SubmissionStatus.Summarized,
            DetectedLanguage = "English",
            WasTranslated = false,
            Summary = "Test summary",
            UploadedAt = DateTime.UtcNow
        };

        _mockSubmissionService
            .Setup(x => x.GetByIdAsync(submissionId))
            .ReturnsAsync(submission);

        // Act
        var result = await _controller.GetSubmission(submissionId);

        // Assert
        result.Result.Should().BeOfType<OkObjectResult>();
        var okResult = result.Result as OkObjectResult;
        var returnedSubmission = okResult!.Value as Submission;
        returnedSubmission.Should().BeEquivalentTo(submission);

        _mockSubmissionService.Verify(x => x.GetByIdAsync(submissionId), Times.Once);
    }

    [Fact]
    public async Task GetSubmission_WhenSubmissionNotFound_ReturnsNotFound()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockSubmissionService
            .Setup(x => x.GetByIdAsync(submissionId))
            .ReturnsAsync((Submission?)null);

        // Act
        var result = await _controller.GetSubmission(submissionId);

        // Assert
        result.Result.Should().BeOfType<NotFoundObjectResult>();
        var notFoundResult = result.Result as NotFoundObjectResult;
        notFoundResult!.Value.Should().BeEquivalentTo(new { error = AppConstants.Messages.SubmissionNotFound });
    }

    [Fact]
    public async Task GetSubmission_WhenServiceThrowsException_ReturnsInternalServerError()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockSubmissionService
            .Setup(x => x.GetByIdAsync(submissionId))
            .ThrowsAsync(new Exception("Database error"));

        // Act
        var result = await _controller.GetSubmission(submissionId);

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(500);
    }

    #endregion

    #region GetSubmissionAudit Tests

    [Fact]
    public async Task GetSubmissionAudit_WhenSubmissionExists_ReturnsOkWithAuditLogs()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var submission = new Submission { Id = submissionId, FileName = "test.pdf" };
        var auditLogs = new List<AuditLog>
        {
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = submissionId,
                Action = "FileUploaded",
                Timestamp = DateTime.UtcNow,
                PerformedBy = "testuser"
            },
            new AuditLog
            {
                Id = Guid.NewGuid(),
                SubmissionId = submissionId,
                Action = "ProcessingStarted",
                Timestamp = DateTime.UtcNow,
                PerformedBy = "system"
            }
        };

        _mockSubmissionService
            .Setup(x => x.GetByIdAsync(submissionId))
            .ReturnsAsync(submission);

        _mockSubmissionService
            .Setup(x => x.GetAuditLogsAsync(submissionId))
            .ReturnsAsync(auditLogs);

        // Act
        var result = await _controller.GetSubmissionAudit(submissionId);

        // Assert
        result.Result.Should().BeOfType<OkObjectResult>();
        var okResult = result.Result as OkObjectResult;
        var returnedLogs = okResult!.Value as List<AuditLog>;
        returnedLogs.Should().HaveCount(2);
        returnedLogs.Should().BeEquivalentTo(auditLogs);

        _mockSubmissionService.Verify(x => x.GetByIdAsync(submissionId), Times.Once);
        _mockSubmissionService.Verify(x => x.GetAuditLogsAsync(submissionId), Times.Once);
    }

    [Fact]
    public async Task GetSubmissionAudit_WhenSubmissionNotFound_ReturnsNotFound()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockSubmissionService
            .Setup(x => x.GetByIdAsync(submissionId))
            .ReturnsAsync((Submission?)null);

        // Act
        var result = await _controller.GetSubmissionAudit(submissionId);

        // Assert
        result.Result.Should().BeOfType<NotFoundObjectResult>();
        var notFoundResult = result.Result as NotFoundObjectResult;
        notFoundResult!.Value.Should().BeEquivalentTo(new { error = AppConstants.Messages.SubmissionNotFound });

        _mockSubmissionService.Verify(x => x.GetAuditLogsAsync(It.IsAny<Guid>()), Times.Never);
    }

    [Fact]
    public async Task GetSubmissionAudit_WhenServiceThrowsException_ReturnsInternalServerError()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockSubmissionService
            .Setup(x => x.GetByIdAsync(submissionId))
            .ThrowsAsync(new Exception("Database error"));

        // Act
        var result = await _controller.GetSubmissionAudit(submissionId);

        // Assert
        result.Result.Should().BeOfType<ObjectResult>();
        var objectResult = result.Result as ObjectResult;
        objectResult!.StatusCode.Should().Be(500);
    }

    #endregion
}
