using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ScholarFlow.API.Controllers;
using ScholarFlow.API.Services;
using ScholarFlow.API.DTOs.Chat;

namespace ScholarFlow.API.Tests.Controllers;

public class ChatControllerTests
{
    private readonly Mock<IChatService> _mockChatService;
    private readonly Mock<ILogger<ChatController>> _mockLogger;
    private readonly ChatController _controller;

    public ChatControllerTests()
    {
        _mockChatService = new Mock<IChatService>();
        _mockLogger = new Mock<ILogger<ChatController>>();
        _controller = new ChatController(_mockChatService.Object, _mockLogger.Object);
    }

    [Fact]
    public async Task AskQuestion_ValidRequest_ReturnsOkWithResponse()
    {
        // Arrange
        var request = new ChatRequest
        {
            Query = "What is AI?",
            Language = "en",
            TopK = 5
        };

        var response = new ChatResponse
        {
            Answer = "AI is artificial intelligence...",
            DetectedLanguage = "en",
            Sources = new List<SourceReference>(),
            CitedSubmissions = new List<Guid>()
        };

        _mockChatService.Setup(x => x.AskQuestionAsync(request))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.AskQuestion(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedResponse = Assert.IsType<ChatResponse>(okResult.Value);
        Assert.Equal(response.Answer, returnedResponse.Answer);
    }

    [Fact]
    public async Task AskQuestion_InvalidModelState_ReturnsBadRequest()
    {
        // Arrange
        var request = new ChatRequest { Query = "" }; // Invalid - query required
        _controller.ModelState.AddModelError("Query", "Required");

        // Act
        var result = await _controller.AskQuestion(request);

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task AskQuestion_ServiceThrowsException_ReturnsInternalServerError()
    {
        // Arrange
        var request = new ChatRequest { Query = "Test query" };
        _mockChatService.Setup(x => x.AskQuestionAsync(request))
            .ThrowsAsync(new Exception("Service error"));

        // Act
        var result = await _controller.AskQuestion(request);

        // Assert
        var statusResult = Assert.IsType<ObjectResult>(result.Result);
        Assert.Equal(500, statusResult.StatusCode);
    }

    [Fact]
    public async Task AskAboutSubmission_ValidRequest_ReturnsOkWithResponse()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new ChatRequest { Query = "Explain this paper" };
        
        var response = new ChatResponse
        {
            Answer = "This paper discusses...",
            DetectedLanguage = "en",
            Sources = new List<SourceReference>
            {
                new SourceReference { SubmissionId = submissionId, Title = "Paper Title" }
            },
            CitedSubmissions = new List<Guid> { submissionId }
        };

        _mockChatService.Setup(x => x.AskQuestionAsync(It.Is<ChatRequest>(r => r.SubmissionId == submissionId)))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.AskAboutSubmission(submissionId, request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedResponse = Assert.IsType<ChatResponse>(okResult.Value);
        Assert.Equal(response.Answer, returnedResponse.Answer);
        Assert.Contains(submissionId, returnedResponse.CitedSubmissions);
    }

    [Fact]
    public async Task AskAboutSubmission_NoResults_ReturnsNotFound()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new ChatRequest { Query = "About this paper" };
        
        var response = new ChatResponse
        {
            Answer = "Submission not found",
            DetectedLanguage = "en",
            Sources = new List<SourceReference>(),
            CitedSubmissions = new List<Guid>()
        };

        _mockChatService.Setup(x => x.AskQuestionAsync(It.IsAny<ChatRequest>()))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.AskAboutSubmission(submissionId, request);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result.Result);
    }

    [Fact]
    public async Task AskAboutSubmission_InvalidModelState_ReturnsBadRequest()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var request = new ChatRequest { Query = "" };
        _controller.ModelState.AddModelError("Query", "Required");

        // Act
        var result = await _controller.AskAboutSubmission(submissionId, request);

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetChatHistory_ValidSubmissionId_ReturnsOkWithHistory()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var history = new ChatHistoryResponse
        {
            SubmissionId = submissionId,
            Messages = new List<ChatMessageDto>
            {
                new ChatMessageDto
                {
                    Id = Guid.NewGuid(),
                    Role = "user",
                    Content = "Question",
                    Language = "en",
                    Timestamp = DateTime.UtcNow
                },
                new ChatMessageDto
                {
                    Id = Guid.NewGuid(),
                    Role = "assistant",
                    Content = "Answer",
                    Language = "en",
                    Timestamp = DateTime.UtcNow
                }
            }
        };

        _mockChatService.Setup(x => x.GetChatHistoryAsync(submissionId))
            .ReturnsAsync(history);

        // Act
        var result = await _controller.GetChatHistory(submissionId);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedHistory = Assert.IsType<ChatHistoryResponse>(okResult.Value);
        Assert.Equal(2, returnedHistory.Messages.Count);
        Assert.Equal(submissionId, returnedHistory.SubmissionId);
    }

    [Fact]
    public async Task GetChatHistory_NoHistory_ReturnsEmptyList()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        var history = new ChatHistoryResponse
        {
            SubmissionId = submissionId,
            Messages = new List<ChatMessageDto>()
        };

        _mockChatService.Setup(x => x.GetChatHistoryAsync(submissionId))
            .ReturnsAsync(history);

        // Act
        var result = await _controller.GetChatHistory(submissionId);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedHistory = Assert.IsType<ChatHistoryResponse>(okResult.Value);
        Assert.Empty(returnedHistory.Messages);
    }

    [Fact]
    public async Task GetChatHistory_ServiceThrowsException_ReturnsInternalServerError()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockChatService.Setup(x => x.GetChatHistoryAsync(submissionId))
            .ThrowsAsync(new Exception("Database error"));

        // Act
        var result = await _controller.GetChatHistory(submissionId);

        // Assert
        var statusResult = Assert.IsType<ObjectResult>(result.Result);
        Assert.Equal(500, statusResult.StatusCode);
    }

    [Fact]
    public async Task DeleteChatHistory_ValidSubmissionId_ReturnsNoContent()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockChatService.Setup(x => x.DeleteChatHistoryAsync(submissionId))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _controller.DeleteChatHistory(submissionId);

        // Assert
        Assert.IsType<NoContentResult>(result);
        _mockChatService.Verify(x => x.DeleteChatHistoryAsync(submissionId), Times.Once);
    }

    [Fact]
    public async Task DeleteChatHistory_ServiceThrowsException_ReturnsInternalServerError()
    {
        // Arrange
        var submissionId = Guid.NewGuid();
        _mockChatService.Setup(x => x.DeleteChatHistoryAsync(submissionId))
            .ThrowsAsync(new Exception("Delete failed"));

        // Act
        var result = await _controller.DeleteChatHistory(submissionId);

        // Assert
        var statusResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(500, statusResult.StatusCode);
    }

    [Fact]
    public async Task GetGeneralChatHistory_ReturnsOkWithHistory()
    {
        // Arrange
        var history = new ChatHistoryResponse
        {
            SubmissionId = Guid.Empty,
            Messages = new List<ChatMessageDto>
            {
                new ChatMessageDto { Role = "user", Content = "General question", Language = "en", Timestamp = DateTime.UtcNow }
            }
        };

        _mockChatService.Setup(x => x.GetChatHistoryAsync(Guid.Empty))
            .ReturnsAsync(history);

        // Act
        var result = await _controller.GetGeneralChatHistory();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedHistory = Assert.IsType<ChatHistoryResponse>(okResult.Value);
        Assert.Equal(Guid.Empty, returnedHistory.SubmissionId);
        Assert.Single(returnedHistory.Messages);
    }

    [Fact]
    public async Task DeleteGeneralChatHistory_ReturnsNoContent()
    {
        // Arrange
        _mockChatService.Setup(x => x.DeleteChatHistoryAsync(Guid.Empty))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _controller.DeleteGeneralChatHistory();

        // Assert
        Assert.IsType<NoContentResult>(result);
        _mockChatService.Verify(x => x.DeleteChatHistoryAsync(Guid.Empty), Times.Once);
    }

    [Fact]
    public async Task AskAboutSubmission_OverridesSubmissionIdFromPath()
    {
        // Arrange
        var pathSubmissionId = Guid.NewGuid();
        var bodySubmissionId = Guid.NewGuid(); // Different ID in body (should be overridden)
        
        var request = new ChatRequest
        {
            Query = "About this paper",
            SubmissionId = bodySubmissionId
        };

        var response = new ChatResponse
        {
            Answer = "Answer about the paper",
            DetectedLanguage = "en",
            Sources = new List<SourceReference>(),
            CitedSubmissions = new List<Guid> { pathSubmissionId }
        };

        _mockChatService.Setup(x => x.AskQuestionAsync(
            It.Is<ChatRequest>(r => r.SubmissionId == pathSubmissionId)))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.AskAboutSubmission(pathSubmissionId, request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        _mockChatService.Verify(x => x.AskQuestionAsync(
            It.Is<ChatRequest>(r => r.SubmissionId == pathSubmissionId)), Times.Once);
    }

    [Fact]
    public async Task AskQuestion_WithTopKParameter_PassesCorrectly()
    {
        // Arrange
        var request = new ChatRequest
        {
            Query = "What are the top papers?",
            TopK = 10
        };

        var response = new ChatResponse
        {
            Answer = "Here are the top papers...",
            DetectedLanguage = "en",
            Sources = Enumerable.Range(0, 10).Select(i => new SourceReference
            {
                SubmissionId = Guid.NewGuid(),
                Title = $"Paper {i}"
            }).ToList(),
            CitedSubmissions = new List<Guid>()
        };

        _mockChatService.Setup(x => x.AskQuestionAsync(
            It.Is<ChatRequest>(r => r.TopK == 10)))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.AskQuestion(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedResponse = Assert.IsType<ChatResponse>(okResult.Value);
        Assert.Equal(10, returnedResponse.Sources.Count);
    }

    [Fact]
    public async Task AskQuestion_MultilingualQuery_PreservesLanguage()
    {
        // Arrange
        var request = new ChatRequest
        {
            Query = "¿Cuál es la mejor arquitectura de red neuronal?",
            Language = "es"
        };

        var response = new ChatResponse
        {
            Answer = "La mejor arquitectura depende del caso de uso...",
            DetectedLanguage = "es",
            WasTranslated = true,
            TranslatedQuery = "What is the best neural network architecture?",
            Sources = new List<SourceReference>(),
            CitedSubmissions = new List<Guid>()
        };

        _mockChatService.Setup(x => x.AskQuestionAsync(request))
            .ReturnsAsync(response);

        // Act
        var result = await _controller.AskQuestion(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedResponse = Assert.IsType<ChatResponse>(okResult.Value);
        Assert.Equal("es", returnedResponse.DetectedLanguage);
        Assert.True(returnedResponse.WasTranslated);
    }
}
