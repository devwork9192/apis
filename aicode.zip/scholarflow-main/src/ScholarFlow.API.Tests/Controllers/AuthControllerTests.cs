using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using ScholarFlow.API.Controllers;
using ScholarFlow.API.DTOs.Auth;
using ScholarFlow.API.Services;
using Xunit;

namespace ScholarFlow.API.Tests.Controllers;

public class AuthControllerTests
{
    private readonly Mock<IAuthService> _authServiceMock;
    private readonly Mock<ILogger<AuthController>> _loggerMock;
    private readonly AuthController _controller;

    public AuthControllerTests()
    {
        _authServiceMock = new Mock<IAuthService>();
        _loggerMock = new Mock<ILogger<AuthController>>();
        _controller = new AuthController(_authServiceMock.Object, _loggerMock.Object);
    }

    [Fact]
    public async Task Login_WithValidCredentials_ReturnsOkWithToken()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "TestPass123"
        };

        var expectedResponse = new LoginResponse
        {
            Token = "test.jwt.token",
            Role = "Author",
            Username = "researcher@test.edu",
            ExpiresAt = DateTime.UtcNow.AddHours(8)
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync(expectedResponse);

        // Act
        var result = await _controller.Login(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var response = Assert.IsType<LoginResponse>(okResult.Value);
        Assert.Equal(expectedResponse.Token, response.Token);
        Assert.Equal(expectedResponse.Role, response.Role);
        Assert.Equal(expectedResponse.Username, response.Username);
    }

    [Fact]
    public async Task Login_WithInvalidCredentials_ReturnsUnauthorized()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "WrongPassword"
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync((LoginResponse)null!);

        // Act
        var result = await _controller.Login(request);

        // Assert
        var actionResult = Assert.IsType<ActionResult<LoginResponse>>(result);
        Assert.IsType<UnauthorizedObjectResult>(actionResult.Result);
    }

    [Fact]
    public async Task Login_WithAuthorRole_ReturnsCorrectRole()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "TestPass123"
        };

        var expectedResponse = new LoginResponse
        {
            Token = "test.jwt.token",
            Role = "Author",
            Username = "researcher@test.edu",
            ExpiresAt = DateTime.UtcNow.AddHours(8)
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync(expectedResponse);

        // Act
        var result = await _controller.Login(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var response = Assert.IsType<LoginResponse>(okResult.Value);
        Assert.Equal("Author", response.Role);
    }

    [Fact]
    public async Task Login_WithReviewerRole_ReturnsCorrectRole()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "admin@test.edu",
            Password = "AdminPass456"
        };

        var expectedResponse = new LoginResponse
        {
            Token = "test.jwt.token",
            Role = "Reviewer",
            Username = "admin@test.edu",
            ExpiresAt = DateTime.UtcNow.AddHours(8)
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync(expectedResponse);

        // Act
        var result = await _controller.Login(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var response = Assert.IsType<LoginResponse>(okResult.Value);
        Assert.Equal("Reviewer", response.Role);
    }

    [Fact]
    public async Task Login_WithEmptyUsername_ReturnsUnauthorized()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "",
            Password = "TestPass123"
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync((LoginResponse)null!);

        // Act
        var result = await _controller.Login(request);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result.Result);
    }

    [Fact]
    public async Task Login_WithEmptyPassword_ReturnsUnauthorized()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = ""
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync((LoginResponse)null!);

        // Act
        var result = await _controller.Login(request);

        // Assert
        Assert.IsType<UnauthorizedObjectResult>(result.Result);
    }

    [Fact]
    public void Validate_WithValidCredentials_ReturnsOk()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "TestPass123"
        };

        _authServiceMock
            .Setup(x => x.ValidateCredentials(request.Username, request.Password))
            .Returns(true);

        // Act
        var result = _controller.ValidateCredentials(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        Assert.NotNull(okResult.Value);
        var message = okResult.Value.ToString();
        Assert.Contains("Credentials are valid", message);
    }

    [Fact]
    public void Validate_WithInvalidCredentials_ReturnsUnauthorized()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "WrongPassword"
        };

        _authServiceMock
            .Setup(x => x.ValidateCredentials(request.Username, request.Password))
            .Returns(false);

        // Act
        var result = _controller.ValidateCredentials(request);

        // Assert
        var unauthorizedResult = Assert.IsType<UnauthorizedObjectResult>(result);
        Assert.NotNull(unauthorizedResult.Value);
        var message = unauthorizedResult.Value.ToString();
        Assert.Contains("Invalid credentials", message);
    }

    [Fact]
    public void Validate_CallsAuthServiceOnce()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "TestPass123"
        };

        _authServiceMock
            .Setup(x => x.ValidateCredentials(request.Username, request.Password))
            .Returns(true);

        // Act
        _controller.ValidateCredentials(request);

        // Assert
        _authServiceMock.Verify(
            x => x.ValidateCredentials(request.Username, request.Password),
            Times.Once);
    }

    [Fact]
    public async Task Login_CallsAuthServiceOnce()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "TestPass123"
        };

        var expectedResponse = new LoginResponse
        {
            Token = "test.jwt.token",
            Role = "Author",
            Username = "researcher@test.edu",
            ExpiresAt = DateTime.UtcNow.AddHours(8)
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync(expectedResponse);

        // Act
        await _controller.Login(request);

        // Assert
        _authServiceMock.Verify(
            x => x.AuthenticateAsync(request.Username, request.Password),
            Times.Once);
    }

    [Fact]
    public async Task Login_ReturnsTokenWithExpiration()
    {
        // Arrange
        var request = new LoginRequest
        {
            Username = "researcher@test.edu",
            Password = "TestPass123"
        };

        var expectedExpiration = DateTime.UtcNow.AddHours(8);
        var expectedResponse = new LoginResponse
        {
            Token = "test.jwt.token",
            Role = "Author",
            Username = "researcher@test.edu",
            ExpiresAt = expectedExpiration
        };

        _authServiceMock
            .Setup(x => x.AuthenticateAsync(request.Username, request.Password))
            .ReturnsAsync(expectedResponse);

        // Act
        var result = await _controller.Login(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var response = Assert.IsType<LoginResponse>(okResult.Value);
        Assert.True(response.ExpiresAt > DateTime.UtcNow);
    }

    [Fact]
    public async Task Login_WithNullRequest_ThrowsException()
    {
        // Arrange
        LoginRequest request = null!;

        // Act & Assert
        await Assert.ThrowsAsync<NullReferenceException>(() => _controller.Login(request));
    }

    [Fact]
    public void Validate_WithNullRequest_ThrowsException()
    {
        // Arrange
        LoginRequest request = null!;

        // Act - Method catches NullReferenceException and returns 500
        var result = _controller.ValidateCredentials(request);
        
        // Assert
        Assert.IsType<ObjectResult>(result);
    }
}
