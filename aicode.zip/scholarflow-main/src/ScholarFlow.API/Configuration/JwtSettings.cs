namespace ScholarFlow.API.Configuration;

/// <summary>
/// JWT authentication settings
/// </summary>
public class JwtSettings
{
    /// <summary>
    /// Secret key for signing tokens (minimum 32 characters)
    /// </summary>
    public string SecretKey { get; set; } = string.Empty;

    /// <summary>
    /// Token issuer
    /// </summary>
    public string Issuer { get; set; } = "ScholarFlow";

    /// <summary>
    /// Token audience
    /// </summary>
    public string Audience { get; set; } = "ScholarFlowAPI";

    /// <summary>
    /// Token expiration in minutes (default: 8 hours)
    /// </summary>
    public int ExpirationMinutes { get; set; } = 480;
}

/// <summary>
/// User configuration for authentication
/// </summary>
public class UserConfig
{
    /// <summary>
    /// Username or email
    /// </summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Password (should be hashed in production)
    /// </summary>
    public string Password { get; set; } = string.Empty;

    /// <summary>
    /// User role: Author or Reviewer
    /// </summary>
    public string Role { get; set; } = string.Empty;
}

/// <summary>
/// Authentication settings container
/// </summary>
public class AuthSettings
{
    /// <summary>
    /// List of configured users
    /// </summary>
    public List<UserConfig> Users { get; set; } = new();
}
