using ScholarFlow.API.Common;

namespace ScholarFlow.API.Configuration;

public class ValidationRulesSettings
{
    public int MinPageCount { get; set; } = 8;
    public int MaxPageCount { get; set; } = 25;
    public List<string> RequiredSections { get; set; } = new();
    public double PlagiarismThreshold { get; set; } = 0.85;
    public double ToxicityThreshold { get; set; } = 0.7;
    public double HumanReviewThreshold { get; set; } = 0.75;
}

public class StorageSettings
{
    public string UploadPath { get; set; } = AppConstants.Paths.DefaultUploadPath;
    public string DatabasePath { get; set; } = AppConstants.Paths.DefaultDatabaseName;
}
