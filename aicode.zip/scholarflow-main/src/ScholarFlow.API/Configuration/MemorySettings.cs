namespace ScholarFlow.API.Configuration;

/// <summary>
/// Configuration for vector store and memory/RAG functionality
/// </summary>
public class MemorySettings
{
    /// <summary>
    /// Type of vector store to use (e.g., "Qdrant", "AzureAISearch")
    /// </summary>
    public string VectorStoreType { get; set; } = "Qdrant";
    
    /// <summary>
    /// Connection string for the vector database
    /// </summary>
    public string ConnectionString { get; set; } = "http://localhost:6333";
    
    /// <summary>
    /// Name of the collection/index for research papers
    /// </summary>
    public string CollectionName { get; set; } = "research_papers";
    
    /// <summary>
    /// Dimension of embedding vectors (1536 for text-embedding-ada-002)
    /// </summary>
    public int EmbeddingDimensions { get; set; } = 1536;
    
    /// <summary>
    /// Azure OpenAI embedding model deployment name
    /// </summary>
    public string EmbeddingDeploymentName { get; set; } = "text-embedding-ada-002";
}
