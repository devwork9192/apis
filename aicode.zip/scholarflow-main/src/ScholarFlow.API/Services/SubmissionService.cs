using Microsoft.EntityFrameworkCore;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Services;

public interface ISubmissionService
{
    Task<Submission?> GetByIdAsync(Guid id);
    Task<SubmissionStatusResponse?> GetStatusAsync(Guid id);
    Task<List<SubmissionListResponse>> GetAllAsync();
    Task<List<AuditLog>> GetAuditLogsAsync(Guid submissionId);
}

public class SubmissionService : ISubmissionService
{
    private readonly ScholarFlowDbContext _context;
    private readonly ILogger<SubmissionService> _logger;

    public SubmissionService(
        ScholarFlowDbContext context,
        ILogger<SubmissionService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<Submission?> GetByIdAsync(Guid id)
    {
        return await _context.Submissions
            .Include(s => s.AuditLogs)
            .FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<SubmissionStatusResponse?> GetStatusAsync(Guid id)
    {
        var submission = await _context.Submissions.FindAsync(id);
        if (submission == null)
            return null;

        return new SubmissionStatusResponse
        {
            Id = submission.Id,
            FileName = submission.FileName,
            Status = submission.Status.ToString(),
            CurrentStage = submission.CurrentStage.ToString(),
            DetectedLanguage = submission.DetectedLanguage,
            PageCount = submission.PageCount,
            WasTranslated = submission.WasTranslated,
            Title = submission.Title,
            Authors = submission.Authors,
            Affiliations = submission.Affiliations,
            Abstract = submission.Abstract,
            Keywords = submission.Keywords,
            ValidationWarnings = submission.ValidationWarnings,
            Summary = submission.Summary,
            ErrorMessage = submission.ErrorMessage,
            UploadedAt = submission.UploadedAt,
            ProcessedAt = submission.ProcessedAt
        };
    }

    public async Task<List<SubmissionListResponse>> GetAllAsync()
    {
        return await _context.Submissions
            .OrderByDescending(s => s.UploadedAt)
            .Select(s => new SubmissionListResponse
            {
                Id = s.Id,
                FileName = s.FileName,
                Status = s.Status.ToString(),
                UploadedAt = s.UploadedAt,
                PageCount = s.PageCount,
                DetectedLanguage = s.DetectedLanguage,
                ErrorMessage = s.ErrorMessage,
                UploadedBy = s.UploadedBy
            })
            .ToListAsync();
    }

    public async Task<List<AuditLog>> GetAuditLogsAsync(Guid submissionId)
    {
        return await _context.AuditLogs
            .Where(a => a.SubmissionId == submissionId)
            .OrderBy(a => a.Timestamp)
            .ToListAsync();
    }
}
