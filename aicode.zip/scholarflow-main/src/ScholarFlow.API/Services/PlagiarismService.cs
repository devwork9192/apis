using Microsoft.SemanticKernel.Embeddings;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Agents;
using Microsoft.EntityFrameworkCore;

#pragma warning disable CS0618 // Type or member is obsolete - Will be upgraded to IEmbeddingGenerator in Phase 2 (RAG)

namespace ScholarFlow.API.Services;

/// <summary>
/// Service for detecting plagiarism using semantic similarity
/// </summary>
public interface IPlagiarismService
{
    /// <summary>
    /// Check submission for plagiarism against existing submissions
    /// </summary>
    Task<PlagiarismCheckResult> CheckPlagiarismAsync(string text, Guid submissionId, double threshold);
}

/// <summary>
/// Implementation of plagiarism detection using embeddings-based semantic similarity
/// </summary>
public class PlagiarismService : IPlagiarismService
{
    private readonly ITextEmbeddingGenerationService _embeddingService;
    private readonly ScholarFlowDbContext _dbContext;
    private readonly ILogger<PlagiarismService> _logger;

    // Configuration for chunking large texts
    private const int MaxChunkSize = 8000; // characters
    private const int TopNResults = 5;

    public PlagiarismService(
        ITextEmbeddingGenerationService embeddingService,
        ScholarFlowDbContext dbContext,
        ILogger<PlagiarismService> logger)
    {
        _embeddingService = embeddingService;
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task<PlagiarismCheckResult> CheckPlagiarismAsync(string text, Guid submissionId, double threshold)
    {
        try
        {
            _logger.LogInformation("Starting plagiarism check for submission: {SubmissionId}", submissionId);

            if (string.IsNullOrWhiteSpace(text))
            {
                return new PlagiarismCheckResult
                {
                    CheckSuccessful = false,
                    ErrorMessage = "Text cannot be empty",
                    Details = "No text provided for plagiarism check"
                };
            }

            // Get or generate embedding for current submission
            var currentEmbedding = await GenerateEmbeddingAsync(text);
            if (!currentEmbedding.HasValue)
            {
                return new PlagiarismCheckResult
                {
                    CheckSuccessful = false,
                    ErrorMessage = "Failed to generate embedding",
                    Details = "Could not create text embedding for comparison"
                };
            }

            // Get all other submissions with abstracts (excluding current one)
            var otherSubmissions = await _dbContext.Submissions
                .Where(s => s.Id != submissionId && !string.IsNullOrEmpty(s.Abstract))
                .Select(s => new
                {
                    s.Id,
                    s.Title,
                    s.Authors,
                    s.Abstract,
                    s.UploadedAt,
                    TextForComparison = (s.TranslatedText ?? s.RawText) ?? s.Abstract
                })
                .ToListAsync();

            _logger.LogInformation("Comparing against {Count} existing submissions", otherSubmissions.Count);

            if (!otherSubmissions.Any())
            {
                return new PlagiarismCheckResult
                {
                    CheckSuccessful = true,
                    PlagiarismScore = 0.0,
                    IsAboveThreshold = false,
                    Details = "No existing submissions to compare against",
                    SimilarSubmissions = new List<SimilarSubmission>()
                };
            }

            // Calculate similarities
            var similarities = new List<(Guid Id, string Title, string Authors, DateTime SubmittedAt, double Score)>();

            foreach (var submission in otherSubmissions)
            {
                try
                {
                    var otherText = submission.TextForComparison;
                    if (string.IsNullOrWhiteSpace(otherText))
                    {
                        _logger.LogWarning("Skipping submission {SubmissionId} - no text available", submission.Id);
                        continue;
                    }
                    
                    var otherEmbedding = await GenerateEmbeddingAsync(otherText);
                    if (otherEmbedding.HasValue)
                    {
                        var similarity = CalculateCosineSimilarity(currentEmbedding.Value, otherEmbedding.Value);
                        similarities.Add((submission.Id, submission.Title ?? "Untitled", submission.Authors ?? "Unknown", submission.UploadedAt, similarity));
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error comparing with submission {SubmissionId}", submission.Id);
                }
            }

            // Get top N most similar
            var topSimilar = similarities
                .OrderByDescending(s => s.Score)
                .Take(TopNResults)
                .ToList();

            var maxScore = topSimilar.Any() ? topSimilar.Max(s => s.Score) : 0.0;

            var result = new PlagiarismCheckResult
            {
                CheckSuccessful = true,
                PlagiarismScore = maxScore,
                IsAboveThreshold = maxScore >= threshold,
                Details = $"Compared against {otherSubmissions.Count} submissions. Found {topSimilar.Count} similar matches.",
                SimilarSubmissions = topSimilar.Select(s => new SimilarSubmission
                {
                    SubmissionId = s.Id,
                    Title = s.Title,
                    Authors = s.Authors,
                    SimilarityScore = s.Score,
                    SubmittedAt = s.SubmittedAt
                }).ToList()
            };

            _logger.LogInformation("Plagiarism check completed. Score: {Score}, Threshold: {Threshold}, Above threshold: {IsAbove}",
                maxScore, threshold, result.IsAboveThreshold);

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during plagiarism check for submission: {SubmissionId}", submissionId);
            return new PlagiarismCheckResult
            {
                CheckSuccessful = false,
                ErrorMessage = ex.Message,
                Details = $"Plagiarism check failed: {ex.Message}"
            };
        }
    }

    private async Task<ReadOnlyMemory<float>?> GenerateEmbeddingAsync(string text)
    {
        try
        {
            // Truncate if too long
            var truncatedText = text.Length > MaxChunkSize ? text.Substring(0, MaxChunkSize) : text;

            var embedding = await _embeddingService.GenerateEmbeddingAsync(truncatedText);
            return embedding;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating embedding");
            return null;
        }
    }

    private static double CalculateCosineSimilarity(ReadOnlyMemory<float> vector1, ReadOnlyMemory<float> vector2)
    {
        var v1 = vector1.Span;
        var v2 = vector2.Span;

        if (v1.Length != v2.Length)
        {
            throw new ArgumentException("Vectors must have the same length");
        }

        double dotProduct = 0.0;
        double magnitude1 = 0.0;
        double magnitude2 = 0.0;

        for (int i = 0; i < v1.Length; i++)
        {
            dotProduct += v1[i] * v2[i];
            magnitude1 += v1[i] * v1[i];
            magnitude2 += v2[i] * v2[i];
        }

        magnitude1 = Math.Sqrt(magnitude1);
        magnitude2 = Math.Sqrt(magnitude2);

        if (magnitude1 == 0.0 || magnitude2 == 0.0)
        {
            return 0.0;
        }

        return dotProduct / (magnitude1 * magnitude2);
    }
}
