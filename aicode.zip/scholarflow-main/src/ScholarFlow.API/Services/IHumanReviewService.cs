using ScholarFlow.API.DTOs.HumanReview;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Services;

/// <summary>
/// Service for handling human review workflow
/// </summary>
public interface IHumanReviewService
{
    /// <summary>
    /// Get all submissions pending human review
    /// </summary>
    Task<List<ReviewSummaryResponse>> GetPendingReviewsAsync();
    
    /// <summary>
    /// Get review summary for a specific submission
    /// </summary>
    Task<ReviewSummaryResponse?> GetReviewSummaryAsync(Guid submissionId);
    
    /// <summary>
    /// Approve a submission
    /// </summary>
    Task<ReviewResponse?> ApproveSubmissionAsync(Guid submissionId, ApproveRequest request);
    
    /// <summary>
    /// Reject a submission
    /// </summary>
    Task<ReviewResponse?> RejectSubmissionAsync(Guid submissionId, RejectRequest request);
    
    /// <summary>
    /// Override validation findings
    /// </summary>
    Task<ReviewResponse?> OverrideValidationAsync(Guid submissionId, OverrideRequest request);
}
