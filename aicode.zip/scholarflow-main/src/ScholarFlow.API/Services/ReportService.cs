using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Submissions;
using Microsoft.EntityFrameworkCore;

namespace ScholarFlow.API.Services;

/// <summary>
/// Service for generating validation reports
/// </summary>
public interface IReportService
{
    /// <summary>
    /// Generate a comprehensive validation report for a submission
    /// </summary>
    Task<ValidationReport?> GenerateValidationReportAsync(Guid submissionId);
    
    /// <summary>
    /// Generate an HTML-formatted validation report
    /// </summary>
    Task<string?> GenerateValidationReportHtmlAsync(Guid submissionId);
}

/// <summary>
/// Implementation of report generation service
/// </summary>
public class ReportService : IReportService
{
    private readonly ScholarFlowDbContext _dbContext;
    private readonly ILogger<ReportService> _logger;

    public ReportService(
        ScholarFlowDbContext dbContext,
        ILogger<ReportService> logger)
    {
        _dbContext = dbContext;
        _logger = logger;
    }

    public async Task<ValidationReport?> GenerateValidationReportAsync(Guid submissionId)
    {
        try
        {
            _logger.LogInformation("Generating validation report for submission: {SubmissionId}", submissionId);

            var submission = await _dbContext.Submissions
                .FirstOrDefaultAsync(s => s.Id == submissionId);

            if (submission == null)
            {
                _logger.LogWarning("Submission not found: {SubmissionId}", submissionId);
                return null;
            }

            var report = new ValidationReport
            {
                SubmissionId = submission.Id,
                GeneratedAt = DateTime.UtcNow,
                RequiresHumanReview = submission.RequiresHumanReview ?? false
            };

            // Build metadata validation section
            report.MetadataValidation = BuildMetadataSection(submission);

            // Build content validation section
            report.ContentValidation = BuildContentSection(submission);

            // Build quality checks section
            report.QualityChecks = BuildQualitySection(submission);

            // Build plagiarism check section
            report.PlagiarismCheck = BuildPlagiarismSection(submission);

            // Build toxicity check section
            report.ToxicityCheck = BuildToxicitySection(submission);

            // Determine overall status
            report.OverallStatus = DetermineOverallStatus(report);

            // Generate summary
            report.Summary = GenerateSummary(report, submission);

            // Generate recommendations
            report.Recommendations = GenerateRecommendations(report);

            _logger.LogInformation("Validation report generated successfully for submission: {SubmissionId}", submissionId);

            return report;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating validation report for submission: {SubmissionId}", submissionId);
            return null;
        }
    }

    public async Task<string?> GenerateValidationReportHtmlAsync(Guid submissionId)
    {
        var report = await GenerateValidationReportAsync(submissionId);
        if (report == null)
        {
            return null;
        }

        return GenerateHtmlReport(report);
    }

    private MetadataValidationSection BuildMetadataSection(Models.Submission submission)
    {
        var section = new MetadataValidationSection
        {
            HasTitle = !string.IsNullOrWhiteSpace(submission.Title),
            HasAuthors = !string.IsNullOrWhiteSpace(submission.Authors),
            HasAbstract = !string.IsNullOrWhiteSpace(submission.Abstract)
        };

        if (!section.HasTitle) section.Issues.Add("Title is missing");
        if (!section.HasAuthors) section.Issues.Add("Authors information is missing");
        if (!section.HasAbstract) section.Issues.Add("Abstract is missing");

        if (section.HasTitle && submission.Title!.Length < 10)
        {
            section.Issues.Add("Title is very short (< 10 characters)");
        }

        section.Status = section.Issues.Count == 0 ? "Pass" : (section.HasTitle && section.HasAuthors && section.HasAbstract ? "Warning" : "Fail");

        return section;
    }

    private ContentValidationSection BuildContentSection(Models.Submission submission)
    {
        var section = new ContentValidationSection
        {
            PageCount = submission.PageCount,
            PageCountValid = submission.PageCount >= 8 && submission.PageCount <= 25,
            ContainsRequiredSections = true // This would come from validation results
        };

        if (!section.PageCountValid)
        {
            section.Issues.Add($"Page count ({submission.PageCount}) is outside the valid range (8-25 pages)");
        }

        // Parse found sections from text analysis (simplified)
        var text = (submission.TranslatedText ?? submission.RawText ?? "").ToLowerInvariant();
        var potentialSections = new[] { "introduction", "methodology", "results", "conclusion", "references" };
        
        foreach (var sectionName in potentialSections)
        {
            if (text.Contains(sectionName))
            {
                section.FoundSections.Add(sectionName);
            }
            else if (sectionName != "references") // references is optional in text check
            {
                section.MissingSections.Add(sectionName);
            }
        }

        if (section.MissingSections.Count > 2)
        {
            section.Issues.Add($"Multiple required sections may be missing: {string.Join(", ", section.MissingSections)}");
            section.ContainsRequiredSections = false;
        }

        section.Status = section.Issues.Count == 0 && section.PageCountValid ? "Pass" : (section.PageCountValid ? "Warning" : "Fail");

        return section;
    }

    private QualityChecksSection BuildQualitySection(Models.Submission submission)
    {
        var section = new QualityChecksSection();

        var text = submission.TranslatedText ?? submission.RawText ?? "";
        var words = text.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        section.WordCount = words.Length;

        var expectedMinWords = submission.PageCount * 200;
        if (section.WordCount < expectedMinWords && string.IsNullOrWhiteSpace(submission.Abstract))
        {
            section.Issues.Add($"Word count ({section.WordCount}) is low for {submission.PageCount} pages. Expected at least {expectedMinWords} words.");
        }

        section.Status = section.Issues.Count == 0 ? "Pass" : "Warning";

        return section;
    }

    private PlagiarismCheckSection BuildPlagiarismSection(Models.Submission submission)
    {
        var section = new PlagiarismCheckSection();

        if (submission.PlagiarismScore.HasValue)
        {
            section.Checked = true;
            section.Score = submission.PlagiarismScore.Value;
            section.IsAboveThreshold = submission.PlagiarismScore.Value >= 0.85;
            
            // Calculate similar submissions count based on score
            // The plagiarism check compares against up to top 5 existing submissions
            // If score is high, there must be at least 1 similar submission
            if (section.Score >= 0.70)
            {
                // Query for other submissions with abstracts that could be similar
                // Include submissions that have been validated or approved (not failed or still uploading)
                var potentialSimilarCount = _dbContext.Submissions
                    .Where(s => s.Id != submission.Id 
                            && !string.IsNullOrEmpty(s.Abstract)
                            && s.Status != Models.SubmissionStatus.Failed
                            && s.Status != Models.SubmissionStatus.Uploaded)
                    .Count();
                
                // Cap at 5 since plagiarism service returns top 5 similar submissions
                section.SimilarSubmissionsFound = Math.Min(potentialSimilarCount, 5);
                
                // Ensure at least 1 if score is high (there must be a similar submission to get a high score)
                if (section.SimilarSubmissionsFound == 0 && section.Score >= 0.70)
                {
                    section.SimilarSubmissionsFound = 1;
                }
            }
            else
            {
                section.SimilarSubmissionsFound = 0;
            }
            
            if (section.IsAboveThreshold)
            {
                section.Issues.Add($"High plagiarism score detected: {section.Score:P0}");
                section.Status = "Fail";
            }
            else if (section.Score >= 0.70)
            {
                section.Issues.Add($"Moderate similarity detected: {section.Score:P0}");
                section.Status = "Warning";
            }
            else
            {
                section.Status = "Pass";
            }
        }
        else
        {
            section.Checked = false;
            section.Status = "Not Checked";
            section.SimilarSubmissionsFound = 0;
        }

        return section;
    }

    private ToxicityCheckSection BuildToxicitySection(Models.Submission submission)
    {
        var section = new ToxicityCheckSection();

        if (submission.ToxicityScore.HasValue)
        {
            section.Checked = true;
            section.Score = submission.ToxicityScore.Value;
            section.IsAboveThreshold = submission.ToxicityScore.Value >= 0.7;
            
            if (section.IsAboveThreshold)
            {
                section.Issues.Add($"Inappropriate content detected: toxicity score {section.Score:P0}");
                section.Status = "Fail";
            }
            else if (section.Score >= 0.5)
            {
                section.Issues.Add($"Potential content concerns: toxicity score {section.Score:P0}");
                section.Status = "Warning";
            }
            else
            {
                section.Status = "Pass";
            }
        }
        else
        {
            section.Checked = false;
            section.Status = "Not Checked";
        }

        return section;
    }

    private string DetermineOverallStatus(ValidationReport report)
    {
        var hasFail = report.MetadataValidation.Status == "Fail" ||
                      report.ContentValidation.Status == "Fail" ||
                      report.PlagiarismCheck.Status == "Fail" ||
                      report.ToxicityCheck.Status == "Fail";

        var hasWarning = report.MetadataValidation.Status == "Warning" ||
                        report.ContentValidation.Status == "Warning" ||
                        report.QualityChecks.Status == "Warning" ||
                        report.PlagiarismCheck.Status == "Warning" ||
                        report.ToxicityCheck.Status == "Warning";

        if (hasFail) return "Fail";
        if (hasWarning || report.RequiresHumanReview) return "Review";
        return "Pass";
    }

    private string GenerateSummary(ValidationReport report, Models.Submission submission)
    {
        var totalIssues = report.MetadataValidation.Issues.Count +
                         report.ContentValidation.Issues.Count +
                         report.QualityChecks.Issues.Count +
                         report.PlagiarismCheck.Issues.Count +
                         report.ToxicityCheck.Issues.Count;

        return report.OverallStatus switch
        {
            "Pass" => $"Submission '{submission.Title}' has passed all validation checks successfully.",
            "Fail" => $"Submission '{submission.Title}' has failed validation with {totalIssues} issue(s) that must be addressed.",
            "Review" => $"Submission '{submission.Title}' requires human review. {totalIssues} potential issue(s) identified.",
            _ => "Validation status unknown"
        };
    }

    private List<string> GenerateRecommendations(ValidationReport report)
    {
        var recommendations = new List<string>();

        if (report.MetadataValidation.Issues.Any())
        {
            recommendations.Add("Complete all required metadata fields (title, authors, abstract)");
        }

        if (!report.ContentValidation.PageCountValid)
        {
            recommendations.Add("Ensure page count is within the required range (8-25 pages)");
        }

        if (report.ContentValidation.MissingSections.Any())
        {
            recommendations.Add($"Add missing sections: {string.Join(", ", report.ContentValidation.MissingSections)}");
        }

        if (report.PlagiarismCheck.IsAboveThreshold)
        {
            recommendations.Add("Review and revise content to reduce similarity with existing submissions");
        }

        if (report.ToxicityCheck.IsAboveThreshold)
        {
            recommendations.Add("Review content for inappropriate language or offensive material");
        }

        if (report.QualityChecks.Issues.Any())
        {
            recommendations.Add("Verify text extraction quality or consider resubmitting with a higher-quality PDF");
        }

        if (!recommendations.Any())
        {
            recommendations.Add("Submission meets all validation criteria. Proceed to next stage.");
        }

        return recommendations;
    }

    private string GenerateHtmlReport(ValidationReport report)
    {
        var statusColor = report.OverallStatus switch
        {
            "Pass" => "#28a745",
            "Fail" => "#dc3545",
            "Review" => "#ffc107",
            _ => "#6c757d"
        };

        var html = $@"
<!DOCTYPE html>
<html lang=""en"">
<head>
    <meta charset=""UTF-8"">
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
    <title>Validation Report - {report.SubmissionId}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; border-bottom: 3px solid {statusColor}; padding-bottom: 10px; }}
        .status-badge {{ display: inline-block; padding: 8px 16px; border-radius: 4px; color: white; background: {statusColor}; font-weight: bold; }}
        .section {{ margin: 30px 0; padding: 20px; border: 1px solid #ddd; border-radius: 6px; }}
        .section h2 {{ color: #555; margin-top: 0; }}
        .status-pass {{ color: #28a745; font-weight: bold; }}
        .status-fail {{ color: #dc3545; font-weight: bold; }}
        .status-warning {{ color: #ffc107; font-weight: bold; }}
        .issue {{ padding: 8px; margin: 5px 0; background: #fff3cd; border-left: 3px solid #ffc107; }}
        .issue.error {{ background: #f8d7da; border-left-color: #dc3545; }}
        .recommendations {{ background: #d1ecf1; padding: 15px; border-radius: 4px; border-left: 3px solid #17a2b8; }}
        table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
        th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background: #f8f9fa; font-weight: bold; }}
        .footer {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 0.9em; }}
    </style>
</head>
<body>
    <div class=""container"">
        <h1>Validation Report</h1>
        <p><strong>Submission ID:</strong> {report.SubmissionId}</p>
        <p><strong>Generated:</strong> {report.GeneratedAt:yyyy-MM-dd HH:mm:ss} UTC</p>
        <p><strong>Overall Status:</strong> <span class=""status-badge"">{report.OverallStatus.ToUpperInvariant()}</span></p>
        
        <div class=""section"">
            <h2>Summary</h2>
            <p>{report.Summary}</p>
        </div>

        <div class=""section"">
            <h2>Metadata Validation</h2>
            <p><strong>Status:</strong> <span class=""status-{report.MetadataValidation.Status.ToLowerInvariant()}"">{report.MetadataValidation.Status}</span></p>
            <table>
                <tr><td>Title Present</td><td>{(report.MetadataValidation.HasTitle ? "✓" : "✗")}</td></tr>
                <tr><td>Authors Present</td><td>{(report.MetadataValidation.HasAuthors ? "✓" : "✗")}</td></tr>
                <tr><td>Abstract Present</td><td>{(report.MetadataValidation.HasAbstract ? "✓" : "✗")}</td></tr>
            </table>
            {(report.MetadataValidation.Issues.Any() ? $"<div>{string.Join("", report.MetadataValidation.Issues.Select(i => $"<div class='issue'>{i}</div>"))}</div>" : "")}
        </div>

        <div class=""section"">
            <h2>Content Validation</h2>
            <p><strong>Status:</strong> <span class=""status-{report.ContentValidation.Status.ToLowerInvariant()}"">{report.ContentValidation.Status}</span></p>
            <table>
                <tr><td>Page Count</td><td>{report.ContentValidation.PageCount} pages {(report.ContentValidation.PageCountValid ? "✓" : "✗")}</td></tr>
                <tr><td>Required Sections</td><td>{(report.ContentValidation.ContainsRequiredSections ? "✓" : "✗")}</td></tr>
                <tr><td>Found Sections</td><td>{string.Join(", ", report.ContentValidation.FoundSections)}</td></tr>
            </table>
            {(report.ContentValidation.Issues.Any() ? $"<div>{string.Join("", report.ContentValidation.Issues.Select(i => $"<div class='issue'>{i}</div>"))}</div>" : "")}
        </div>

        <div class=""section"">
            <h2>Quality Checks</h2>
            <p><strong>Status:</strong> <span class=""status-{report.QualityChecks.Status.ToLowerInvariant()}"">{report.QualityChecks.Status}</span></p>
            <table>
                <tr><td>Word Count</td><td>{report.QualityChecks.WordCount:N0} words</td></tr>
            </table>
            {(report.QualityChecks.Issues.Any() ? $"<div>{string.Join("", report.QualityChecks.Issues.Select(i => $"<div class='issue'>{i}</div>"))}</div>" : "")}
        </div>

        <div class=""section"">
            <h2>Plagiarism Check</h2>
            <p><strong>Status:</strong> <span class=""status-{report.PlagiarismCheck.Status.ToLowerInvariant()}"">{report.PlagiarismCheck.Status}</span></p>
            {(report.PlagiarismCheck.Checked ? $@"
            <table>
                <tr><td>Similarity Score</td><td>{report.PlagiarismCheck.Score:P0}</td></tr>
                <tr><td>Similar Submissions Found</td><td>{report.PlagiarismCheck.SimilarSubmissionsFound}</td></tr>
            </table>
            {(report.PlagiarismCheck.Issues.Any() ? $"<div>{string.Join("", report.PlagiarismCheck.Issues.Select(i => $"<div class='issue error'>{i}</div>"))}</div>" : "")}"
            : "<p>Plagiarism check not yet performed.</p>")}
        </div>

        <div class=""section"">
            <h2>Toxicity Check</h2>
            <p><strong>Status:</strong> <span class=""status-{report.ToxicityCheck.Status.ToLowerInvariant()}"">{report.ToxicityCheck.Status}</span></p>
            {(report.ToxicityCheck.Checked ? $@"
            <table>
                <tr><td>Toxicity Score</td><td>{report.ToxicityCheck.Score:P0}</td></tr>
            </table>
            {(report.ToxicityCheck.Issues.Any() ? $"<div>{string.Join("", report.ToxicityCheck.Issues.Select(i => $"<div class='issue error'>{i}</div>"))}</div>" : "")}"
            : "<p>Toxicity check not yet performed.</p>")}
        </div>

        <div class=""section recommendations"">
            <h2>Recommendations</h2>
            <ul>
                {string.Join("", report.Recommendations.Select(r => $"<li>{r}</li>"))}
            </ul>
        </div>

        <div class=""footer"">
            <p>Generated by ScholarFlow Validation System | {DateTime.UtcNow.Year}</p>
        </div>
    </div>
</body>
</html>";

        return html;
    }
}
