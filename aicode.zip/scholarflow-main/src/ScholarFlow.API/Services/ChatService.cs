using ScholarFlow.API.DTOs.Chat;
using ScholarFlow.API.Database;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Models;
using Microsoft.EntityFrameworkCore;

namespace ScholarFlow.API.Services;

public interface IChatService
{
    Task<ChatResponse> AskQuestionAsync(ChatRequest request);
    Task<ChatHistoryResponse> GetChatHistoryAsync(Guid submissionId);
    Task DeleteChatHistoryAsync(Guid submissionId);
}

/// <summary>
/// Service for managing chat/Q&A operations
/// </summary>
public class ChatService : IChatService
{
    private readonly IQAAgent _qaAgent;
    private readonly ScholarFlowDbContext _context;
    private readonly ILogger<ChatService> _logger;

    public ChatService(
        IQAAgent qaAgent,
        ScholarFlowDbContext context,
        ILogger<ChatService> logger)
    {
        _qaAgent = qaAgent;
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Asks a question and stores the conversation in chat history
    /// </summary>
    public async Task<ChatResponse> AskQuestionAsync(ChatRequest request)
    {
        try
        {
            _logger.LogInformation("Processing chat request. Query: {Query}, SubmissionId: {Id}", 
                request.Query, request.SubmissionId);

            // Get answer from QA agent
            var response = await _qaAgent.AnswerQuestionAsync(
                request.Query,
                request.Language,
                request.TopK,
                request.SubmissionId);

            // Save user message to chat history
            var userMessage = new ChatMessage
            {
                SubmissionId = request.SubmissionId,
                Role = "user",
                Content = request.Query,
                Language = response.DetectedLanguage,
                Timestamp = DateTime.UtcNow
            };
            _context.ChatMessages.Add(userMessage);

            // Save assistant message to chat history
            var assistantMessage = new ChatMessage
            {
                SubmissionId = request.SubmissionId,
                Role = "assistant",
                Content = response.Answer,
                Language = response.DetectedLanguage,
                CitedSubmissions = string.Join(",", response.CitedSubmissions),
                Timestamp = DateTime.UtcNow
            };
            _context.ChatMessages.Add(assistantMessage);

            await _context.SaveChangesAsync();

            _logger.LogInformation("Chat request completed successfully");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to process chat request");
            throw;
        }
    }

    /// <summary>
    /// Retrieves chat history for a submission
    /// </summary>
    public async Task<ChatHistoryResponse> GetChatHistoryAsync(Guid submissionId)
    {
        try
        {
            _logger.LogInformation("Retrieving chat history for submission: {SubmissionId}", submissionId);

            var messages = await _context.ChatMessages
                .Where(m => m.SubmissionId == submissionId)
                .OrderBy(m => m.Timestamp)
                .ToListAsync();

            var response = new ChatHistoryResponse
            {
                SubmissionId = submissionId,
                Messages = messages.Select(m => new ChatMessageDto
                {
                    Id = m.Id,
                    Role = m.Role,
                    Content = m.Content,
                    Language = m.Language,
                    CitedSubmissions = string.IsNullOrEmpty(m.CitedSubmissions)
                        ? new List<Guid>()
                        : m.CitedSubmissions.Split(',', StringSplitOptions.RemoveEmptyEntries)
                            .Select(id => Guid.Parse(id))
                            .ToList(),
                    Timestamp = m.Timestamp
                }).ToList()
            };

            _logger.LogInformation("Retrieved {Count} messages", response.Messages.Count);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve chat history for submission: {SubmissionId}", submissionId);
            throw;
        }
    }

    /// <summary>
    /// Deletes all chat history for a submission
    /// </summary>
    public async Task DeleteChatHistoryAsync(Guid submissionId)
    {
        try
        {
            _logger.LogInformation("Deleting chat history for submission: {SubmissionId}", submissionId);

            var messages = await _context.ChatMessages
                .Where(m => m.SubmissionId == submissionId)
                .ToListAsync();

            _context.ChatMessages.RemoveRange(messages);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Deleted {Count} messages", messages.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to delete chat history for submission: {SubmissionId}", submissionId);
            throw;
        }
    }
}
