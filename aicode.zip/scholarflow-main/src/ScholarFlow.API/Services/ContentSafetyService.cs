using Microsoft.SemanticKernel;
using ScholarFlow.API.DTOs.Agents;

namespace ScholarFlow.API.Services;

/// <summary>
/// Service for content safety and toxicity detection
/// </summary>
public interface IContentSafetyService
{
    /// <summary>
    /// Analyze text for toxicity and inappropriate content
    /// </summary>
    Task<ContentSafetyResult> AnalyzeTextAsync(string text, double threshold);
}

/// <summary>
/// Implementation of content safety using Azure OpenAI for toxicity analysis
/// </summary>
public class ContentSafetyService : IContentSafetyService
{
    private readonly Kernel _kernel;
    private readonly ILogger<ContentSafetyService> _logger;

    private const int MaxTextLength = 5000; // characters

    private const string ToxicityAnalysisPrompt = @"
You are a content safety analyzer. Analyze the following academic text for inappropriate content across these categories:
1. Hate speech or discriminatory language (0-10 scale)
2. Sexual or inappropriate content (0-10 scale)
3. Violence or harmful content (0-10 scale)
4. Self-harm content (0-10 scale)

Text to analyze:
{{text}}

Provide a JSON response with severity scores for each category and an overall toxicity assessment:
```json
{
  ""hate_severity"": <0-10>,
  ""sexual_severity"": <0-10>,
  ""violence_severity"": <0-10>,
  ""selfharm_severity"": <0-10>,
  ""overall_toxicity"": <0-10>,
  ""flagged_categories"": [""category1"", ""category2""],
  ""explanation"": ""Brief explanation""
}
```

Be objective and consider academic context. Scientific discussions are not toxic.";

    public ContentSafetyService(
        Kernel kernel,
        ILogger<ContentSafetyService> logger)
    {
        _kernel = kernel;
        _logger = logger;
    }

    public async Task<ContentSafetyResult> AnalyzeTextAsync(string text, double threshold)
    {
        try
        {
            _logger.LogInformation("Starting content safety analysis");

            if (string.IsNullOrWhiteSpace(text))
            {
                return new ContentSafetyResult
                {
                    CheckSuccessful = false,
                    ErrorMessage = "Text cannot be empty",
                    Details = "No text provided for content safety analysis"
                };
            }

            // Truncate if too long
            var truncatedText = text.Length > MaxTextLength ? text.Substring(0, MaxTextLength) : text;

            // Build the prompt directly with the text embedded to avoid template parsing issues
            var prompt = @$"You are a content safety analyzer. Analyze the following academic text for inappropriate content across these categories:
1. Hate speech or discriminatory language (0-10 scale)
2. Sexual or inappropriate content (0-10 scale)
3. Violence or harmful content (0-10 scale)
4. Self-harm content (0-10 scale)

Text to analyze:
{truncatedText}

Provide a JSON response with severity scores for each category and an overall toxicity assessment:
```json
{{
  ""hate_severity"": <0-10>,
  ""sexual_severity"": <0-10>,
  ""violence_severity"": <0-10>,
  ""selfharm_severity"": <0-10>,
  ""overall_toxicity"": <0-10>,
  ""flagged_categories"": [""category1"", ""category2""],
  ""explanation"": ""Brief explanation""
}}
```

Be objective and consider academic context. Scientific discussions are not toxic.";

            // Invoke without template variables
            var result = await _kernel.InvokePromptAsync(prompt);
            var response = result.ToString();

            _logger.LogInformation("Content safety analysis response received: {Response}", response);

            // Parse the response
            var safetyResult = ParseAnalysisResponse(response, threshold);
            safetyResult.CheckSuccessful = true;

            _logger.LogInformation("Content safety analysis completed. Toxicity score: {Score}, Above threshold: {IsAbove}",
                safetyResult.ToxicityScore, safetyResult.IsAboveThreshold);

            return safetyResult;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during content safety analysis");
            return new ContentSafetyResult
            {
                CheckSuccessful = false,
                ErrorMessage = ex.Message,
                Details = $"Content safety check failed: {ex.Message}"
            };
        }
    }

    private ContentSafetyResult ParseAnalysisResponse(string response, double threshold)
    {
        try
        {
            // Try to parse JSON response
            var jsonStart = response.IndexOf('{');
            var jsonEnd = response.LastIndexOf('}');

            if (jsonStart >= 0 && jsonEnd > jsonStart)
            {
                var jsonString = response.Substring(jsonStart, jsonEnd - jsonStart + 1);
                var data = System.Text.Json.JsonDocument.Parse(jsonString);
                var root = data.RootElement;

                var hateSeverity = root.TryGetProperty("hate_severity", out var hate) ? hate.GetDouble() : 0.0;
                var sexualSeverity = root.TryGetProperty("sexual_severity", out var sexual) ? sexual.GetDouble() : 0.0;
                var violenceSeverity = root.TryGetProperty("violence_severity", out var violence) ? violence.GetDouble() : 0.0;
                var selfharmSeverity = root.TryGetProperty("selfharm_severity", out var selfharm) ? selfharm.GetDouble() : 0.0;
                var overallToxicity = root.TryGetProperty("overall_toxicity", out var overall) ? overall.GetDouble() : 0.0;

                var flaggedCategories = new List<string>();
                if (root.TryGetProperty("flagged_categories", out var categories) && categories.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    foreach (var category in categories.EnumerateArray())
                    {
                        flaggedCategories.Add(category.GetString() ?? "");
                    }
                }

                var explanation = root.TryGetProperty("explanation", out var exp) ? exp.GetString() : "";

                // Normalize scores from 0-10 scale to 0-1 scale
                var normalizedToxicity = overallToxicity / 10.0;

                return new ContentSafetyResult
                {
                    ToxicityScore = normalizedToxicity,
                    HateSeverity = hateSeverity / 10.0,
                    SexualSeverity = sexualSeverity / 10.0,
                    ViolenceSeverity = violenceSeverity / 10.0,
                    SelfHarmSeverity = selfharmSeverity / 10.0,
                    IsAboveThreshold = normalizedToxicity >= threshold,
                    FlaggedCategories = flaggedCategories,
                    Details = explanation ?? "Content analyzed successfully",
                    CheckSuccessful = true
                };
            }

            // Fallback: simple heuristic analysis
            _logger.LogWarning("Could not parse JSON response, using fallback analysis");
            return PerformFallbackAnalysis(response, threshold);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error parsing analysis response, using fallback");
            return PerformFallbackAnalysis(response, threshold);
        }
    }

    private ContentSafetyResult PerformFallbackAnalysis(string response, double threshold)
    {
        // Simple keyword-based fallback
        var lowerResponse = response.ToLowerInvariant();
        var toxicityIndicators = new[] { "toxic", "inappropriate", "harmful", "offensive", "concerning" };
        var indicatorCount = toxicityIndicators.Count(indicator => lowerResponse.Contains(indicator));

        var estimatedScore = Math.Min(indicatorCount * 0.2, 1.0);

        return new ContentSafetyResult
        {
            ToxicityScore = estimatedScore,
            IsAboveThreshold = estimatedScore >= threshold,
            Details = "Analyzed using fallback method due to parsing error",
            CheckSuccessful = true,
            FlaggedCategories = new List<string>()
        };
    }
}
