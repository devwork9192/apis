using Microsoft.AspNetCore.Http;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration;

namespace ScholarFlow.API.Services;

public interface IProcessService
{
    Task<SubmissionResponse> ProcessSubmissionAsync(IFormFile file, string uploadedBy, string? title = null, string? description = null);
}

/// <summary>
/// Service for orchestrating the complete submission processing pipeline
/// </summary>
public class ProcessService : IProcessService
{
    private readonly IIngestionAgent _ingestionAgent;
    private readonly IProcessOrchestrator _processOrchestrator;
    private readonly ScholarFlowDbContext _context;
    private readonly IAuditService _auditService;
    private readonly ILogger<ProcessService> _logger;

    public ProcessService(
        IIngestionAgent ingestionAgent,
        IProcessOrchestrator processOrchestrator,
        ScholarFlowDbContext context,
        IAuditService auditService,
        ILogger<ProcessService> logger)
    {
        _ingestionAgent = ingestionAgent;
        _processOrchestrator = processOrchestrator;
        _context = context;
        _auditService = auditService;
        _logger = logger;
    }

    /// <summary>
    /// Process a research paper submission through the complete 6-agent pipeline
    /// </summary>
    public async Task<SubmissionResponse> ProcessSubmissionAsync(IFormFile file, string uploadedBy, string? title = null, string? description = null)
    {
        _logger.LogInformation("[PROCESS-SERVICE] Starting process for file: {FileName}", file?.FileName);

        if (file == null)
        {
            throw new ArgumentException(AppConstants.Messages.NoFileProvided);
        }

        // Step 1: Ingest file using IngestionAgent
        var ingestionResult = await _ingestionAgent.IngestSubmissionAsync(file, uploadedBy, title, description);

        if (!ingestionResult.Success)
        {
            _logger.LogWarning("[PROCESS-SERVICE] Ingestion failed: {Error}", ingestionResult.ErrorMessage);
            throw new InvalidOperationException(ingestionResult.ErrorMessage);
        }

        _logger.LogInformation("[PROCESS-SERVICE] Ingestion completed. Starting processing workflow for submission: {SubmissionId}",
            ingestionResult.SubmissionId);

        // Step 2: Get submission from database
        var submission = await _context.Submissions.FindAsync(ingestionResult.SubmissionId);
        if (submission == null)
        {
            throw new InvalidOperationException("Submission record not found after ingestion");
        }

        // Step 3: Update status and run processing workflow
        submission.Status = SubmissionStatus.Preprocessing;
        submission.CurrentStage = ProcessingStage.Preprocess;
        await _context.SaveChangesAsync();

        await _auditService.LogActionAsync(
            submission.Id,
            "ProcessingStarted",
            "Multi-agent workflow initiated",
            uploadedBy,
            stage: ProcessingStage.Preprocess);

        // Step 4: Execute ProcessOrchestrator workflow
        var processingResult = await _processOrchestrator.ExecuteWorkflowAsync(submission);

        if (!processingResult.Success)
        {
            submission.Status = SubmissionStatus.Failed;
            submission.ErrorMessage = processingResult.ErrorMessage;
            await _context.SaveChangesAsync();

            await _auditService.LogActionAsync(
                submission.Id,
                "ProcessingFailed",
                processingResult.ErrorMessage ?? "Unknown error",
                uploadedBy,
                stage: ProcessingStage.Preprocess);

            throw new InvalidOperationException(processingResult.ErrorMessage);
        }

        // Step 5: Update submission with processing results
        // Note: ValidationStep already updates: IsValid, PlagiarismScore, ToxicityScore, 
        // RequiresHumanReview, ValidationErrors, ValidationWarnings
        submission.DetectedLanguage = processingResult.DetectedLanguage;
        submission.TranslatedText = processingResult.TranslatedText;
        submission.Summary = processingResult.Summary;
        
        // ALL submissions require human review/approval
        // Always set to PendingReview status for admin approval
        submission.Status = SubmissionStatus.PendingReview;
        submission.CurrentStage = ProcessingStage.HumanReview;
        submission.ProcessedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        // Log completion with appropriate message
        var completionMessage = "Processing completed - pending human review/approval";

        await _auditService.LogActionAsync(
            submission.Id,
            "ProcessingCompleted",
            completionMessage,
            uploadedBy,
            stage: ProcessingStage.HumanReview);

        _logger.LogInformation("[PROCESS-SERVICE] Processing completed for submission: {SubmissionId}. Status: PendingReview (awaiting approval). Errors: {ErrorCount}, Warnings: {WarningCount}", 
            submission.Id, 
            submission.ValidationErrors != null ? submission.ValidationErrors.Split('\n').Length : 0,
            submission.ValidationWarnings != null ? submission.ValidationWarnings.Split('\n').Length : 0);

        return new SubmissionResponse
        {
            Id = submission.Id,
            Status = submission.Status.ToString(),
            Stage = submission.CurrentStage.ToString(),
            Message = completionMessage
        };
    }
}
