using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Services;

public interface IAuditService
{
    Task LogActionAsync(Guid submissionId, string action, string? details = null, 
        string performedBy = AppConstants.Users.System, string? agentName = null, ProcessingStage? stage = null);
}

public class AuditService : IAuditService
{
    private readonly ScholarFlowDbContext _context;
    private readonly ILogger<AuditService> _logger;

    public AuditService(ScholarFlowDbContext context, ILogger<AuditService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task LogActionAsync(Guid submissionId, string action, string? details = null, 
        string performedBy = AppConstants.Users.System, string? agentName = null, ProcessingStage? stage = null)
    {
        try
        {
            var auditLog = new AuditLog
            {
                SubmissionId = submissionId,
                Action = action,
                Details = details,
                PerformedBy = performedBy,
                AgentName = agentName,
                Stage = stage,
                Timestamp = DateTime.UtcNow
            };

            _context.AuditLogs.Add(auditLog);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Audit log created: {Action} for submission {SubmissionId}", 
                action, submissionId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating audit log for submission {SubmissionId}", submissionId);
            // Don't throw - auditing should not break the main flow
        }
    }
}
