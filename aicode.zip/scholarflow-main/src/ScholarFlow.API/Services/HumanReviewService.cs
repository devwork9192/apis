using Microsoft.EntityFrameworkCore;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.HumanReview;
using ScholarFlow.API.Models;
using System.Text.Json;

namespace ScholarFlow.API.Services;

/// <summary>
/// Service for handling human review workflow
/// </summary>
public class HumanReviewService : IHumanReviewService
{
    private readonly ScholarFlowDbContext _context;
    private readonly IAuditService _auditService;
    private readonly ILogger<HumanReviewService> _logger;

    public HumanReviewService(
        ScholarFlowDbContext context,
        IAuditService auditService,
        ILogger<HumanReviewService> logger)
    {
        _context = context;
        _auditService = auditService;
        _logger = logger;
    }

    public async Task<List<ReviewSummaryResponse>> GetPendingReviewsAsync()
    {
        try
        {
            _logger.LogInformation("Fetching submissions pending human review");

            // Get all submissions requiring human review that haven't been reviewed yet
            // Exclude only Approved and Rejected status (allow PendingReview, Validated, Summarized, etc.)
            var pendingSubmissions = await _context.Submissions
                .Where(s => s.RequiresHumanReview == true && 
                           s.Status != SubmissionStatus.Approved && 
                           s.Status != SubmissionStatus.Rejected)
                .OrderByDescending(s => s.UploadedAt)
                .ToListAsync();

            var reviews = pendingSubmissions.Select(s => MapToReviewSummary(s)).ToList();
            
            // Sort by priority (High first) then by upload date (newest first)
            reviews = reviews
                .OrderByDescending(r => r.ReviewPriority == "High")
                .ThenByDescending(r => r.UploadedAt)
                .ToList();

            _logger.LogInformation("Found {Count} submissions pending review ({HighPriority} high priority, {NormalPriority} normal)", 
                reviews.Count,
                reviews.Count(r => r.ReviewPriority == "High"),
                reviews.Count(r => r.ReviewPriority == "Normal"));
            
            return reviews;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching pending reviews");
            throw;
        }
    }

    public async Task<ReviewSummaryResponse?> GetReviewSummaryAsync(Guid submissionId)
    {
        try
        {
            var submission = await _context.Submissions.FindAsync(submissionId);
            if (submission == null)
            {
                _logger.LogWarning("Submission not found: {SubmissionId}", submissionId);
                return null;
            }

            return MapToReviewSummary(submission);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting review summary for submission: {SubmissionId}", submissionId);
            throw;
        }
    }

    public async Task<ReviewResponse?> ApproveSubmissionAsync(Guid submissionId, ApproveRequest request)
    {
        try
        {
            _logger.LogInformation("Approving submission: {SubmissionId} by {ReviewedBy}", submissionId, request.ReviewedBy);

            var submission = await _context.Submissions.FindAsync(submissionId);
            if (submission == null)
            {
                _logger.LogWarning("Submission not found: {SubmissionId}", submissionId);
                return null;
            }

            // Update submission status
            submission.Status = SubmissionStatus.Approved;
            submission.RequiresHumanReview = false;
            submission.ReviewedBy = request.ReviewedBy;
            submission.ReviewedAt = DateTime.UtcNow;
            submission.RejectionReason = null; // Clear any previous rejection

            await _context.SaveChangesAsync();

            // Audit log
            await _auditService.LogActionAsync(
                submissionId,
                "Approved",
                $"Submission approved by {request.ReviewedBy}. {(string.IsNullOrEmpty(request.Notes) ? "" : $"Notes: {request.Notes}")}",
                request.ReviewedBy,
                "HumanReview",
                ProcessingStage.HumanReview
            );

            _logger.LogInformation("Submission approved: {SubmissionId}", submissionId);

            return new ReviewResponse
            {
                SubmissionId = submissionId,
                Status = submission.Status,
                Message = "Submission approved successfully",
                ReviewedAt = submission.ReviewedAt.Value,
                ReviewedBy = submission.ReviewedBy
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error approving submission: {SubmissionId}", submissionId);
            throw;
        }
    }

    public async Task<ReviewResponse?> RejectSubmissionAsync(Guid submissionId, RejectRequest request)
    {
        try
        {
            _logger.LogInformation("Rejecting submission: {SubmissionId} by {ReviewedBy}", submissionId, request.ReviewedBy);

            var submission = await _context.Submissions.FindAsync(submissionId);
            if (submission == null)
            {
                _logger.LogWarning("Submission not found: {SubmissionId}", submissionId);
                return null;
            }

            // Update submission status
            submission.Status = SubmissionStatus.Rejected;
            submission.RequiresHumanReview = false;
            submission.RejectionReason = request.RejectionReason;
            submission.ReviewedBy = request.ReviewedBy;
            submission.ReviewedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            // Audit log
            await _auditService.LogActionAsync(
                submissionId,
                "Rejected",
                $"Submission rejected by {request.ReviewedBy}. Reason: {request.RejectionReason}",
                request.ReviewedBy,
                "HumanReview",
                ProcessingStage.HumanReview
            );

            _logger.LogInformation("Submission rejected: {SubmissionId}", submissionId);

            return new ReviewResponse
            {
                SubmissionId = submissionId,
                Status = submission.Status,
                Message = "Submission rejected",
                ReviewedAt = submission.ReviewedAt.Value,
                ReviewedBy = submission.ReviewedBy
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error rejecting submission: {SubmissionId}", submissionId);
            throw;
        }
    }

    public async Task<ReviewResponse?> OverrideValidationAsync(Guid submissionId, OverrideRequest request)
    {
        try
        {
            _logger.LogInformation("Overriding validation for submission: {SubmissionId} by {ReviewedBy}", 
                submissionId, request.ReviewedBy);

            var submission = await _context.Submissions.FindAsync(submissionId);
            if (submission == null)
            {
                _logger.LogWarning("Submission not found: {SubmissionId}", submissionId);
                return null;
            }

            var overrideDetails = new List<string>();

            // Override plagiarism score if provided
            if (request.OverridePlagiarismScore.HasValue)
            {
                var oldScore = submission.PlagiarismScore;
                submission.PlagiarismScore = request.OverridePlagiarismScore.Value;
                overrideDetails.Add($"Plagiarism score: {oldScore:P0} → {submission.PlagiarismScore:P0}");
            }

            // Override toxicity score if provided
            if (request.OverrideToxicityScore.HasValue)
            {
                var oldScore = submission.ToxicityScore;
                submission.ToxicityScore = request.OverrideToxicityScore.Value;
                overrideDetails.Add($"Toxicity score: {oldScore:P0} → {submission.ToxicityScore:P0}");
            }

            // Approve anyway despite errors
            if (request.ApproveAnyway == true)
            {
                submission.IsValid = true;
                submission.Status = SubmissionStatus.Approved;
                overrideDetails.Add("Marked as valid despite validation errors");
            }

            submission.RequiresHumanReview = false;
            submission.ReviewedBy = request.ReviewedBy;
            submission.ReviewedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            // Audit log
            var overrideDetailsStr = string.Join("; ", overrideDetails);
            await _auditService.LogActionAsync(
                submissionId,
                "ValidationOverride",
                $"Validation overridden by {request.ReviewedBy}. {overrideDetailsStr}. Reason: {request.OverrideReason}",
                request.ReviewedBy,
                "HumanReview",
                ProcessingStage.HumanReview
            );

            _logger.LogInformation("Validation overridden for submission: {SubmissionId}", submissionId);

            return new ReviewResponse
            {
                SubmissionId = submissionId,
                Status = submission.Status,
                Message = $"Validation overridden: {overrideDetailsStr}",
                ReviewedAt = submission.ReviewedAt.Value,
                ReviewedBy = submission.ReviewedBy
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error overriding validation for submission: {SubmissionId}", submissionId);
            throw;
        }
    }

    private ReviewSummaryResponse MapToReviewSummary(Submission submission)
    {
        // Parse validation errors and warnings from JSON
        var errors = new List<string>();
        var warnings = new List<string>();

        if (!string.IsNullOrEmpty(submission.ValidationErrors))
        {
            try
            {
                errors = JsonSerializer.Deserialize<List<string>>(submission.ValidationErrors) ?? new List<string>();
            }
            catch
            {
                // Fallback: split by newline
                errors = submission.ValidationErrors.Split('\n', StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        }

        if (!string.IsNullOrEmpty(submission.ValidationWarnings))
        {
            try
            {
                warnings = JsonSerializer.Deserialize<List<string>>(submission.ValidationWarnings) ?? new List<string>();
            }
            catch
            {
                // Fallback: split by newline
                warnings = submission.ValidationWarnings.Split('\n', StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        }

        // Determine review priority
        // High priority: Has validation errors OR 5+ warnings OR high plagiarism/toxicity
        var reviewPriority = "Normal";
        if (errors.Count > 0 || 
            warnings.Count >= 5 || 
            (submission.PlagiarismScore.HasValue && submission.PlagiarismScore >= 0.60) ||
            (submission.ToxicityScore.HasValue && submission.ToxicityScore >= 0.45))
        {
            reviewPriority = "High";
        }

        return new ReviewSummaryResponse
        {
            SubmissionId = submission.Id,
            FileName = submission.FileName,
            Title = submission.Title,
            Authors = submission.Authors,
            UploadedAt = submission.UploadedAt,
            UploadedBy = submission.UploadedBy,
            IsValid = submission.IsValid,
            Errors = errors,
            Warnings = warnings,
            ReviewPriority = reviewPriority,
            PlagiarismScore = submission.PlagiarismScore,
            ToxicityScore = submission.ToxicityScore,
            RequiresHumanReview = submission.RequiresHumanReview ?? false,
            RejectionReason = submission.RejectionReason,
            ReviewedBy = submission.ReviewedBy,
            ReviewedAt = submission.ReviewedAt,
            PageCount = submission.PageCount,
            DetectedLanguage = submission.DetectedLanguage,
            WasTranslated = submission.WasTranslated
        };
    }
}
