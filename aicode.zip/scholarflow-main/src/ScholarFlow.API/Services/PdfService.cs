using UglyToad.PdfPig;
using UglyToad.PdfPig.Content;
using ScholarFlow.API.Common;

namespace ScholarFlow.API.Services;

public interface IPdfService
{
    Task<(string text, int pageCount)> ExtractTextAsync(string filePath);
    Task<string> SaveFileAsync(IFormFile file, string uploadPath);
    bool ValidateFile(IFormFile file, out string errorMessage);
}

public class PdfService : IPdfService
{
    private readonly ILogger<PdfService> _logger;

    public PdfService(ILogger<PdfService> logger)
    {
        _logger = logger;
    }

    public bool ValidateFile(IFormFile file, out string errorMessage)
    {
        errorMessage = string.Empty;

        if (file == null || file.Length == 0)
        {
            errorMessage = AppConstants.Messages.FileIsEmptyOrNull;
            return false;
        }

        if (file.Length > AppConstants.FileConstraints.MaxFileSizeBytes)
        {
            errorMessage = $"File size exceeds maximum limit of {AppConstants.FileConstraints.MaxFileSizeMB}MB";
            return false;
        }

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (extension != AppConstants.FileConstraints.PdfExtension)
        {
            errorMessage = AppConstants.Messages.OnlyPdfFilesSupported;
            return false;
        }

        return true;
    }

    public async Task<string> SaveFileAsync(IFormFile file, string uploadPath)
    {
        try
        {
            // Create upload directory if it doesn't exist
            if (!Directory.Exists(uploadPath))
            {
                Directory.CreateDirectory(uploadPath);
            }

            // Generate unique filename
            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
            var filePath = Path.Combine(uploadPath, fileName);

            // Save file
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            _logger.LogInformation("File saved successfully: {FilePath}", filePath);
            return filePath;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error saving file");
            throw;
        }
    }

    public async Task<(string text, int pageCount)> ExtractTextAsync(string filePath)
    {
        return await Task.Run(() =>
        {
            try
            {
                using (var document = PdfDocument.Open(filePath))
                {
                    var text = string.Empty;
                    var pageCount = document.NumberOfPages;
                    var totalCharacters = 0;

                    foreach (Page page in document.GetPages())
                    {
                        var pageText = page.Text;
                        totalCharacters += pageText?.Length ?? 0;
                        text += pageText + "\n\n";
                    }

                    var wordCount = text.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Length;
                    
                    _logger.LogInformation(
                        "Extracted text from {PageCount} pages. Total characters: {Characters}, Words: {Words}, Avg per page: {AvgWords}", 
                        pageCount, 
                        totalCharacters, 
                        wordCount,
                        wordCount / pageCount);

                    return (text.Trim(), pageCount);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting text from PDF: {FilePath}", filePath);
                throw;
            }
        });
    }
}
