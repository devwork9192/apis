using Microsoft.EntityFrameworkCore;
using Microsoft.SemanticKernel;
using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Health;
using System.Diagnostics;

namespace ScholarFlow.API.Services;

public interface IHealthService
{
    Task<HealthCheckResponse> CheckHealthAsync();
}

public class HealthService : IHealthService
{
    private readonly ScholarFlowDbContext _dbContext;
    private readonly Kernel _kernel;
    private readonly ILogger<HealthService> _logger;

    public HealthService(
        ScholarFlowDbContext dbContext,
        Kernel kernel,
        ILogger<HealthService> logger)
    {
        _dbContext = dbContext;
        _kernel = kernel;
        _logger = logger;
    }

    public async Task<HealthCheckResponse> CheckHealthAsync()
    {
        var response = new HealthCheckResponse
        {
            Timestamp = DateTime.UtcNow,
            Components = new Dictionary<string, ComponentHealth>()
        };

        // Check Database
        var dbHealth = await CheckDatabaseHealthAsync();
        response.Components[AppConstants.HealthComponents.Database] = dbHealth;

        // Check AI Service
        var aiHealth = await CheckAIHealthAsync();
        response.Components[AppConstants.HealthComponents.AIService] = aiHealth;

        // Determine overall status
        var allHealthy = response.Components.Values.All(c => c.Status == AppConstants.Status.Healthy);
        response.Status = allHealthy ? AppConstants.Status.Healthy : AppConstants.Status.Unhealthy;

        return response;
    }

    private async Task<ComponentHealth> CheckDatabaseHealthAsync()
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Try to execute a simple query
            await _dbContext.Database.CanConnectAsync();
            
            // Check if we can query the submissions table
            var count = await _dbContext.Submissions.CountAsync();
            
            stopwatch.Stop();
            
            _logger.LogInformation("Database health check passed. Total submissions: {Count}", count);
            
            return new ComponentHealth
            {
                Status = AppConstants.Status.Healthy,
                Message = string.Format(AppConstants.Messages.DatabaseConnectedWithSubmissionCount, count),
                ResponseTimeMs = stopwatch.ElapsedMilliseconds
            };
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Database health check failed");
            
            return new ComponentHealth
            {
                Status = AppConstants.Status.Unhealthy,
                Message = $"{AppConstants.Messages.DatabaseConnectionFailed}: {ex.Message}",
                ResponseTimeMs = stopwatch.ElapsedMilliseconds
            };
        }
    }

    private async Task<ComponentHealth> CheckAIHealthAsync()
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            // Send a simple prompt to verify AI connectivity
            var result = await _kernel.InvokePromptAsync(AppConstants.Prompts.HealthCheckPrompt);
            var response = result.ToString().Trim();
            
            stopwatch.Stop();
            
            _logger.LogInformation("AI service health check passed. Response: {Response}", response);
            
            return new ComponentHealth
            {
                Status = AppConstants.Status.Healthy,
                Message = AppConstants.Messages.AIServiceConnectedAndResponding,
                ResponseTimeMs = stopwatch.ElapsedMilliseconds
            };
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "AI service health check failed");
            
            return new ComponentHealth
            {
                Status = AppConstants.Status.Unhealthy,
                Message = $"{AppConstants.Messages.AIServiceConnectionFailed}: {ex.Message}",
                ResponseTimeMs = stopwatch.ElapsedMilliseconds
            };
        }
    }
}
