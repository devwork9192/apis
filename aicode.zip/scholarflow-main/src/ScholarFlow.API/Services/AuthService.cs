using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using ScholarFlow.API.Configuration;
using ScholarFlow.API.DTOs.Auth;

namespace ScholarFlow.API.Services;

/// <summary>
/// Service interface for authentication operations
/// </summary>
public interface IAuthService
{
    /// <summary>
    /// Authenticate user and generate JWT token
    /// </summary>
    Task<LoginResponse?> AuthenticateAsync(string username, string password);

    /// <summary>
    /// Validate user credentials
    /// </summary>
    bool ValidateCredentials(string username, string password);
}

/// <summary>
/// Authentication service for JWT token generation
/// </summary>
public class AuthService : IAuthService
{
    private readonly JwtSettings _jwtSettings;
    private readonly AuthSettings _authSettings;
    private readonly ILogger<AuthService> _logger;

    public AuthService(
        IOptions<JwtSettings> jwtSettings,
        IOptions<AuthSettings> authSettings,
        ILogger<AuthService> logger)
    {
        _jwtSettings = jwtSettings.Value;
        _authSettings = authSettings.Value;
        _logger = logger;
    }

    /// <summary>
    /// Authenticate user and return JWT token
    /// </summary>
    public async Task<LoginResponse?> AuthenticateAsync(string username, string password)
    {
        try
        {
            // Find user in configuration
            var user = _authSettings.Users.FirstOrDefault(u => 
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));

            if (user == null)
            {
                _logger.LogWarning("Authentication failed: User {Username} not found", username);
                return null;
            }

            // Validate password (simple comparison for now, should use hashing in production)
            if (!user.Password.Equals(password))
            {
                _logger.LogWarning("Authentication failed: Invalid password for user {Username}", username);
                return null;
            }

            // Generate token
            var token = GenerateJwtToken(user);
            var expiresAt = DateTime.UtcNow.AddMinutes(_jwtSettings.ExpirationMinutes);

            _logger.LogInformation("User {Username} authenticated successfully with role {Role}", username, user.Role);

            return await Task.FromResult(new LoginResponse
            {
                Token = token,
                Role = user.Role,
                Username = user.Username,
                ExpiresAt = expiresAt
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during authentication for user {Username}", username);
            return null;
        }
    }

    /// <summary>
    /// Validate user credentials without generating token
    /// </summary>
    public bool ValidateCredentials(string username, string password)
    {
        var user = _authSettings.Users.FirstOrDefault(u => 
            u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));

        return user != null && user.Password.Equals(password);
    }

    /// <summary>
    /// Generate JWT token for authenticated user
    /// </summary>
    private string GenerateJwtToken(UserConfig user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.SecretKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Email, user.Username),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Sub, user.Username),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString())
        };

        var token = new JwtSecurityToken(
            issuer: _jwtSettings.Issuer,
            audience: _jwtSettings.Audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(_jwtSettings.ExpirationMinutes),
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
