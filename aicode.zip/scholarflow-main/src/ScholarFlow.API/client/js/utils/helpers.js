/**
 * Format date to readable string
 */
export function formatDate(dateString) {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

/**
 * Format file size to human readable
 */
export function formatFileSize(bytes) {
  if (!bytes || bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

/**
 * Sanitize HTML to prevent XSS
 */
export function sanitizeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/**
 * Debounce function calls
 */
export function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * Deep clone object
 */
export function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

/**
 * Get status badge color
 */
export function getStatusColor(status) {
  const statusColors = {
    'Uploaded': 'blue',
    'Preprocessing': 'blue',
    'LanguageDetected': 'blue',
    'Translating': 'purple',
    'Translated': 'purple',
    'Extracting': 'orange',
    'Extracted': 'orange',
    'Validating': 'yellow',
    'Validated': 'yellow',
    'Summarizing': 'teal',
    'Summarized': 'teal',
    'PendingReview': 'amber',
    'Approved': 'green',
    'Rejected': 'red',
    'Failed': 'red'
  };
  return statusColors[status] || 'gray';
}
