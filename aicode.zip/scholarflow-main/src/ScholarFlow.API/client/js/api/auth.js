import { apiClient } from './client.js';
import { config } from '../config.js';
import { store } from '../state/store.js';

/**
 * Login user
 */
export async function login(username, password) {
  const response = await apiClient.post('/auth/login', {
    username,
    password,
  });

  // Store token and user info
  localStorage.setItem(config.storageKeys.authToken, response.token);
  localStorage.setItem(config.storageKeys.userInfo, JSON.stringify(response.user));

  // Update store
  store.setState({
    token: response.token,
    user: response.user,
    isAuthenticated: true,
  });

  return response;
}

/**
 * Logout user
 */
export function logout() {
  // Clear storage
  localStorage.removeItem(config.storageKeys.authToken);
  localStorage.removeItem(config.storageKeys.userInfo);

  // Clear store
  store.setState({
    token: null,
    user: null,
    isAuthenticated: false,
  });

  // Redirect to login
  window.location.hash = config.routes.login;
}

/**
 * Check if user is authenticated and restore session
 */
export function restoreSession() {
  const token = localStorage.getItem(config.storageKeys.authToken);
  const userJson = localStorage.getItem(config.storageKeys.userInfo);

  if (token && userJson) {
    try {
      const user = JSON.parse(userJson);
      store.setState({
        token,
        user,
        isAuthenticated: true,
      });
      return true;
    } catch (error) {
      console.error('Failed to restore session:', error);
      logout();
      return false;
    }
  }

  return false;
}

/**
 * Get current user
 */
export function getCurrentUser() {
  return store.getState().user;
}

/**
 * Check if user has specific role
 */
export function hasRole(role) {
  const user = getCurrentUser();
  return user && user.role === role;
}
