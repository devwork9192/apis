import { apiClient } from './client.js';

/**
 * Get all submissions (for dashboard)
 */
export async function getAllSubmissions() {
  return await apiClient.get('/submissions');
}

/**
 * Get submission by ID
 */
export async function getSubmission(id) {
  return await apiClient.get(`/submissions/${id}`);
}

/**
 * Get submission by ID (alias for consistency)
 */
export async function getSubmissionById(id) {
  return await apiClient.get(`/submissions/${id}`);
}

/**
 * Get submission status
 */
export async function getSubmissionStatus(id) {
  return await apiClient.get(`/submissions/${id}/status`);
}

/**
 * Upload and process a document
 */
export async function processSubmission(file, uploadedBy = 'user', title = null, description = null) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('uploadedBy', uploadedBy);
  if (title) formData.append('title', title);
  if (description) formData.append('description', description);

  return await apiClient.post('/process', formData);
}

/**
 * Upload a submission with title and description
 * Note: Currently the API only accepts file and uploadedBy via /process endpoint
 */
export async function uploadSubmission(file, title, description = '', uploadedBy = 'user') {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('uploadedBy', uploadedBy);
  // Note: title and description are not currently supported by the API
  // They can be added later when the API is updated

  return await apiClient.post('/process', formData);
}

/**
 * Get submission report
 */
export async function getSubmissionReport(id) {
  return await apiClient.get(`/submissions/${id}/report`);
}

/**
 * Delete submission
 */
export async function deleteSubmission(id) {
  return await apiClient.delete(`/submissions/${id}`);
}
