import { apiClient } from './client.js';

/**
 * Ask a question (RAG-based Q&A)
 */
export async function askQuestion(query, submissionId = null) {
  return await apiClient.post('/chat', {
    Query: query,
    SubmissionId: submissionId,
    TopK: 3
  });
}

/**
 * Send a message in chat (alias for consistency)
 */
export async function sendMessage(submissionId, message) {
  return await apiClient.post('/chat', {
    Query: message,
    SubmissionId: submissionId,
    TopK: 3
  });
}

/**
 * Get chat history for a submission
 */
export async function getChatHistory(submissionId) {
  return await apiClient.get(`/chat/${submissionId}/history`);
}

/**
 * Clear chat history
 */
export async function clearChatHistory(submissionId) {
  return await apiClient.delete(`/chat/${submissionId}/history`);
}
