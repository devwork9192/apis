import { apiClient } from './client.js';

/**
 * Get all pending reviews
 */
export async function getPendingReviews() {
  return await apiClient.get('/review/pending');
}

/**
 * Get review queue (with optional filters)
 */
export async function getReviewQueue(status = '', searchTerm = '') {
  let url = '/review/pending';
  const params = new URLSearchParams();
  
  if (status) params.append('status', status);
  if (searchTerm) params.append('search', searchTerm);
  
  const queryString = params.toString();
  if (queryString) url += '?' + queryString;
  
  return await apiClient.get(url);
}

/**
 * Get review details
 */
export async function getReviewDetails(submissionId) {
  return await apiClient.get(`/review/${submissionId}`);
}

/**
 * Approve submission
 */
export async function approveSubmission(submissionId, reviewedBy, notes = '') {
  return await apiClient.post(`/review/${submissionId}/approve`, {
    reviewedBy,
    notes,
  });
}

/**
 * Reject submission
 */
export async function rejectSubmission(submissionId, reviewedBy, reason, validationIssues = []) {
  return await apiClient.post(`/review/${submissionId}/reject`, {
    reviewedBy,
    reason,
    validationIssues,
  });
}

/**
 * Review submission (approve or reject)
 */
export async function reviewSubmission(submissionId, approved, reason = '') {
  const endpoint = approved ? 'approve' : 'reject';
  
  // Get current user (should get from auth context)
  const reviewedBy = 'admin'; // TODO: Get from user context
  
  const body = approved 
    ? { ReviewedBy: reviewedBy, Notes: reason }
    : { ReviewedBy: reviewedBy, RejectionReason: reason };
  
  return await apiClient.post(`/review/${submissionId}/${endpoint}`, body);
}
