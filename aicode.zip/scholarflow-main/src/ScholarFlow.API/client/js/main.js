import { router } from './router.js';
import { config } from './config.js';
import { store } from './state/store.js';
import { restoreSession } from './api/auth.js';
import { initTheme } from './components/theme.js';
import { initNotifications } from './components/notifications.js';
import { renderHome } from './pages/home.js';
import { renderLogin } from './pages/login.js';
import { renderDashboard } from './pages/dashboard.js';
import { renderUpload } from './pages/upload.js';
import { renderSubmissionDetails } from './pages/submission-details.js';
import { renderChat } from './pages/chat.js';
import { renderReview } from './pages/review.js';

/**
 * Initialize the application
 */
async function init() {
  console.log('🚀 Initializing ScholarFlow UI...');
  
  // Initialize theme system
  initTheme();
  
  // Initialize notifications
  initNotifications();
  
  // Try to restore previous session
  const sessionRestored = restoreSession();
  console.log('Session restored:', sessionRestored);
  
  // Register routes
  router
    .route('/', renderHome)
    .route(config.routes.login, renderLogin)
    .route(config.routes.dashboard, renderDashboard)
    .route('/upload', renderUpload)
    .route('/submission/:id', renderSubmissionDetails)
    .route('/chat', renderChat)
    .route('/review', renderReview);
    // More routes can be added as needed
  
  // Subscribe to state changes for debugging
  store.subscribe((state) => {
    console.log('State updated:', state);
  });
  
  console.log('✅ ScholarFlow UI initialized');
}

// Start the app
init();
