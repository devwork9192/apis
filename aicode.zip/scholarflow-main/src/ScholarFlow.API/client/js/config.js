// Application configuration
export const config = {
  // API base URL - using relative path since UI is served from same origin
  apiBaseUrl: '/api',
  
  // Local storage keys
  storageKeys: {
    authToken: 'scholarflow_token',
    userInfo: 'scholarflow_user',
    theme: 'scholarflow_theme',
  },
  
  // Polling interval for submission status (milliseconds)
  pollingInterval: 2000,
  
  // File upload settings
  upload: {
    maxSizeMB: 50,
    acceptedTypes: ['application/pdf'],
  },
  
  // App routes
  routes: {
    home: '/',
    login: '/login',
    dashboard: '/dashboard',
    upload: '/upload',
    processing: '/processing',
    review: '/review',
    chat: '/chat',
  },
  
  // User roles
  roles: {
    author: 'Author',
    reviewer: 'Reviewer',
  }
};
