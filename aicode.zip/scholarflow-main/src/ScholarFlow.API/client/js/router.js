import { config } from './config.js';
import { store } from './state/store.js';

/**
 * Simple hash-based router
 */
class Router {
  constructor() {
    this.routes = {};
    this.currentRoute = null;
    
    // Listen to hash changes
    window.addEventListener('hashchange', () => this.handleRouteChange());
    window.addEventListener('load', () => this.handleRouteChange());
  }

  /**
   * Register a route
   */
  route(path, handler) {
    this.routes[path] = handler;
    return this;
  }

  /**
   * Navigate to a route
   */
  navigate(path) {
    console.log('Router.navigate called with path:', path);
    window.location.hash = path;
  }

  /**
   * Handle route change
   */
  async handleRouteChange() {
    const hash = window.location.hash.slice(1) || '/';
    const state = store.getState();
    
    console.log('Route change:', { hash, isAuthenticated: state.isAuthenticated });

    // Parse path and query string
    const [path, queryString] = hash.split('?');
    const query = this.parseQuery(queryString);

    // Check if route requires authentication
    const publicRoutes = ['/', config.routes.login];
    const requiresAuth = !publicRoutes.includes(path);

    if (requiresAuth && !state.isAuthenticated) {
      // Redirect to login
      console.log('Auth required, redirecting to login');
      this.navigate(config.routes.login);
      return;
    }

    // Find matching route (including dynamic routes)
    let handler = null;
    let params = {};

    // Try exact match first
    if (this.routes[path]) {
      handler = this.routes[path];
    } else {
      // Try dynamic route matching
      for (const [routePath, routeHandler] of Object.entries(this.routes)) {
        const match = this.matchRoute(routePath, path);
        if (match) {
          handler = routeHandler;
          params = match;
          break;
        }
      }
    }
    
    console.log('Route handler found:', !!handler, 'for path:', path, 'params:', params, 'query:', query);
    
    if (handler) {
      this.currentRoute = hash;
      store.setState({ currentRoute: hash });
      
      // Call handler with params and query
      await handler(params, query);
    } else {
      // 404 - redirect to dashboard or login
      console.log('Route not found, redirecting...');
      this.navigate(state.isAuthenticated ? config.routes.dashboard : config.routes.login);
    }
  }

  /**
   * Match a route pattern with dynamic segments
   * e.g., /submission/:id matches /submission/123
   */
  matchRoute(pattern, path) {
    const patternParts = pattern.split('/');
    const pathParts = path.split('/');

    if (patternParts.length !== pathParts.length) {
      return null;
    }

    const params = {};
    
    for (let i = 0; i < patternParts.length; i++) {
      if (patternParts[i].startsWith(':')) {
        // Dynamic segment
        const paramName = patternParts[i].slice(1);
        params[paramName] = pathParts[i];
      } else if (patternParts[i] !== pathParts[i]) {
        // Static segment doesn't match
        return null;
      }
    }

    return params;
  }

  /**
   * Parse query string into object
   */
  parseQuery(queryString) {
    if (!queryString) return {};
    
    const params = new URLSearchParams(queryString);
    const query = {};
    
    for (const [key, value] of params) {
      query[key] = value;
    }
    
    return query;
  }

  /**
   * Get current route
   */
  getCurrentRoute() {
    return this.currentRoute;
  }
}

// Export singleton instance
export const router = new Router();
