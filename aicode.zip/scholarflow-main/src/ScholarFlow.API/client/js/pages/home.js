import { router } from '../router.js';
import { config } from '../config.js';

/**
 * Render home page (landing page)
 */
export async function renderHome() {
  const content = document.getElementById('main-content');
  
  content.innerHTML = `
    <div style="
      min-height: 80vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 2rem;
    ">
      <div style="max-width: 800px;">
        <!-- Icon -->
        <div style="font-size: 5rem; margin-bottom: 1.5rem;">📚</div>
        
        <!-- Title -->
        <h1 style="
          font-size: 3rem;
          font-weight: 800;
          margin-bottom: 1rem;
          background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-secondary) 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        ">
          ScholarFlow
        </h1>
        
        <p style="
          font-size: 1.25rem;
          color: var(--text-secondary);
          margin-bottom: 1rem;
        ">
          AI-Powered Research Document Processor
        </p>
        
        <p style="
          font-size: 1rem;
          color: var(--text-tertiary);
          margin-bottom: 3rem;
        ">
          Automated Academic Paper Processing & Analysis System
        </p>
        
        <!-- Features -->
        <div class="feature-grid" style="
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 1.5rem;
          margin-bottom: 3rem;
          text-align: left;
          max-width: 1000px;
          margin-left: auto;
          margin-right: auto;
        ">
          <div class="card">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">🔍</div>
            <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Smart Extraction</h3>
            <p style="font-size: 0.875rem; color: var(--text-secondary); margin: 0;">
              Automatic metadata extraction using AI
            </p>
          </div>
          
          <div class="card">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">🌐</div>
            <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Language Detection</h3>
            <p style="font-size: 0.875rem; color: var(--text-secondary); margin: 0;">
              Multi-language support with translation
            </p>
          </div>
          
          <div class="card">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">✅</div>
            <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Content Safety Check</h3>
            <p style="font-size: 0.875rem; color: var(--text-secondary); margin: 0;">
              Keep content within ethical boundaries
            </p>
          </div>
          
          <div class="card">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">📊</div>
            <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Plagiarism Detection</h3>
            <p style="font-size: 0.875rem; color: var(--text-secondary); margin: 0;">
              Multi-level similarity score analysis
            </p>
          </div>
          
          <div class="card">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">💬</div>
            <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Q&A System</h3>
            <p style="font-size: 0.875rem; color: var(--text-secondary); margin: 0;">
              RAG-based question answering
            </p>
          </div>
          
          <div class="card">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">👥</div>
            <h3 style="font-size: 1rem; margin-bottom: 0.5rem;">Admin Review</h3>
            <p style="font-size: 0.875rem; color: var(--text-secondary); margin: 0;">
              Document approval workflow
            </p>
          </div>
        </div>
        
        <!-- Login buttons -->
        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
          <button id="user-login-btn" class="btn btn-primary btn-lg">
            👤 User Login
          </button>
          <button id="admin-login-btn" class="btn btn-secondary btn-lg">
            🔐 Admin Login
          </button>
        </div>
      </div>
    </div>
  `;
  
  // Attach event listeners
  const userBtn = document.getElementById('user-login-btn');
  const adminBtn = document.getElementById('admin-login-btn');
  
  console.log('Home page rendered, attaching event listeners...');
  console.log('User button:', userBtn);
  console.log('Admin button:', adminBtn);
  
  if (userBtn) {
    userBtn.addEventListener('click', () => {
      console.log('User login clicked');
      router.navigate(config.routes.login + '?role=user');
    });
  }
  
  if (adminBtn) {
    adminBtn.addEventListener('click', () => {
      console.log('Admin login clicked');
      router.navigate(config.routes.login + '?role=admin');
    });
  }
}
