import { getReviewQueue, reviewSubmission } from '../api/review.js';
import { showNotification } from '../components/notifications.js';
import { renderNavbar } from '../components/navbar.js';

export async function renderReview(params, query) {
    renderNavbar();
    const container = document.getElementById('main-content');
    container.innerHTML = `
        <div class="page-container">
            <div class="page-header">
                <h1>Review Queue</h1>
                <p>Review and approve/reject submitted documents</p>
            </div>

            <div class="review-filters">
                <select id="filter-status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="UnderReview" selected>Under Review</option>
                    <option value="Completed">Completed</option>
                </select>
                <input 
                    type="text" 
                    id="search-review" 
                    class="form-control" 
                    placeholder="Search by title..."
                />
            </div>

            <div id="review-queue-container">
                <div class="loading">Loading review queue...</div>
            </div>
        </div>
    `;

    await initReview();
}

async function initReview() {
    await loadReviewQueue();

    // Filters
    const filterStatus = document.getElementById('filter-status');
    const searchInput = document.getElementById('search-review');

    filterStatus?.addEventListener('change', loadReviewQueue);
    searchInput?.addEventListener('input', debounce(loadReviewQueue, 300));
}

async function loadReviewQueue() {
    const container = document.getElementById('review-queue-container');
    const filterStatus = document.getElementById('filter-status')?.value;
    const searchTerm = document.getElementById('search-review')?.value;

    try {
        const submissions = await getReviewQueue(filterStatus, searchTerm);

        if (submissions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📋</div>
                    <h3>No submissions to review</h3>
                    <p>All caught up! Check back later for new submissions.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="review-grid">
                ${submissions.map(sub => renderReviewCard(sub)).join('')}
            </div>
        `;

        // Add event listeners
        submissions.forEach(sub => {
            const viewBtn = document.getElementById(`view-${sub.id}`);
            const approveBtn = document.getElementById(`approve-${sub.id}`);
            const rejectBtn = document.getElementById(`reject-${sub.id}`);

            viewBtn?.addEventListener('click', () => showReviewModal(sub));
            approveBtn?.addEventListener('click', () => handleApprove(sub.id));
            rejectBtn?.addEventListener('click', () => handleReject(sub.id));
        });

    } catch (error) {
        console.error('Error loading review queue:', error);
        container.innerHTML = `
            <div class="error-message">
                Failed to load review queue. Please try again.
            </div>
        `;
    }
}

function renderReviewCard(submission) {
    const statusClass = submission.status === 'UnderReview' ? 'status-review' : 'status-completed';
    const showActions = submission.status === 'UnderReview';

    return `
        <div class="review-card">
            <div class="review-card-header">
                <h3>${submission.title}</h3>
                <span class="status-badge ${statusClass}">
                    ${submission.status === 'UnderReview' ? '👁️ Under Review' : '✓ Reviewed'}
                </span>
            </div>
            
            <div class="review-card-body">
                <p><strong>Submitted:</strong> ${formatDate(submission.submittedAt)}</p>
                <p><strong>Author:</strong> ${submission.authorName || 'N/A'}</p>
                ${submission.description ? `<p><strong>Description:</strong> ${submission.description}</p>` : ''}
                
                ${submission.qaScore !== undefined ? `
                    <div class="qa-score">
                        <strong>Quality Score:</strong>
                        <div class="score-bar">
                            <div class="score-fill" style="width: ${submission.qaScore}%"></div>
                        </div>
                        <span>${submission.qaScore}%</span>
                    </div>
                ` : ''}
            </div>

            <div class="review-card-actions">
                <button type="button" class="btn btn-secondary" id="view-${submission.id}">
                    View Details
                </button>
                ${showActions ? `
                    <button type="button" class="btn btn-success" id="approve-${submission.id}">
                        ✓ Approve
                    </button>
                    <button type="button" class="btn btn-danger" id="reject-${submission.id}">
                        ✗ Reject
                    </button>
                ` : ''}
            </div>
        </div>
    `;
}

function showReviewModal(submission) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2>${submission.title}</h2>
                <button type="button" class="modal-close" id="close-modal">×</button>
            </div>
            <div class="modal-body">
                <div class="review-details">
                    <h3>Submission Information</h3>
                    <p><strong>Submitted:</strong> ${formatDate(submission.submittedAt)}</p>
                    <p><strong>Author:</strong> ${submission.authorName || 'N/A'}</p>
                    ${submission.description ? `<p><strong>Description:</strong> ${submission.description}</p>` : ''}

                    ${submission.processedData ? `
                        <h3>Processing Results</h3>
                        ${renderProcessingResults(submission.processedData)}
                    ` : ''}

                    ${submission.pdfUrl ? `
                        <div class="pdf-viewer">
                            <h3>Document Preview</h3>
                            <iframe src="${submission.pdfUrl}" width="100%" height="600px"></iframe>
                        </div>
                    ` : ''}
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="modal-close-btn">Close</button>
                ${submission.status === 'UnderReview' ? `
                    <button type="button" class="btn btn-success" id="modal-approve-btn">Approve</button>
                    <button type="button" class="btn btn-danger" id="modal-reject-btn">Reject</button>
                ` : ''}
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    modal.style.display = 'flex';

    // Event listeners
    const closeModal = () => {
        modal.remove();
    };

    document.getElementById('close-modal')?.addEventListener('click', closeModal);
    document.getElementById('modal-close-btn')?.addEventListener('click', closeModal);
    document.getElementById('modal-approve-btn')?.addEventListener('click', () => {
        handleApprove(submission.id);
        closeModal();
    });
    document.getElementById('modal-reject-btn')?.addEventListener('click', () => {
        handleReject(submission.id);
        closeModal();
    });

    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });
}

async function handleApprove(submissionId) {
    const reason = prompt('Add approval comment (optional):');
    
    try {
        await reviewSubmission(submissionId, true, reason || '');
        showNotification('Submission approved successfully', 'success');
        await loadReviewQueue();
    } catch (error) {
        console.error('Approval error:', error);
        showNotification('Failed to approve submission', 'error');
    }
}

async function handleReject(submissionId) {
    const reason = prompt('Please provide a reason for rejection:');
    if (!reason || !reason.trim()) {
        showNotification('Rejection reason is required', 'error');
        return;
    }

    try {
        await reviewSubmission(submissionId, false, reason);
        showNotification('Submission rejected', 'success');
        await loadReviewQueue();
    } catch (error) {
        console.error('Rejection error:', error);
        showNotification('Failed to reject submission', 'error');
    }
}

function renderProcessingResults(data) {
    let html = '<div class="processing-results">';

    if (data.summary) {
        html += `
            <div class="result-section">
                <h4>Summary</h4>
                <p>${data.summary}</p>
            </div>
        `;
    }

    if (data.extractedData) {
        html += `
            <div class="result-section">
                <h4>Extracted Data</h4>
                <table class="data-table">
                    ${Object.entries(data.extractedData).map(([key, value]) => `
                        <tr>
                            <td><strong>${formatKey(key)}</strong></td>
                            <td>${value}</td>
                        </tr>
                    `).join('')}
                </table>
            </div>
        `;
    }

    if (data.qaResults && data.qaResults.length > 0) {
        html += `
            <div class="result-section">
                <h4>Quality Assessment</h4>
                <ul class="qa-list">
                    ${data.qaResults.map(qa => `
                        <li class="qa-item ${qa.passed ? 'qa-pass' : 'qa-fail'}">
                            <span class="qa-icon">${qa.passed ? '✓' : '✗'}</span>
                            ${qa.message}
                        </li>
                    `).join('')}
                </ul>
            </div>
        `;
    }

    html += '</div>';
    return html;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatKey(key) {
    return key
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase())
        .trim();
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
