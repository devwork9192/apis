import { getAllSubmissions } from '../api/submissions.js';
import { getCurrentUser } from '../api/auth.js';
import { router } from '../router.js';
import { config } from '../config.js';
import { formatDate, getStatusColor } from '../utils/helpers.js';
import { showNotification } from '../components/notifications.js';
import { renderNavbar } from '../components/navbar.js';

/**
 * Render dashboard page
 */
export async function renderDashboard() {
  renderNavbar();
  
  const content = document.getElementById('main-content');
  const user = getCurrentUser();
  const isReviewer = user?.role === config.roles.reviewer;
  
  // Show loading
  content.innerHTML = `
    <div style="display: flex; justify-content: center; align-items: center; min-height: 60vh;">
      <div class="spinner"></div>
    </div>
  `;
  
  try {
    const submissions = await getAllSubmissions();
    
    content.innerHTML = `
      <div>
        <!-- Header -->
        <div style="margin-bottom: 2rem;">
          <h1 style="margin-bottom: 0.5rem;">
            ${isReviewer ? '📋 Review Dashboard' : '📊 My Documents'}
          </h1>
          <p style="color: var(--text-secondary); margin: 0;">
            ${isReviewer 
              ? 'Review and approve submitted research documents' 
              : 'View and manage your uploaded research papers'}
          </p>
        </div>
        
        <!-- Quick stats -->
        <div style="
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-bottom: 2rem;
        ">
          <div class="card">
            <div style="color: var(--text-secondary); font-size: 0.875rem; margin-bottom: 0.25rem;">
              Total Submissions
            </div>
            <div style="font-size: 2rem; font-weight: 700; color: var(--text-primary);">
              ${submissions.length}
            </div>
          </div>
          
          <div class="card">
            <div style="color: var(--text-secondary); font-size: 0.875rem; margin-bottom: 0.25rem;">
              ${isReviewer ? 'Pending Reviews' : 'Processing'}
            </div>
            <div style="font-size: 2rem; font-weight: 700; color: var(--color-warning);">
              ${submissions.filter(s => 
                isReviewer 
                  ? s.status === 'PendingReview' 
                  : !['Approved', 'Rejected', 'Failed'].includes(s.status)
              ).length}
            </div>
          </div>
          
          <div class="card">
            <div style="color: var(--text-secondary); font-size: 0.875rem; margin-bottom: 0.25rem;">
              Approved
            </div>
            <div style="font-size: 2rem; font-weight: 700; color: var(--color-success);">
              ${submissions.filter(s => s.status === 'Approved').length}
            </div>
          </div>
          
          <div class="card">
            <div style="color: var(--text-secondary); font-size: 0.875rem; margin-bottom: 0.25rem;">
              Rejected
            </div>
            <div style="font-size: 2rem; font-weight: 700; color: var(--color-error);">
              ${submissions.filter(s => s.status === 'Rejected').length}
            </div>
          </div>
        </div>
        
        <!-- Actions -->
        ${!isReviewer ? `
          <div style="margin-bottom: 2rem;">
            <button id="upload-btn" class="btn btn-primary">
              📤 Upload New Document
            </button>
          </div>
        ` : ''}
        
        <!-- Submissions table -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">
              ${isReviewer ? 'All Submissions' : 'My Submissions'}
            </h3>
          </div>
          
          ${submissions.length === 0 ? `
            <div style="text-align: center; padding: 3rem; color: var(--text-secondary);">
              <div style="font-size: 3rem; margin-bottom: 1rem;">📄</div>
              <p style="margin: 0;">No submissions yet</p>
              ${!isReviewer ? `
                <button id="upload-btn-empty" class="btn btn-primary" style="margin-top: 1rem;">
                  Upload Your First Document
                </button>
              ` : ''}
            </div>
          ` : `
            <div style="overflow-x: auto;">
              <table style="width: 100%; border-collapse: collapse;">
                <thead>
                  <tr style="border-bottom: 1px solid var(--border-color);">
                    <th style="text-align: left; padding: 0.75rem; font-weight: 600; font-size: 0.875rem; color: var(--text-secondary);">
                      File Name
                    </th>
                    <th style="text-align: left; padding: 0.75rem; font-weight: 600; font-size: 0.875rem; color: var(--text-secondary);">
                      Status
                    </th>
                    <th style="text-align: left; padding: 0.75rem; font-weight: 600; font-size: 0.875rem; color: var(--text-secondary);">
                      Uploaded
                    </th>
                    <th style="text-align: left; padding: 0.75rem; font-weight: 600; font-size: 0.875rem; color: var(--text-secondary);">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  ${submissions.map(sub => `
                    <tr style="border-bottom: 1px solid var(--border-color);">
                      <td style="padding: 0.75rem;">
                        <div style="font-weight: 500; color: var(--text-primary);">
                          ${sub.fileName || 'Unknown'}
                        </div>
                        <div style="font-size: 0.75rem; color: var(--text-tertiary);">
                          ${sub.uploadedBy || 'System'}
                        </div>
                      </td>
                      <td style="padding: 0.75rem;">
                        <span class="badge badge-${getStatusColor(sub.status)}">
                          ${sub.status}
                        </span>
                      </td>
                      <td style="padding: 0.75rem; color: var(--text-secondary); font-size: 0.875rem;">
                        ${sub.status}
                      </td>
                      <td style="padding: 0.75rem; color: var(--text-secondary); font-size: 0.875rem;">
                        ${formatDate(sub.uploadedAt)}
                      </td>
                      <td style="padding: 0.75rem;">
                        <div style="display: flex; gap: 0.5rem;">
                          <button class="btn btn-secondary btn-sm view-btn" data-id="${sub.id}">
                            👁️ View
                          </button>
                          ${['Completed', 'Approved'].includes(sub.status) ? `
                            <button class="btn btn-primary btn-sm chat-btn" data-id="${sub.id}">
                              💬 Chat
                            </button>
                          ` : ''}
                        </div>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `}
        </div>
      </div>
    `;
    
    // Attach event listeners
    document.getElementById('upload-btn')?.addEventListener('click', () => {
      router.navigate('/upload');
    });
    
    document.getElementById('upload-btn-empty')?.addEventListener('click', () => {
      router.navigate('/upload');
    });
    
    document.querySelectorAll('.view-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.getAttribute('data-id');
        router.navigate(`/submission/${id}`);
      });
    });
    
    document.querySelectorAll('.chat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.target.getAttribute('data-id');
        router.navigate(`/chat?submissionId=${id}`);
      });
    });
    
  } catch (error) {
    console.error('Error loading dashboard:', error);
    content.innerHTML = `
      <div class="card" style="text-align: center; padding: 3rem;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">⚠️</div>
        <h3>Failed to load submissions</h3>
        <p style="color: var(--text-secondary);">${error.message}</p>
        <button class="btn btn-primary" onclick="location.reload()">
          Retry
        </button>
      </div>
    `;
  }
}
