import { sendMessage, getChatHistory } from '../api/chat.js';
import { showNotification } from '../components/notifications.js';
import { store } from '../state/store.js';
import { renderNavbar } from '../components/navbar.js';

export async function renderChat(params, query) {
    renderNavbar();
    const submissionId = query?.submissionId;
    
    if (!submissionId) {
        showNotification('No submission specified', 'error');
        window.location.hash = '#/dashboard';
        return;
    }

    const container = document.getElementById('main-content');
    container.innerHTML = `
        <div class="page-container chat-page">
            <div class="page-header">
                <button type="button" class="btn btn-text" id="back-btn">← Back</button>
                <h1>Chat with Document</h1>
                <button type="button" class="btn btn-text" id="clear-chat-btn">Clear Chat</button>
            </div>

            <div class="chat-container">
                <div class="chat-messages" id="chat-messages">
                    <div class="chat-welcome">
                        <h3>💬 Ask questions about your document</h3>
                        <p>I'll help you understand the content using AI-powered analysis. Ask me anything!</p>
                    </div>
                </div>

                <div class="chat-input-container">
                    <textarea 
                        id="chat-input" 
                        class="chat-input"
                        placeholder="Type your question here..."
                        rows="1"
                    ></textarea>
                    <button type="button" class="btn btn-primary" id="send-btn" disabled>
                        Send
                    </button>
                </div>
            </div>
        </div>
    `;

    await initChat(submissionId);
}

async function initChat(submissionId) {
    const backBtn = document.getElementById('back-btn');
    const clearBtn = document.getElementById('clear-chat-btn');
    const chatInput = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    const messagesContainer = document.getElementById('chat-messages');

    // Load chat history
    await loadChatHistory(submissionId);

    // Back button
    backBtn?.addEventListener('click', () => {
        window.location.hash = `#/submission/${submissionId}`;
    });

    // Clear chat
    clearBtn?.addEventListener('click', () => {
        if (confirm('Are you sure you want to clear the chat history?')) {
            messagesContainer.innerHTML = `
                <div class="chat-welcome">
                    <h3>💬 Ask questions about your document</h3>
                    <p>I'll help you understand the content using AI-powered analysis. Ask me anything!</p>
                </div>
            `;
        }
    });

    // Enable/disable send button
    chatInput?.addEventListener('input', () => {
        if (sendBtn) {
            sendBtn.disabled = !chatInput.value.trim();
        }
    });

    // Auto-resize textarea
    chatInput?.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    // Send on Enter (Shift+Enter for new line)
    chatInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    });

    // Send button
    sendBtn?.addEventListener('click', handleSendMessage);

    async function handleSendMessage() {
        const message = chatInput?.value.trim();
        if (!message) return;

        // Add user message to UI
        addMessage('user', message);

        // Clear input
        if (chatInput) {
            chatInput.value = '';
            chatInput.style.height = 'auto';
        }
        if (sendBtn) sendBtn.disabled = true;

        // Show typing indicator
        const typingId = addTypingIndicator();

        try {
            const response = await sendMessage(submissionId, message);
            
            // Remove typing indicator
            removeTypingIndicator(typingId);

            // Extract context from sources
            const context = response.Sources && response.Sources.length > 0
                ? response.Sources.map(s => s.Excerpt)
                : null;

            // Add AI response (use Answer property from API)
            addMessage('assistant', response.Answer, context);

        } catch (error) {
            console.error('Chat error:', error);
            removeTypingIndicator(typingId);
            showNotification('Failed to get response. Please try again.', 'error');
            addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
        }
    }

    async function loadChatHistory(submissionId) {
        try {
            const history = await getChatHistory(submissionId);
            
            // The API returns ChatHistoryResponse with Messages array
            const messages = history?.Messages || history?.messages || [];
            
            if (messages && messages.length > 0) {
                // Remove welcome message
                const welcome = messagesContainer.querySelector('.chat-welcome');
                if (welcome) welcome.remove();

                // Add messages
                messages.forEach(msg => {
                    // Extract context from sources if it's an assistant message
                    const context = msg.Sources && msg.Sources.length > 0
                        ? msg.Sources.map(s => s.Excerpt)
                        : null;
                    addMessage(msg.Role || msg.role, msg.Content || msg.content, context, false);
                });
            }
        } catch (error) {
            console.error('Error loading chat history:', error);
        }
    }

    function addMessage(role, content, context = null, scroll = true) {
        const welcome = messagesContainer.querySelector('.chat-welcome');
        if (welcome) welcome.remove();

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message chat-message-${role}`;
        
        let contextHtml = '';
        if (context && context.length > 0) {
            contextHtml = `
                <div class="chat-context">
                    <strong>📚 Relevant excerpts:</strong>
                    ${context.map(c => `<p class="context-snippet">${c}</p>`).join('')}
                </div>
            `;
        }

        messageDiv.innerHTML = `
            <div class="message-avatar">${role === 'user' ? '👤' : '🤖'}</div>
            <div class="message-content">
                <div class="message-text">${formatMessage(content)}</div>
                ${contextHtml}
                <div class="message-time">${new Date().toLocaleTimeString()}</div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);

        if (scroll) {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    function addTypingIndicator() {
        const id = 'typing-' + Date.now();
        const typingDiv = document.createElement('div');
        typingDiv.id = id;
        typingDiv.className = 'chat-message chat-message-assistant';
        typingDiv.innerHTML = `
            <div class="message-avatar">🤖</div>
            <div class="message-content">
                <div class="typing-indicator">
                    <span></span><span></span><span></span>
                </div>
            </div>
        `;
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        return id;
    }

    function removeTypingIndicator(id) {
        const indicator = document.getElementById(id);
        if (indicator) indicator.remove();
    }

    function formatMessage(text) {
        // Simple markdown-like formatting
        return text
            .replace(/\n/g, '<br>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>');
    }
}
