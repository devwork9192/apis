import { getSubmissionById } from '../api/submissions.js';
import { showNotification } from '../components/notifications.js';
import { renderNavbar } from '../components/navbar.js';

const statusConfig = {
    'Submitted': { label: 'Submitted', class: 'status-submitted', icon: '📝' },
    'Processing': { label: 'Processing', class: 'status-processing', icon: '⚙️' },
    'Completed': { label: 'Completed', class: 'status-completed', icon: '✓' },
    'Failed': { label: 'Failed', class: 'status-failed', icon: '✗' },
    'UnderReview': { label: 'Under Review', class: 'status-review', icon: '👁️' },
    'Approved': { label: 'Approved', class: 'status-approved', icon: '✓' },
    'Rejected': { label: 'Rejected', class: 'status-rejected', icon: '✗' }
};

export async function renderSubmissionDetails(params, query) {
    renderNavbar();
    
    const submissionId = params?.id;
    
    if (!submissionId) {
        window.location.hash = '#/dashboard';
        return;
    }

    const container = document.getElementById('main-content');
    container.innerHTML = `
        <div class="page-container">
            <div class="page-header">
                <button type="button" class="btn btn-text" id="back-btn">← Back to Dashboard</button>
                <h1>Submission Details</h1>
            </div>

            <div id="details-content">
                <div class="loading">Loading submission details...</div>
            </div>
        </div>
    `;

    const backBtn = document.getElementById('back-btn');
    backBtn?.addEventListener('click', () => {
        window.location.hash = '#/dashboard';
    });

    await loadSubmissionDetails(submissionId);
}

async function loadSubmissionDetails(submissionId) {
    const container = document.getElementById('details-content');
    
    try {
        const submission = await getSubmissionById(submissionId);
        
        const status = statusConfig[submission.status] || statusConfig['Submitted'];
        
        container.innerHTML = `
            <div class="details-grid">
                <div class="details-card">
                    <h2>Basic Information</h2>
                    <div class="detail-row">
                        <span class="detail-label">Title:</span>
                        <span class="detail-value">${submission.title}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status:</span>
                        <span class="detail-value">
                            <span class="status-badge ${status.class}">
                                ${status.icon} ${status.label}
                            </span>
                        </span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Submitted:</span>
                        <span class="detail-value">${formatDate(submission.uploadedAt)}</span>
                    </div>
                    ${submission.description ? `
                        <div class="detail-row">
                            <span class="detail-label">Description:</span>
                            <span class="detail-value">${submission.description}</span>
                        </div>
                    ` : ''}
                </div>

                ${submission.processedData ? renderProcessingResults(submission.processedData) : ''}
                
                ${submission.status === 'Processing' ? renderProcessingSteps() : ''}
                
                <div class="details-card">
                    <h2>Actions</h2>
                    <div class="action-buttons">
                        <button type="button" class="btn btn-primary" id="chat-btn">
                            💬 Chat with Document
                        </button>
                        ${submission.pdfUrl ? `
                            <button type="button" class="btn btn-secondary" id="download-btn">
                                📥 Download PDF
                            </button>
                        ` : ''}
                        ${submission.status === 'Completed' ? `
                            <button type="button" class="btn btn-secondary" id="download-report-btn">
                                📄 Download Report
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;

        // Add event listeners
        document.getElementById('chat-btn')?.addEventListener('click', () => {
            window.location.hash = `#/chat?submissionId=${submissionId}`;
        });

        document.getElementById('download-btn')?.addEventListener('click', () => {
            window.open(submission.pdfUrl, '_blank');
        });

        document.getElementById('download-report-btn')?.addEventListener('click', async () => {
            try {
                // Call report API
                showNotification('Generating report...', 'info');
                // TODO: Implement report download
            } catch (error) {
                showNotification('Failed to generate report', 'error');
            }
        });

    } catch (error) {
        console.error('Error loading submission:', error);
        container.innerHTML = `
            <div class="error-message">
                Failed to load submission details. Please try again.
            </div>
        `;
    }
}

function renderProcessingResults(data) {
    return `
        <div class="details-card">
            <h2>Processing Results</h2>
            
            ${data.languageDetected ? `
                <div class="result-section">
                    <h3>Language Detection</h3>
                    <p><strong>Detected Language:</strong> ${data.languageDetected}</p>
                </div>
            ` : ''}
            
            ${data.summary ? `
                <div class="result-section">
                    <h3>Summary</h3>
                    <p>${data.summary}</p>
                </div>
            ` : ''}
            
            ${data.extractedData ? `
                <div class="result-section">
                    <h3>Extracted Information</h3>
                    <div class="extracted-data">
                        ${Object.entries(data.extractedData).map(([key, value]) => `
                            <div class="data-item">
                                <strong>${formatKey(key)}:</strong>
                                <span>${value}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
            
            ${data.qaResults && data.qaResults.length > 0 ? `
                <div class="result-section">
                    <h3>Quality Assessment</h3>
                    <ul class="qa-list">
                        ${data.qaResults.map(qa => `
                            <li class="qa-item ${qa.passed ? 'qa-pass' : 'qa-fail'}">
                                <span class="qa-icon">${qa.passed ? '✓' : '✗'}</span>
                                <span>${qa.message}</span>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            ` : ''}
        </div>
    `;
}

function renderProcessingSteps() {
    return `
        <div class="details-card">
            <h2>Processing Progress</h2>
            <div class="processing-steps">
                <div class="step step-completed">
                    <div class="step-icon">✓</div>
                    <div class="step-content">
                        <strong>Document Uploaded</strong>
                        <span>File received and validated</span>
                    </div>
                </div>
                <div class="step step-active">
                    <div class="step-icon">⚙️</div>
                    <div class="step-content">
                        <strong>Processing</strong>
                        <span>Analyzing document content...</span>
                    </div>
                </div>
                <div class="step">
                    <div class="step-icon">○</div>
                    <div class="step-content">
                        <strong>Quality Check</strong>
                        <span>Pending</span>
                    </div>
                </div>
                <div class="step">
                    <div class="step-icon">○</div>
                    <div class="step-content">
                        <strong>Completed</strong>
                        <span>Pending</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatKey(key) {
    return key
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase())
        .trim();
}
