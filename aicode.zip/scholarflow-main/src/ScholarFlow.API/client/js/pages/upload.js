import { showNotification } from '../components/notifications.js';
import { processSubmission } from '../api/submissions.js';
import { router } from '../router.js';
import { renderNavbar } from '../components/navbar.js';
import { getCurrentUser } from '../api/auth.js';

export async function renderUpload(params, query) {
    renderNavbar();
    const container = document.getElementById('main-content');
    container.innerHTML = `
        <div class="page-container">
            <div class="page-header">
                <h1>Upload Research Document</h1>
                <p>Upload your PDF document for analysis and processing</p>
            </div>

            <div class="upload-container">
                <div class="upload-box" id="upload-box">
                    <input 
                        type="file" 
                        id="file-input" 
                        accept=".pdf"
                        style="display: none;"
                    />
                    <div class="upload-icon">📄</div>
                    <h3>Drag & Drop PDF Here</h3>
                    <p>or</p>
                    <button type="button" class="btn btn-primary" id="browse-btn">
                        Browse Files
                    </button>
                    <p class="upload-hint">Only PDF files are supported (Max 50MB)</p>
                </div>

                <div class="selected-file" id="selected-file" style="display: none;">
                    <div class="file-info">
                        <div class="file-icon">📄</div>
                        <div class="file-details">
                            <strong id="file-name"></strong>
                            <span id="file-size"></span>
                        </div>
                        <button type="button" class="btn btn-text" id="remove-file">✕</button>
                    </div>
                    <div class="form-group">
                        <label>Title</label>
                        <input 
                            type="text" 
                            id="submission-title" 
                            class="form-control"
                            placeholder="Enter document title"
                            required
                        />
                    </div>
                    <div class="form-group">
                        <label>Description (Optional)</label>
                        <textarea 
                            id="submission-description" 
                            class="form-control"
                            placeholder="Enter document description"
                            rows="3"
                        ></textarea>
                    </div>
                    <div class="upload-actions">
                        <button type="button" class="btn btn-secondary" id="cancel-upload">
                            Cancel
                        </button>
                        <button type="button" class="btn btn-primary" id="submit-upload">
                            Upload & Process
                        </button>
                    </div>
                </div>

                <div class="upload-progress" id="upload-progress" style="display: none;">
                    <h3>Uploading...</h3>
                    <div class="progress-bar">
                        <div class="progress-fill" id="progress-fill"></div>
                    </div>
                    <p id="progress-text">0%</p>
                </div>
            </div>
        </div>
    `;

    initUpload();
}

function initUpload() {
    const uploadBox = document.getElementById('upload-box');
    const fileInput = document.getElementById('file-input');
    const browseBtn = document.getElementById('browse-btn');
    const selectedFileSection = document.getElementById('selected-file');
    const removeFileBtn = document.getElementById('remove-file');
    const cancelBtn = document.getElementById('cancel-upload');
    const submitBtn = document.getElementById('submit-upload');

    let selectedFile = null;

    // Browse button
    browseBtn?.addEventListener('click', () => {
        fileInput?.click();
    });

    // File input change
    fileInput?.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            handleFileSelect(file);
        }
    });

    // Drag and drop
    uploadBox?.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadBox.classList.add('drag-over');
    });

    uploadBox?.addEventListener('dragleave', () => {
        uploadBox.classList.remove('drag-over');
    });

    uploadBox?.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadBox.classList.remove('drag-over');
        
        const file = e.dataTransfer.files[0];
        if (file) {
            handleFileSelect(file);
        }
    });

    // Remove file
    removeFileBtn?.addEventListener('click', resetUpload);
    cancelBtn?.addEventListener('click', resetUpload);

    // Submit upload
    submitBtn?.addEventListener('click', handleSubmit);

    function handleFileSelect(file) {
        // Validate file type
        if (file.type !== 'application/pdf') {
            showNotification('Only PDF files are supported', 'error');
            return;
        }

        // Validate file size (50MB)
        const maxSize = 50 * 1024 * 1024;
        if (file.size > maxSize) {
            showNotification('File size must be less than 50MB', 'error');
            return;
        }

        selectedFile = file;

        // Display file info
        document.getElementById('file-name').textContent = file.name;
        document.getElementById('file-size').textContent = formatFileSize(file.size);

        // Auto-fill title from filename
        const titleInput = document.getElementById('submission-title');
        if (titleInput && !titleInput.value) {
            titleInput.value = file.name.replace('.pdf', '');
        }

        // Show selected file section
        uploadBox.style.display = 'none';
        selectedFileSection.style.display = 'block';
    }

    function resetUpload() {
        selectedFile = null;
        fileInput.value = '';
        document.getElementById('submission-title').value = '';
        document.getElementById('submission-description').value = '';
        uploadBox.style.display = 'flex';
        selectedFileSection.style.display = 'none';
    }

    async function handleSubmit() {
        if (!selectedFile) {
            showNotification('Please select a file', 'error');
            return;
        }

        const title = document.getElementById('submission-title').value.trim();
        if (!title) {
            showNotification('Please enter a title', 'error');
            return;
        }

        const description = document.getElementById('submission-description').value.trim();

        // Show progress
        selectedFileSection.style.display = 'none';
        const progressSection = document.getElementById('upload-progress');
        progressSection.style.display = 'block';

        try {
            // Simulate progress for UX
            updateProgress(10);

            // Get current user
            const user = getCurrentUser();
            const uploadedBy = user?.username || 'user';

            // Upload with title and description
            const result = await processSubmission(selectedFile, uploadedBy, title, description);

            updateProgress(100);

            showNotification('Document uploaded successfully! Processing started.', 'success');

            // Navigate to dashboard after short delay
            setTimeout(() => {
                router.navigate('/dashboard');
            }, 1500);

        } catch (error) {
            console.error('Upload error:', error);
            showNotification(error.message || 'Failed to upload document', 'error');
            
            // Reset on error
            progressSection.style.display = 'none';
            selectedFileSection.style.display = 'block';
        }
    }

    function updateProgress(percent) {
        const fill = document.getElementById('progress-fill');
        const text = document.getElementById('progress-text');
        if (fill) fill.style.width = `${percent}%`;
        if (text) text.textContent = `${percent}%`;
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
}
