import { login } from '../api/auth.js';
import { router } from '../router.js';
import { config } from '../config.js';
import { showNotification } from '../components/notifications.js';

/**
 * Render login page
 */
export async function renderLogin() {
  const content = document.getElementById('main-content');
  const urlParams = new URLSearchParams(window.location.hash.split('?')[1]);
  const roleParam = urlParams.get('role');
  const isAdmin = roleParam === 'admin';
  
  content.innerHTML = `
    <div style="
      min-height: 80vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    ">
      <div class="card" style="
        width: 100%;
        max-width: 420px;
        box-shadow: var(--shadow-xl);
      ">
        <div style="text-align: center; margin-bottom: 2rem;">
          <div style="font-size: 3rem; margin-bottom: 1rem;">${isAdmin ? '🔐' : '👤'}</div>
          <h2 style="margin-bottom: 0.5rem;">${isAdmin ? 'Admin' : 'User'} Login</h2>
          <p style="color: var(--text-secondary); font-size: 0.875rem; margin: 0;">
            ${isAdmin ? 'Reviewer & Administrator Access' : 'Upload and Process Research Documents'}
          </p>
        </div>
        
        <form id="login-form">
          <div class="form-group">
            <label for="username">Username</label>
            <input 
              type="text" 
              id="username" 
              name="username" 
              placeholder="${isAdmin ? 'admin' : 'user'}" 
              required 
              autocomplete="username"
            />
          </div>
          
          <div class="form-group">
            <label for="password">Password</label>
            <input 
              type="password" 
              id="password" 
              name="password" 
              placeholder="Enter your password" 
              required 
              autocomplete="current-password"
            />
          </div>
          
          <!-- Login as toggle -->
          <div style="
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
            padding: 0.75rem;
            background: var(--bg-secondary);
            border-radius: var(--radius-md);
            font-size: 0.875rem;
          ">
            <span style="color: var(--text-secondary);">Login as:</span>
            <label style="
              display: flex;
              align-items: center;
              gap: 0.25rem;
              cursor: pointer;
              margin: 0;
            ">
              <input 
                type="radio" 
                name="loginType" 
                value="user" 
                ${!isAdmin ? 'checked' : ''}
              />
              <span>User</span>
            </label>
            <label style="
              display: flex;
              align-items: center;
              gap: 0.25rem;
              cursor: pointer;
              margin: 0;
            ">
              <input 
                type="radio" 
                name="loginType" 
                value="admin" 
                ${isAdmin ? 'checked' : ''}
              />
              <span>Admin</span>
            </label>
          </div>
          
          <button type="submit" class="btn btn-primary" style="width: 100%;" id="submit-btn">
            Sign In
          </button>
          
          <div style="margin-top: 1.5rem; text-align: center;">
            <a href="#/" style="
              font-size: 0.875rem;
              color: var(--text-secondary);
              text-decoration: none;
            ">
              ← Back to Home
            </a>
          </div>
        </form>
        
        <!-- Demo credentials -->
        <div style="
          margin-top: 2rem;
          padding: 1rem;
          background: var(--bg-secondary);
          border-radius: var(--radius-md);
          font-size: 0.8125rem;
        ">
          <div style="font-weight: 600; margin-bottom: 0.5rem; color: var(--text-primary);">
            Demo Credentials:
          </div>
          <div style="color: var(--text-secondary); line-height: 1.6;">
            <div><strong>Researcher:</strong> researcher@university.edu / ResearchPass123</div>
            <div><strong>Admin:</strong> admin@university.edu / AdminPass123</div>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Handle form submission
  const form = document.getElementById('login-form');
  const submitBtn = document.getElementById('submit-btn');
  
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Disable button during login
    submitBtn.disabled = true;
    submitBtn.textContent = 'Signing in...';
    
    try {
      await login(username, password);
      showNotification('Login successful! Welcome back.', 'success');
      router.navigate(config.routes.dashboard);
    } catch (error) {
      console.error('Login error:', error);
      showNotification(error.message || 'Login failed. Please check your credentials.', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Sign In';
    }
  });
  
  // Handle radio button changes
  const radioButtons = document.querySelectorAll('input[name="loginType"]');
  radioButtons.forEach(radio => {
    radio.addEventListener('change', (e) => {
      const usernameInput = document.getElementById('username');
      if (e.target.value === 'admin') {
        usernameInput.placeholder = 'admin';
      } else {
        usernameInput.placeholder = 'user';
      }
    });
  });
}
