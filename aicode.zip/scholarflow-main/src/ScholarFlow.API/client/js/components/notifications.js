/**
 * Toast notification system
 */

let toastContainer;
let toastId = 0;

/**
 * Initialize toast container
 */
export function initNotifications() {
  toastContainer = document.getElementById('toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    toastContainer.style.cssText = `
      position: fixed;
      top: 1rem;
      right: 1rem;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      max-width: 400px;
    `;
    document.body.appendChild(toastContainer);
  }
}

/**
 * Show a toast notification
 */
export function showNotification(message, type = 'info', duration = 4000) {
  if (!toastContainer) initNotifications();
  
  const id = `toast-${toastId++}`;
  const icons = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ',
  };
  
  const colors = {
    success: 'var(--color-success)',
    error: 'var(--color-error)',
    warning: 'var(--color-warning)',
    info: 'var(--color-info)',
  };
  
  const toast = document.createElement('div');
  toast.id = id;
  toast.style.cssText = `
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    border-left: 4px solid ${colors[type]};
    border-radius: var(--radius-md);
    padding: 1rem;
    box-shadow: var(--shadow-lg);
    display: flex;
    align-items: start;
    gap: 0.75rem;
    min-width: 300px;
    animation: slideIn 0.3s ease-out;
  `;
  
  toast.innerHTML = `
    <div style="
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: ${colors[type]};
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      flex-shrink: 0;
    ">
      ${icons[type]}
    </div>
    <div style="flex: 1; color: var(--text-primary); font-size: 0.875rem; line-height: 1.5;">
      ${message}
    </div>
    <button onclick="this.parentElement.remove()" style="
      background: none;
      border: none;
      color: var(--text-tertiary);
      cursor: pointer;
      font-size: 1.25rem;
      padding: 0;
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    ">×</button>
  `;
  
  // Add animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    @keyframes slideOut {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(100%);
        opacity: 0;
      }
    }
  `;
  if (!document.getElementById('toast-animations')) {
    style.id = 'toast-animations';
    document.head.appendChild(style);
  }
  
  toastContainer.appendChild(toast);
  
  // Auto remove after duration
  if (duration > 0) {
    setTimeout(() => {
      toast.style.animation = 'slideOut 0.3s ease-in';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }
}

/**
 * Show success notification
 */
export function showSuccess(message, duration) {
  showNotification(message, 'success', duration);
}

/**
 * Show error notification
 */
export function showError(message, duration) {
  showNotification(message, 'error', duration);
}

/**
 * Show warning notification
 */
export function showWarning(message, duration) {
  showNotification(message, 'warning', duration);
}

/**
 * Show info notification
 */
export function showInfo(message, duration) {
  showNotification(message, 'info', duration);
}
