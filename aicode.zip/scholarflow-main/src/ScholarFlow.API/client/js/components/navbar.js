import { store } from '../state/store.js';
import { config } from '../config.js';
import { router } from '../router.js';
import { logout, getCurrentUser } from '../api/auth.js';
import { renderThemeToggle, attachThemeToggleListener } from './theme.js';

/**
 * Render navigation bar
 */
export function renderNavbar() {
  const navbar = document.getElementById('navbar');
  const state = store.getState();
  
  if (!state.isAuthenticated) {
    navbar.innerHTML = '';
    navbar.style.display = 'none';
    return;
  }
  
  navbar.style.display = 'block';
  
  const user = getCurrentUser();
  const isReviewer = user?.role === config.roles.reviewer;
  
  navbar.innerHTML = `
    <nav style="
      background: var(--bg-primary);
      border-bottom: 1px solid var(--border-color);
      padding: 0 2rem;
      box-shadow: var(--shadow-sm);
    ">
      <div style="
        max-width: 1400px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 64px;
      ">
        <!-- Logo -->
        <div style="display: flex; align-items: center; gap: 2rem;">
          <a href="#${config.routes.dashboard}" style="
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--color-primary);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
          ">
            📚 ScholarFlow
          </a>
          
          <!-- Navigation Links -->
          <div style="display: flex; gap: 0.5rem;">
            <a href="#${config.routes.dashboard}" class="nav-link ${state.currentRoute === config.routes.dashboard ? 'active' : ''}">
              Dashboard
            </a>
            ${!isReviewer ? `
              <a href="#${config.routes.upload}" class="nav-link ${state.currentRoute === config.routes.upload ? 'active' : ''}">
                Upload
              </a>
              <a href="#${config.routes.chat}" class="nav-link ${state.currentRoute === config.routes.chat ? 'active' : ''}">
                Q&A Chat
              </a>
            ` : `
              <a href="#${config.routes.review}" class="nav-link ${state.currentRoute === config.routes.review ? 'active' : ''}">
                Reviews
              </a>
            `}
          </div>
        </div>
        
        <!-- Right side -->
        <div style="display: flex; align-items: center; gap: 1rem;">
          <!-- User info -->
          <div style="
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: var(--bg-secondary);
            border-radius: var(--radius-full);
          ">
            <div style="
              width: 32px;
              height: 32px;
              border-radius: 50%;
              background: var(--color-primary);
              color: white;
              display: flex;
              align-items: center;
              justify-content: center;
              font-weight: 600;
              font-size: 0.875rem;
            ">
              ${user?.username?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div style="display: flex; flex-direction: column; line-height: 1.2;">
              <span style="font-size: 0.875rem; font-weight: 600; color: var(--text-primary);">
                ${user?.username || 'User'}
              </span>
              <span style="font-size: 0.75rem; color: var(--text-secondary);">
                ${user?.role || 'User'}
              </span>
            </div>
          </div>
          
          <!-- Theme toggle -->
          ${renderThemeToggle()}
          
          <!-- Logout button -->
          <button id="logout-btn" class="btn btn-secondary btn-sm">
            Logout
          </button>
        </div>
      </div>
    </nav>
    
    <style>
      .nav-link {
        padding: 0.5rem 1rem;
        color: var(--text-secondary);
        text-decoration: none;
        font-weight: 500;
        font-size: 0.875rem;
        border-radius: var(--radius-md);
        transition: all var(--transition-fast);
      }
      
      .nav-link:hover {
        background: var(--bg-secondary);
        color: var(--text-primary);
      }
      
      .nav-link.active {
        background: var(--bg-secondary);
        color: var(--color-primary);
      }
    </style>
  `;
  
  // Attach event listeners
  attachThemeToggleListener();
  
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      logout();
      router.navigate(config.routes.login);
    });
  }
}

// Store reference for theme toggle
window.renderNavbar = renderNavbar;
