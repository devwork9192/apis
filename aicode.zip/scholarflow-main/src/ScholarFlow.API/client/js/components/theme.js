import { config } from '../config.js';
import { store } from '../state/store.js';

/**
 * Initialize theme system
 */
export function initTheme() {
  // Get saved theme or default to dark
  const savedTheme = localStorage.getItem(config.storageKeys.theme) || 'dark';
  applyTheme(savedTheme);
  store.setState({ theme: savedTheme });
}

/**
 * Apply theme to document
 */
export function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem(config.storageKeys.theme, theme);
  store.setState({ theme });
}

/**
 * Toggle between light and dark theme
 */
export function toggleTheme() {
  const currentTheme = store.getState().theme;
  const newTheme = currentTheme === 'light' ? 'dark' : 'light';
  applyTheme(newTheme);
  return newTheme;
}

/**
 * Get current theme
 */
export function getCurrentTheme() {
  return store.getState().theme;
}

/**
 * Render theme toggle button
 */
export function renderThemeToggle() {
  const currentTheme = getCurrentTheme();
  const icon = currentTheme === 'light' ? '🌙' : '☀️';
  const label = currentTheme === 'light' ? 'Dark' : 'Light';
  
  return `
    <button class="btn btn-secondary btn-sm" id="theme-toggle" title="Toggle ${label} Mode">
      <span style="font-size: 1.2rem;">${icon}</span>
    </button>
  `;
}

/**
 * Attach theme toggle event listener
 */
export function attachThemeToggleListener() {
  const toggleBtn = document.getElementById('theme-toggle');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      toggleTheme();
      // Re-render navbar to update icon
      const navbar = document.getElementById('navbar');
      if (navbar && window.renderNavbar) {
        window.renderNavbar();
      }
    });
  }
}
