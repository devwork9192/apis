/**
 * Simple reactive state management
 * Similar to a minimal Redux/Vuex but vanilla JS
 */

class Store {
  constructor(initialState = {}) {
    this.state = initialState;
    this.listeners = [];
  }

  /**
   * Get current state
   */
  getState() {
    return this.state;
  }

  /**
   * Update state and notify listeners
   */
  setState(updates) {
    this.state = { ...this.state, ...updates };
    this.notify();
  }

  /**
   * Subscribe to state changes
   */
  subscribe(listener) {
    this.listeners.push(listener);
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  /**
   * Notify all listeners
   */
  notify() {
    this.listeners.forEach(listener => listener(this.state));
  }
}

// Create global store instance
export const store = new Store({
  user: null,
  isAuthenticated: false,
  token: null,
  theme: 'dark',
  currentRoute: '/',
  submissions: [],
  currentSubmission: null,
  loading: false,
});
