namespace ScholarFlow.API.Memory;

/// <summary>
/// Service for generating embeddings from text
/// </summary>
public interface IEmbeddingService
{
    /// <summary>
    /// Generates an embedding vector for the given text
    /// </summary>
    /// <param name="text">Text to embed</param>
    /// <returns>Embedding vector (typically 1536 dimensions)</returns>
    Task<float[]> GenerateEmbeddingAsync(string text);
    
    /// <summary>
    /// Generates embeddings for multiple texts in a single batch
    /// </summary>
    /// <param name="texts">Texts to embed</param>
    /// <returns>List of embedding vectors</returns>
    Task<List<float[]>> GenerateEmbeddingsAsync(IEnumerable<string> texts);
}
