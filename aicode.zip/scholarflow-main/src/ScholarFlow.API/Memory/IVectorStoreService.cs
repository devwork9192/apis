namespace ScholarFlow.API.Memory;

/// <summary>
/// Service for storing and retrieving vectors from a vector database
/// </summary>
public interface IVectorStoreService
{
    /// <summary>
    /// Stores a document with its embedding in the vector database
    /// </summary>
    /// <param name="submissionId">ID of the submission</param>
    /// <param name="text">Document text</param>
    /// <param name="embedding">Pre-computed embedding vector</param>
    /// <param name="metadata">Optional metadata to store with the vector</param>
    Task StoreDocumentAsync(Guid submissionId, string text, float[] embedding, Dictionary<string, object>? metadata = null);
    
    /// <summary>
    /// Searches for similar documents using semantic similarity
    /// </summary>
    /// <param name="query">Search query text</param>
    /// <param name="topK">Number of results to return</param>
    /// <returns>List of search results with similarity scores</returns>
    Task<IEnumerable<SearchResult>> SearchAsync(string query, int topK = 5);
    
    /// <summary>
    /// Searches using a pre-computed embedding vector
    /// </summary>
    /// <param name="embedding">Query embedding vector</param>
    /// <param name="topK">Number of results to return</param>
    /// <returns>List of search results with similarity scores</returns>
    Task<IEnumerable<SearchResult>> SearchByEmbeddingAsync(float[] embedding, int topK = 5);
    
    /// <summary>
    /// Deletes a document from the vector store
    /// </summary>
    /// <param name="submissionId">ID of the submission to delete</param>
    Task DeleteDocumentAsync(Guid submissionId);
    
    /// <summary>
    /// Clears all documents from the vector store (used for testing)
    /// </summary>
    Task ClearAsync();
}

/// <summary>
/// Represents a search result from vector similarity search
/// </summary>
public record SearchResult
{
    /// <summary>
    /// ID of the submission
    /// </summary>
    public Guid SubmissionId { get; init; }
    
    /// <summary>
    /// Document text
    /// </summary>
    public string Text { get; init; } = string.Empty;
    
    /// <summary>
    /// Similarity score (typically 0-1, higher is more similar)
    /// </summary>
    public float Score { get; init; }
    
    /// <summary>
    /// Additional metadata stored with the document
    /// </summary>
    public Dictionary<string, object> Metadata { get; init; } = new();
}
