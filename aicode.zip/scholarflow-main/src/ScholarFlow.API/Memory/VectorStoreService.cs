using Microsoft.Extensions.Options;
using ScholarFlow.API.Configuration;
using System.Collections.Concurrent;

namespace ScholarFlow.API.Memory;

/// <summary>
/// In-memory implementation of vector store for RAG functionality
/// Stores document embeddings and performs similarity search using cosine similarity
/// </summary>
public class VectorStoreService : IVectorStoreService
{
    private readonly MemorySettings _settings;
    private readonly ILogger<VectorStoreService> _logger;
    private readonly IEmbeddingService _embeddingService;
    
    // In-memory storage for documents and their embeddings (static to persist across instances)
    private static readonly ConcurrentDictionary<Guid, VectorDocument> _documents = new();
    
    public VectorStoreService(
        IOptions<MemorySettings> settings,
        ILogger<VectorStoreService> logger,
        IEmbeddingService embeddingService)
    {
        _settings = settings.Value;
        _logger = logger;
        _embeddingService = embeddingService;
    }
    
    public async Task StoreDocumentAsync(
        Guid submissionId, 
        string text, 
        float[] embedding, 
        Dictionary<string, object>? metadata = null)
    {
        try
        {
            _logger.LogInformation("Storing document for submission: {SubmissionId}", submissionId);
            
            if (embedding.Length != _settings.EmbeddingDimensions)
            {
                throw new ArgumentException(
                    $"Embedding dimension mismatch. Expected {_settings.EmbeddingDimensions}, got {embedding.Length}");
            }
            
            var document = new VectorDocument
            {
                SubmissionId = submissionId,
                Text = text,
                Embedding = embedding,
                Metadata = metadata ?? new Dictionary<string, object>(),
                StoredAt = DateTime.UtcNow
            };
            
            _documents[submissionId] = document;
            
            _logger.LogInformation("Successfully stored document. Total documents in memory: {Count}", _documents.Count);
            await Task.CompletedTask;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to store document for submission: {SubmissionId}", submissionId);
            throw;
        }
    }
    
    public async Task<IEnumerable<SearchResult>> SearchAsync(string query, int topK = 5)
    {
        try
        {
            _logger.LogInformation("Searching for: {Query}, top {K} results", query, topK);
            
            // Generate embedding for the query
            var queryEmbedding = await _embeddingService.GenerateEmbeddingAsync(query);
            
            return await SearchByEmbeddingAsync(queryEmbedding, topK);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to search with query: {Query}", query);
            throw;
        }
    }
    
    public async Task<IEnumerable<SearchResult>> SearchByEmbeddingAsync(float[] embedding, int topK = 5)
    {
        try
        {
            if (_documents.IsEmpty)
            {
                _logger.LogWarning("No documents in vector store for search");
                return Enumerable.Empty<SearchResult>();
            }
            
            _logger.LogDebug("Searching {Count} documents with embedding", _documents.Count);
            
            // Calculate cosine similarity for all documents
            var results = _documents.Values
                .Select(doc => new
                {
                    Document = doc,
                    Similarity = CalculateCosineSimilarity(embedding, doc.Embedding)
                })
                .OrderByDescending(x => x.Similarity)
                .Take(topK)
                .Select(x => new SearchResult
                {
                    SubmissionId = x.Document.SubmissionId,
                    Text = x.Document.Text,
                    Score = x.Similarity,
                    Metadata = x.Document.Metadata
                })
                .ToList();
            
            _logger.LogInformation("Found {Count} results", results.Count);
            
            return await Task.FromResult(results);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to search by embedding");
            throw;
        }
    }
    
    public async Task DeleteDocumentAsync(Guid submissionId)
    {
        try
        {
            _logger.LogInformation("Deleting document for submission: {SubmissionId}", submissionId);
            
            var removed = _documents.TryRemove(submissionId, out _);
            
            if (removed)
            {
                _logger.LogInformation("Document deleted successfully");
            }
            else
            {
                _logger.LogWarning("Document not found for deletion: {SubmissionId}", submissionId);
            }
            
            await Task.CompletedTask;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to delete document: {SubmissionId}", submissionId);
            throw;
        }
    }
    
    public async Task ClearAsync()
    {
        try
        {
            _logger.LogInformation("Clearing all documents from vector store");
            _documents.Clear();
            await Task.CompletedTask;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to clear vector store");
            throw;
        }
    }
    
    /// <summary>
    /// Calculates cosine similarity between two vectors
    /// </summary>
    private static float CalculateCosineSimilarity(float[] vector1, float[] vector2)
    {
        if (vector1.Length != vector2.Length)
        {
            throw new ArgumentException("Vectors must have the same length");
        }
        
        float dotProduct = 0;
        float magnitude1 = 0;
        float magnitude2 = 0;
        
        for (int i = 0; i < vector1.Length; i++)
        {
            dotProduct += vector1[i] * vector2[i];
            magnitude1 += vector1[i] * vector1[i];
            magnitude2 += vector2[i] * vector2[i];
        }
        
        magnitude1 = (float)Math.Sqrt(magnitude1);
        magnitude2 = (float)Math.Sqrt(magnitude2);
        
        if (magnitude1 == 0 || magnitude2 == 0)
        {
            return 0;
        }
        
        return dotProduct / (magnitude1 * magnitude2);
    }
}

/// <summary>
/// Internal representation of a vector document in memory
/// </summary>
internal class VectorDocument
{
    public Guid SubmissionId { get; set; }
    public string Text { get; set; } = string.Empty;
    public float[] Embedding { get; set; } = Array.Empty<float>();
    public Dictionary<string, object> Metadata { get; set; } = new();
    public DateTime StoredAt { get; set; }
}
