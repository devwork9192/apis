using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Embeddings;
using Microsoft.Extensions.Options;
using ScholarFlow.API.Configuration;

namespace ScholarFlow.API.Memory;

/// <summary>
/// Implementation for embedding generation using Azure OpenAI
/// </summary>
public class EmbeddingService : IEmbeddingService
{
    private readonly Kernel _kernel;
    private readonly ILogger<EmbeddingService> _logger;
    private readonly MemorySettings _settings;
    
    public EmbeddingService(
        Kernel kernel, 
        ILogger<EmbeddingService> logger,
        IOptions<MemorySettings> settings)
    {
        _kernel = kernel;
        _logger = logger;
        _settings = settings.Value;
    }
    
    public async Task<float[]> GenerateEmbeddingAsync(string text)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                _logger.LogWarning("Empty text provided for embedding generation");
                return new float[_settings.EmbeddingDimensions];
            }

            _logger.LogDebug("Generating embedding for text of length: {Length}", text.Length);

            // Truncate text if too long (max ~8000 tokens for ada-002)
            var truncatedText = text.Length > 30000 ? text.Substring(0, 30000) : text;

#pragma warning disable CS0618 // Will be upgraded when Semantic Kernel updates embedding APIs
            var embeddingService = _kernel.GetRequiredService<ITextEmbeddingGenerationService>();
            var embedding = await embeddingService.GenerateEmbeddingAsync(truncatedText);
#pragma warning restore CS0618
            
            _logger.LogDebug("Embedding generated successfully with {Dimensions} dimensions", embedding.Length);
            
            return embedding.ToArray();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to generate embedding");
            throw;
        }
    }
    
    public async Task<List<float[]>> GenerateEmbeddingsAsync(IEnumerable<string> texts)
    {
        try
        {
            var textList = texts.ToList();
            _logger.LogDebug("Generating {Count} embeddings", textList.Count);

            var embeddings = new List<float[]>();
            
            foreach (var text in textList)
            {
                var embedding = await GenerateEmbeddingAsync(text);
                embeddings.Add(embedding);
            }

            _logger.LogDebug("Generated {Count} embeddings successfully", embeddings.Count);
            return embeddings;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to generate batch embeddings");
            throw;
        }
    }
}
