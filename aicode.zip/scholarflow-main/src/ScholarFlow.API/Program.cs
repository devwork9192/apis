using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Embeddings;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Common;
using ScholarFlow.API.Configuration;
using ScholarFlow.API.Database;
using ScholarFlow.API.Filters;
using ScholarFlow.API.Orchestration;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

var builder = WebApplication.CreateBuilder(args);

// Load local configuration if exists (for local development with secrets)
if (builder.Environment.IsDevelopment())
{
    var localConfigPath = Path.Combine(builder.Environment.ContentRootPath, "appsettings.local.json");
    if (!File.Exists(localConfigPath))
    {
        throw new FileNotFoundException(
            "appsettings.local.json not found. Create this file with your Azure OpenAI credentials. " +
            "See appsettings.json for template.");
    }
    builder.Configuration.AddJsonFile("appsettings.local.json", optional: false, reloadOnChange: true);
}

// Configure settings
builder.Services.Configure<AzureOpenAISettings>(builder.Configuration.GetSection("AzureOpenAI"));
builder.Services.Configure<ValidationRulesSettings>(builder.Configuration.GetSection("ValidationRules"));
builder.Services.Configure<StorageSettings>(builder.Configuration.GetSection("Storage"));
builder.Services.Configure<MemorySettings>(builder.Configuration.GetSection("Memory"));
builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection("JwtSettings"));
builder.Services.Configure<AuthSettings>(builder.Configuration.GetSection("Authentication"));

// Configure SQLite database
var dbPath = builder.Configuration[AppConstants.ConfigKeys.StorageDatabasePath] ?? AppConstants.Paths.DefaultDatabaseName;
builder.Services.AddDbContext<ScholarFlowDbContext>(options =>
    options.UseSqlite($"Data Source={dbPath}"));

// Configure Semantic Kernel
var azureSettings = builder.Configuration.GetSection("AzureOpenAI").Get<AzureOpenAISettings>();
if (azureSettings == null || string.IsNullOrEmpty(azureSettings.Endpoint))
{
    throw new InvalidOperationException("Azure OpenAI configuration is missing or invalid");
}

var kernelBuilder = Kernel.CreateBuilder();

// Add logging to kernel's service collection
kernelBuilder.Services.AddLogging(loggingBuilder => loggingBuilder.AddConsole());

kernelBuilder.AddAzureOpenAIChatCompletion(
    azureSettings.ChatDeploymentName,
    azureSettings.Endpoint,
    azureSettings.ApiKey);

// Add text embedding generation service for plagiarism detection
#pragma warning disable CS0618 // Type or member is obsolete - Will be upgraded to AddAzureOpenAIEmbeddingGenerator in Phase 2 (RAG)
kernelBuilder.AddAzureOpenAITextEmbeddingGeneration(
    azureSettings.EmbeddingDeploymentName,
    azureSettings.Endpoint,
    azureSettings.ApiKey);
#pragma warning restore CS0618

// Register function invocation filter for cross-cutting logging
kernelBuilder.Services.AddSingleton<IFunctionInvocationFilter, LoggingFilter>();

var kernel = kernelBuilder.Build();
builder.Services.AddSingleton(kernel);

// Register text embedding service for DI (needed by PlagiarismService)
// Extract it from the kernel's service provider
#pragma warning disable CS0618 // Type or member is obsolete - Will be upgraded in Phase 2 (RAG)
builder.Services.AddScoped<ITextEmbeddingGenerationService>(sp =>
{
    var kernelInstance = sp.GetRequiredService<Kernel>();
    return kernelInstance.GetRequiredService<ITextEmbeddingGenerationService>();
});
#pragma warning restore CS0618

// Register services
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ISubmissionService, SubmissionService>();
builder.Services.AddScoped<IPdfService, PdfService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IHealthService, HealthService>();
builder.Services.AddScoped<IProcessService, ProcessService>();
builder.Services.AddScoped<IPlagiarismService, PlagiarismService>();
builder.Services.AddScoped<IContentSafetyService, ContentSafetyService>();
builder.Services.AddScoped<IReportService, ReportService>();
builder.Services.AddScoped<IHumanReviewService, HumanReviewService>();

// Register Process Framework orchestrator
builder.Services.AddScoped<IProcessOrchestrator, ProcessOrchestrator>();
builder.Services.AddScoped<ProcessOrchestrator>();

// Register process steps
builder.Services.AddScoped<LanguageDetectionStep>();
builder.Services.AddScoped<TranslationStep>();
builder.Services.AddScoped<MetadataExtractionStep>();
builder.Services.AddScoped<ValidationStep>();
builder.Services.AddScoped<SummaryGenerationStep>();
builder.Services.AddScoped<RAGStep>();

// Register individual agents - used by process steps
builder.Services.AddScoped<IIngestionAgent, IngestionAgent>();
builder.Services.AddScoped<IPreprocessAgent, PreprocessAgent>();
builder.Services.AddScoped<ITranslationAgent, TranslationAgent>();
builder.Services.AddScoped<IExtractionAgent, ExtractionAgent>();
builder.Services.AddScoped<IValidationAgent, ValidationAgent>();
builder.Services.AddScoped<ISummaryAgent, SummaryAgent>();
builder.Services.AddScoped<IRAGAgent, RAGAgent>();
builder.Services.AddScoped<IQAAgent, QAAgent>();

// Memory services (RAG implementation)
builder.Services.AddScoped<ScholarFlow.API.Memory.IEmbeddingService, ScholarFlow.API.Memory.EmbeddingService>();
builder.Services.AddScoped<ScholarFlow.API.Memory.IVectorStoreService, ScholarFlow.API.Memory.VectorStoreService>();

// Chat service (Q&A interface)
builder.Services.AddScoped<IChatService, ChatService>();

// Configure JWT Authentication
var jwtSettings = builder.Configuration.GetSection("JwtSettings").Get<JwtSettings>();
if (jwtSettings == null || string.IsNullOrEmpty(jwtSettings.SecretKey))
{
    throw new InvalidOperationException("JWT settings are missing or invalid in configuration");
}

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings.Issuer,
        ValidAudience = jwtSettings.Audience,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.SecretKey))
    };
});

builder.Services.AddAuthorization();

// Add controllers
builder.Services.AddControllers();

// Configure Swagger/OpenAPI with JWT support
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { 
        Title = "ScholarFlow API", 
        Version = "v1",
        Description = "Automated Multilingual Research Submission Processor with JWT Authentication"
    });
    
    // TODO: Add JWT authentication to Swagger UI
    // Requires Microsoft.OpenApi.Models package or correct namespace resolution
});

var app = builder.Build();

// Log SK configuration
using (var scope = app.Services.CreateScope())
{
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    logger.LogInformation("========================================");
    logger.LogInformation("Semantic Kernel Process Framework Configuration:");
    logger.LogInformation("  - SK Base: Microsoft.SemanticKernel 1.72.0");
    logger.LogInformation("  - SK Agents: Microsoft.SemanticKernel.Agents.Core 1.72.0");
    logger.LogInformation("  - Architecture: Process Framework pattern for workflow orchestration");
    logger.LogInformation("  - Orchestrator: ProcessOrchestrator (workflow-based)");
    logger.LogInformation("========================================");
    logger.LogInformation("Registered Components:");
    logger.LogInformation("  - ProcessOrchestrator: Workflow coordination");
    logger.LogInformation("  - 6 Process Steps: LanguageDetection, Translation, Extraction, Validation, Summary, RAG");
    logger.LogInformation("  - 8 Agents: Ingestion, Preprocess, Translation, Extraction, Validation, Summary, RAG, QA");
    logger.LogInformation("  - Each step encapsulates agent execution with audit logging");
    logger.LogInformation("  - RAG Pipeline: In-memory vector store with Azure OpenAI embeddings");
    logger.LogInformation("  - Q&A Interface: Multilingual conversational interface with chat history");
    logger.LogInformation("========================================");
}

// Create database and apply migrations
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ScholarFlowDbContext>();
    db.Database.EnsureCreated();
}

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "ScholarFlow API v1"));
}

// Enable static file serving for UI from 'client' folder
var clientPath = Path.Combine(app.Environment.ContentRootPath, "client");
app.UseDefaultFiles(new DefaultFilesOptions
{
    FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(clientPath)
});
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(clientPath)
});

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
