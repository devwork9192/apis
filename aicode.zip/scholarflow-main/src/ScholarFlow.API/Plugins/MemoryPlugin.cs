using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.Memory;

namespace ScholarFlow.API.Plugins;

/// <summary>
/// Semantic Kernel plugin for memory and RAG operations
/// </summary>
public class MemoryPlugin
{
    private readonly IVectorStoreService _vectorStore;
    private readonly IEmbeddingService _embedding;
    private readonly ILogger<MemoryPlugin> _logger;
    
    public MemoryPlugin(
        IVectorStoreService vectorStore,
        IEmbeddingService embedding,
        ILogger<MemoryPlugin> logger)
    {
        _vectorStore = vectorStore;
        _embedding = embedding;
        _logger = logger;
    }
    
    [KernelFunction]
    [Description("Stores a research paper in the vector database for semantic search")]
    public async Task<string> StoreDocumentAsync(
        [Description("The submission ID")] string submissionId,
        [Description("The full text of the research paper")] string text)
    {
        try
        {
            var id = Guid.Parse(submissionId);
            var embedding = await _embedding.GenerateEmbeddingAsync(text);
            await _vectorStore.StoreDocumentAsync(id, text, embedding);
            
            return $"Document {submissionId} stored successfully in vector database";
        }
        catch (NotImplementedException ex)
        {
            _logger.LogWarning("Memory plugin called but not yet implemented: {Message}", ex.Message);
            return "Memory storage not yet implemented - will be available in Phase 7";
        }
    }
    
    [KernelFunction]
    [Description("Searches for similar research papers using semantic similarity")]
    public async Task<string> SearchDocumentsAsync(
        [Description("The search query describing what to look for")] string query,
        [Description("Number of results to return (default: 5)")] int topK = 5)
    {
        try
        {
            var results = await _vectorStore.SearchAsync(query, topK);
            
            var resultText = string.Join("\n", results.Select(r => 
                $"Submission {r.SubmissionId}: {r.Text.Substring(0, Math.Min(200, r.Text.Length))}... (Score: {r.Score:F3})"));
            
            return resultText;
        }
        catch (NotImplementedException ex)
        {
            _logger.LogWarning("Memory plugin called but not yet implemented: {Message}", ex.Message);
            return "Semantic search not yet implemented - will be available in Phase 7";
        }
    }
    
    [KernelFunction]
    [Description("Finds papers related to a specific research topic or methodology")]
    public async Task<string> FindRelatedPapersAsync(
        [Description("The topic or methodology to search for")] string topic,
        [Description("Number of related papers to find")] int count = 3)
    {
        try
        {
            var results = await _vectorStore.SearchAsync(topic, count);
            
            return $"Found {results.Count()} papers related to: {topic}";
        }
        catch (NotImplementedException ex)
        {
            _logger.LogWarning("Memory plugin called but not yet implemented: {Message}", ex.Message);
            return "Related paper search not yet implemented - will be available in Phase 7";
        }
    }
}
