using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.Common;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Agents;

public interface IPreprocessAgent
{
    Task<string> DetectLanguageAsync(string text);
    Task<PreprocessResult> ProcessAsync(string rawText, int pageCount);
}

/// <summary>
/// Plugin for preprocessing research paper submissions
/// </summary>
public class PreprocessAgent : IPreprocessAgent
{
    private readonly Kernel _kernel;
    private readonly ILogger<PreprocessAgent> _logger;
    private readonly string _detectLanguagePrompt;

    public PreprocessAgent(Kernel kernel, ILogger<PreprocessAgent> logger)
    {
        _kernel = kernel;
        _logger = logger;
        
        // Load prompt template from file
        var promptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Prompts", "LanguageDetection", "skprompt.txt");
        _detectLanguagePrompt = File.ReadAllText(promptPath);
    }

    [KernelFunction, Description("Detects the language of the given text")]
    public async Task<string> DetectLanguageAsync(
        [Description("The text to analyze for language detection")] string text)
    {
        try
        {
            // Truncate text for language detection
            var textSample = text.Substring(0, Math.Min(text.Length, AppConstants.LanguageDetection.TextSampleSizeForDetection));
            
            var arguments = new KernelArguments
            {
                ["text"] = textSample,
                ["unknown_language"] = AppConstants.LanguageDetection.UnknownLanguage
            };

            var result = await _kernel.InvokePromptAsync(_detectLanguagePrompt, arguments);
            var language = result.ToString().Trim();

            return language;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error detecting language");
            return AppConstants.LanguageDetection.UnknownLanguage;
        }
    }

    public async Task<PreprocessResult> ProcessAsync(string rawText, int pageCount)
    {
        var textLength = rawText?.Length ?? 0;
        var wordCount = string.IsNullOrWhiteSpace(rawText) 
            ? 0 
            : rawText.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Length;

        _logger.LogInformation(
            "Starting preprocessing. Pages: {PageCount}, Text length: {Length} chars, Words: {Words}, Avg chars/page: {AvgChars}", 
            pageCount, 
            textLength, 
            wordCount,
            pageCount > 0 ? textLength / pageCount : 0);

        var detectedLanguage = AppConstants.LanguageDetection.UnknownLanguage;
        
        if (!string.IsNullOrWhiteSpace(rawText) && rawText.Length >= 50)
        {
            detectedLanguage = await DetectLanguageAsync(rawText);
        }
        else
        {
            _logger.LogWarning("Insufficient text for language detection. Text length: {Length}", textLength);
        }
        
        // Improved scanned document detection using proper heuristics
        // A document is likely scanned if it has very little extractable text relative to page count
        var avgCharsPerPage = pageCount > 0 ? (double)textLength / pageCount : 0;
        var avgWordsPerPage = pageCount > 0 ? (double)wordCount / pageCount : 0;
        
        // Typical page has 250-500 words. If avg is below 50 words/page, likely scanned or has extraction issues
        var isScanned = pageCount > 0 && (
            avgCharsPerPage < AppConstants.DocumentHeuristics.MinTextLengthPerPageForScanned * 5 || // ~250 chars minimum per page
            avgWordsPerPage < 50 // Less than 50 words per page suggests scanned/image-based PDF
        );

        if (isScanned)
        {
            _logger.LogWarning(
                "Document appears to be scanned or has poor text extraction. Avg {AvgWords} words/page, {AvgChars} chars/page", 
                Math.Round(avgWordsPerPage, 1), 
                Math.Round(avgCharsPerPage, 1));
        }

        var result = new PreprocessResult
        {
            RawText = rawText ?? string.Empty,
            DetectedLanguage = detectedLanguage,
            IsScanned = isScanned,
            PageCount = pageCount
        };

        _logger.LogInformation(
            "Preprocessing complete: Language={Language}, IsScanned={IsScanned}, PageCount={PageCount}, WordCount={WordCount}", 
            detectedLanguage, isScanned, pageCount, wordCount);

        return result;
    }
}
