using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.Common;
using ScholarFlow.API.Database;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Agents;

public interface IIngestionAgent
{
    Task<IngestionResult> IngestSubmissionAsync(IFormFile file, string uploadedBy, string? title = null, string? description = null);
}

/// <summary>
/// Ingestion Agent - Monitors and ingests research paper submissions
/// Responsible for file validation, storage, and initial submission record creation
/// </summary>
public class IngestionAgent : IIngestionAgent
{
    private readonly ScholarFlowDbContext _context;
    private readonly IPdfService _pdfService;
    private readonly IAuditService _auditService;
    private readonly ILogger<IngestionAgent> _logger;
    private readonly string _uploadPath;

    public IngestionAgent(
        ScholarFlowDbContext context,
        IPdfService pdfService,
        IAuditService auditService,
        IConfiguration configuration,
        ILogger<IngestionAgent> logger)
    {
        _context = context;
        _pdfService = pdfService;
        _auditService = auditService;
        _logger = logger;
        _uploadPath = configuration[AppConstants.ConfigKeys.StorageUploadPath] ?? AppConstants.Paths.DefaultUploadPath;
    }

    /// <summary>
    /// Ingests and validates uploaded research paper submission
    /// </summary>
    [KernelFunction]
    [Description("Ingests uploaded research paper file, validates format, saves to storage, and creates submission record")]
    public async Task<IngestionResult> IngestSubmissionAsync(
        [Description("The uploaded PDF file")] IFormFile file,
        [Description("User who uploaded the file")] string uploadedBy,
        [Description("Optional title for the submission")] string? title = null,
        [Description("Optional description for the submission")] string? description = null)
    {
        try
        {
            _logger.LogInformation("[INGESTION_AGENT] Starting ingestion for file: {FileName}", file.FileName);

            // Step 1: Validate file
            if (!_pdfService.ValidateFile(file, out var errorMessage))
            {
                _logger.LogWarning("[INGESTION_AGENT] File validation failed: {Error}", errorMessage);
                return new IngestionResult
                {
                    Success = false,
                    ErrorMessage = errorMessage,
                    FileName = file.FileName
                };
            }

            // Step 2: Save file to storage
            var filePath = await _pdfService.SaveFileAsync(file, _uploadPath);
            _logger.LogInformation("[INGESTION_AGENT] File saved to: {FilePath}", filePath);

            // Step 3: Extract text and page count from PDF
            var (rawText, pageCount) = await _pdfService.ExtractTextAsync(filePath);
            _logger.LogInformation("[INGESTION_AGENT] Extracted {PageCount} pages, {TextLength} characters", 
                pageCount, rawText?.Length ?? 0);

            // Step 4: Create submission record
            var submission = new Submission
            {
                FileName = file.FileName,
                FilePath = filePath,
                FileSizeBytes = file.Length,
                RawText = rawText,
                PageCount = pageCount,
                Status = SubmissionStatus.Uploaded,
                CurrentStage = ProcessingStage.Upload,
                UploadedBy = uploadedBy,
                UploadedAt = DateTime.UtcNow,
                Title = title,
                Description = description
            };

            _context.Submissions.Add(submission);
            await _context.SaveChangesAsync();

            // Step 5: Log audit trail
            await _auditService.LogActionAsync(
                submission.Id,
                "FileIngested",
                $"File: {file.FileName}, Size: {file.Length} bytes, Pages: {pageCount}",
                uploadedBy,
                agentName: "IngestionAgent",
                stage: ProcessingStage.Upload);

            _logger.LogInformation("[INGESTION_AGENT] Ingestion completed successfully. SubmissionId: {SubmissionId}", submission.Id);

            return new IngestionResult
            {
                Success = true,
                SubmissionId = submission.Id,
                FilePath = filePath,
                FileName = file.FileName,
                FileSizeBytes = file.Length,
                PageCount = pageCount,
                RawText = rawText
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[INGESTION_AGENT] Error during file ingestion: {FileName}", file.FileName);
            return new IngestionResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                FileName = file.FileName
            };
        }
    }
}
