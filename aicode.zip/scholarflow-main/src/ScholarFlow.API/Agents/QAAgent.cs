using Microsoft.SemanticKernel;
using System.ComponentModel;
using System.Text;
using ScholarFlow.API.DTOs.Chat;
using ScholarFlow.API.Memory;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Database;
using Microsoft.EntityFrameworkCore;

namespace ScholarFlow.API.Agents;

/// <summary>
/// Agent for Question Answering with RAG and multilingual support
/// </summary>
public class QAAgent : IQAAgent
{
    private readonly Kernel _kernel;
    private readonly IVectorStoreService _vectorStore;
    private readonly IPreprocessAgent _preprocessAgent;
    private readonly ITranslationAgent _translationAgent;
    private readonly ScholarFlowDbContext _context;
    private readonly ILogger<QAAgent> _logger;
    private readonly string _qaPrompt;

    public QAAgent(
        Kernel kernel,
        IVectorStoreService vectorStore,
        IPreprocessAgent preprocessAgent,
        ITranslationAgent translationAgent,
        ScholarFlowDbContext context,
        ILogger<QAAgent> logger)
    {
        _kernel = kernel;
        _vectorStore = vectorStore;
        _preprocessAgent = preprocessAgent;
        _translationAgent = translationAgent;
        _context = context;
        _logger = logger;
        
        // Load QA prompt template
        var promptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Prompts", "QA", "skprompt.txt");
        _qaPrompt = File.ReadAllText(promptPath);
    }

    /// <summary>
    /// Answers a question about research papers using RAG
    /// </summary>
    [KernelFunction, Description("Answers questions about research papers using semantic search and multilingual support")]
    public async Task<ChatResponse> AnswerQuestionAsync(
        [Description("The user's question")] string query,
        [Description("Optional language code (auto-detected if null)")] string? language = null,
        [Description("Number of papers to retrieve")] int topK = 3,
        [Description("Optional: specific submission to ask about")] Guid? specificSubmissionId = null)
    {
        try
        {
            _logger.LogInformation("Starting QA for query: {Query}", query);

            // Step 1: Detect language if not provided
            var detectedLanguage = language;
            if (string.IsNullOrEmpty(language))
            {
                detectedLanguage = await _preprocessAgent.DetectLanguageAsync(query);
                _logger.LogInformation("Detected language: {Language}", detectedLanguage);
            }

            // Step 2: Translate query to English if needed
            string englishQuery = query;
            bool wasTranslated = false;
            
            if (detectedLanguage?.ToLower() != "en" && detectedLanguage?.ToLower() != "english")
            {
                englishQuery = await _translationAgent.TranslateToEnglishAsync(query, detectedLanguage ?? "auto");
                wasTranslated = true;
                _logger.LogInformation("Translated query from {Lang} to English: {Query}", detectedLanguage, englishQuery);
            }

            // Step 3: Retrieve relevant papers from vector store
            IEnumerable<Memory.SearchResult> searchResults;
            
            if (specificSubmissionId.HasValue)
            {
                // Search for specific submission with its embedding
                var submission = await _context.Submissions.FindAsync(specificSubmissionId.Value);
                if (submission == null)
                {
                    return new ChatResponse
                    {
                        Answer = "The specified submission was not found.",
                        DetectedLanguage = detectedLanguage ?? "en",
                        TranslatedQuery = wasTranslated ? englishQuery : null,
                        WasTranslated = wasTranslated
                    };
                }
                
                // Get the specific document from vector store by searching for itself
                searchResults = await _vectorStore.SearchAsync(englishQuery, 10);
                searchResults = searchResults.Where(r => r.SubmissionId == specificSubmissionId.Value).ToList();
            }
            else
            {
                // Search all papers
                searchResults = await _vectorStore.SearchAsync(englishQuery, topK);
            }

            if (!searchResults.Any())
            {
                var noResultsMsg = "I couldn't find any relevant research papers to answer this question. The database may be empty or no papers match your query.";
                
                if (wasTranslated)
                {
                    noResultsMsg = await _translationAgent.TranslateFromEnglishAsync(noResultsMsg, detectedLanguage ?? "en");
                }
                
                return new ChatResponse
                {
                    Answer = noResultsMsg,
                    DetectedLanguage = detectedLanguage ?? "en",
                    TranslatedQuery = wasTranslated ? englishQuery : null,
                    WasTranslated = wasTranslated
                };
            }

            // Step 4: Fetch submission details from database
            var submissionIds = searchResults.Select(r => r.SubmissionId).ToList();
            var submissions = await _context.Submissions
                .Where(s => submissionIds.Contains(s.Id))
                .ToListAsync();

            // Step 5: Build context for LLM from retrieved papers
            var papersContext = BuildPapersContext(searchResults, submissions);
            
            _logger.LogDebug("Retrieved {Count} relevant papers for QA", searchResults.Count());

            // Step 6: Generate answer using GPT-4
            var arguments = new KernelArguments
            {
                ["query"] = englishQuery,
                ["papers"] = papersContext
            };

            var result = await _kernel.InvokePromptAsync(_qaPrompt, arguments);
            var answer = result.ToString().Trim();

            // Step 7: Translate answer back to original language if needed
            if (wasTranslated && !string.IsNullOrEmpty(detectedLanguage))
            {
                answer = await _translationAgent.TranslateFromEnglishAsync(answer, detectedLanguage);
                _logger.LogInformation("Translated answer back to {Lang}", detectedLanguage);
            }

            // Step 8: Build response with sources
            var sources = searchResults.Zip(submissions, (search, sub) => new SourceReference
            {
                SubmissionId = search.SubmissionId,
                Title = sub.Title ?? "Untitled",
                Authors = sub.Authors,
                RelevanceScore = search.Score,
                Excerpt = search.Text.Length > 300 ? search.Text.Substring(0, 300) + "..." : search.Text
            }).ToList();

            _logger.LogInformation("QA completed successfully. Generated answer with {Count} sources", sources.Count);

            return new ChatResponse
            {
                Answer = answer,
                Sources = sources,
                DetectedLanguage = detectedLanguage ?? "en",
                CitedSubmissions = submissionIds,
                TranslatedQuery = wasTranslated ? englishQuery : null,
                WasTranslated = wasTranslated
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to answer question: {Query}", query);
            throw;
        }
    }

    private string BuildPapersContext(IEnumerable<Memory.SearchResult> searchResults, List<Models.Submission> submissions)
    {
        var sb = new StringBuilder();
        int paperNum = 1;

        foreach (var searchResult in searchResults)
        {
            var submission = submissions.FirstOrDefault(s => s.Id == searchResult.SubmissionId);
            if (submission == null) continue;

            sb.AppendLine($"Paper {paperNum}: {submission.Title ?? "Untitled"}");
            sb.AppendLine($"Authors: {submission.Authors ?? "Unknown"}");
            
            // Truncate abstract to 200 characters to save tokens
            if (!string.IsNullOrEmpty(submission.Abstract))
            {
                var truncatedAbstract = submission.Abstract.Length > 200 
                    ? submission.Abstract.Substring(0, 200) + "..." 
                    : submission.Abstract;
                sb.AppendLine($"Abstract: {truncatedAbstract}");
            }
            
            sb.AppendLine($"Relevance Score: {searchResult.Score:F2}");
            
            // Reduce content from 2000 to 800 chars to fit within token limits
            var contentLength = Math.Min(800, searchResult.Text.Length);
            sb.AppendLine($"Relevant Content: {searchResult.Text.Substring(0, contentLength)}");
            
            sb.AppendLine();
            sb.AppendLine("---");
            sb.AppendLine();
            
            paperNum++;
        }

        return sb.ToString();
    }
}
