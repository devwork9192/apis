using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Agents;

public interface ISummaryAgent
{
    Task<SummaryResult> GenerateSummaryAsync(Submission submission);
}

/// <summary>
/// Plugin for generating publication-ready summaries
/// </summary>
public class SummaryAgent : ISummaryAgent
{
    private readonly Kernel _kernel;
    private readonly ILogger<SummaryAgent> _logger;
    private readonly string _summaryPrompt;

    public SummaryAgent(Kernel kernel, ILogger<SummaryAgent> logger)
    {
        _kernel = kernel;
        _logger = logger;
        
        // Load prompt template from file
        var promptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Prompts", "Summary", "skprompt.txt");
        _summaryPrompt = File.ReadAllText(promptPath);
    }

    /// <summary>
    /// Generates a concise, publication-ready summary of the research paper
    /// </summary>
    [KernelFunction, Description("Generates a 200-300 word publication-ready summary of a research paper")]
    public async Task<SummaryResult> GenerateSummaryAsync(
        [Description("The submission containing the research paper")] Submission submission)
    {
        try
        {
            _logger.LogInformation("Starting summary generation for submission: {SubmissionId}", submission.Id);

            // Validate that we have the necessary extracted data
            if (string.IsNullOrWhiteSpace(submission.Title) || 
                string.IsNullOrWhiteSpace(submission.Abstract))
            {
                _logger.LogWarning("Insufficient metadata for summary generation. Title or abstract missing.");
                return new SummaryResult
                {
                    SummarySuccessful = false,
                    ErrorMessage = "Cannot generate summary: Title or abstract is missing"
                };
            }

            var textToSummarize = submission.WasTranslated ? submission.TranslatedText : submission.RawText;
            var truncatedText = textToSummarize?.Length > 10000 
                ? textToSummarize.Substring(0, 10000) 
                : textToSummarize ?? string.Empty;

            var arguments = new KernelArguments
            {
                ["title"] = submission.Title,
                ["authors"] = submission.Authors ?? "Not provided",
                ["abstract"] = submission.Abstract,
                ["keywords"] = submission.Keywords ?? "Not provided",
                ["full_text"] = truncatedText
            };

            var result = await _kernel.InvokePromptAsync(_summaryPrompt, arguments);
            var summary = result.ToString().Trim();

            _logger.LogInformation("Summary generated successfully. Length: {Length} characters", summary.Length);

            var wordCount = summary.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Length;

            return new SummaryResult
            {
                Summary = summary,
                SummarySuccessful = true,
                SummaryWordCount = wordCount
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating summary for submission: {SubmissionId}", submission.Id);
            return new SummaryResult
            {
                SummarySuccessful = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
