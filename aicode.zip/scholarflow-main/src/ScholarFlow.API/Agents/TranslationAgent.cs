using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.Common;

namespace ScholarFlow.API.Agents;

public interface ITranslationAgent
{
    Task<string> TranslateToEnglishAsync(string text, string sourceLanguage);
    Task<string> TranslateIfNeededAsync(string text, string detectedLanguage);
    Task<string> TranslateFromEnglishAsync(string text, string targetLanguage);
}

/// <summary>
/// Plugin for translating research papers to English
/// </summary>
public class TranslationAgent : ITranslationAgent
{
    private readonly Kernel _kernel;
    private readonly ILogger<TranslationAgent> _logger;
    private readonly string _translatePrompt;

    public TranslationAgent(Kernel kernel, ILogger<TranslationAgent> logger)
    {
        _kernel = kernel;
        _logger = logger;
        
        // Load prompt template from file
        var promptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Prompts", "Translation", "skprompt.txt");
        _translatePrompt = File.ReadAllText(promptPath);
    }

    [KernelFunction, Description("Translates text from source language to English")]
    public async Task<string> TranslateToEnglishAsync(
        [Description("The text to translate")] string text,
        [Description("The source language of the text")] string sourceLanguage)
    {
        try
        {
            // If text is within token limit, translate directly
            if (text.Length <= AppConstants.Translation.MaxChunkSizeForTranslation)
            {
                var arguments = new KernelArguments
                {
                    ["text"] = text,
                    ["source_language"] = sourceLanguage
                };

                var result = await _kernel.InvokePromptAsync(_translatePrompt, arguments);
                return result.ToString().Trim();
            }

            // For large texts, chunk and translate
            _logger.LogInformation("Text length ({Length}) exceeds chunk size, translating in chunks", text.Length);
            var chunks = ChunkText(text, AppConstants.Translation.MaxChunkSizeForTranslation);
            var translatedChunks = new List<string>();

            for (int i = 0; i < chunks.Count; i++)
            {
                _logger.LogInformation("Translating chunk {Index}/{Total}", i + 1, chunks.Count);
                
                var arguments = new KernelArguments
                {
                    ["text"] = chunks[i],
                    ["source_language"] = sourceLanguage
                };

                var result = await _kernel.InvokePromptAsync(_translatePrompt, arguments);
                translatedChunks.Add(result.ToString().Trim());
            }

            var fullTranslation = string.Join("\n\n", translatedChunks);
            _logger.LogInformation("Completed translation of {ChunkCount} chunks", chunks.Count);
            return fullTranslation;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error translating from {Language}", sourceLanguage);
            throw;
        }
    }

    public async Task<string> TranslateIfNeededAsync(string text, string detectedLanguage)
    {
        _logger.LogInformation("Checking if translation needed for language: {Language}", detectedLanguage);

        // Check if text is already in English
        if (detectedLanguage.Equals("English", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation("Text is already in English, skipping translation");
            return text;
        }

        _logger.LogInformation("Translating from {Language} to English", detectedLanguage);
        return await TranslateToEnglishAsync(text, detectedLanguage);
    }

    [KernelFunction, Description("Translates text from English to target language")]
    public async Task<string> TranslateFromEnglishAsync(
        [Description("The English text to translate")] string text,
        [Description("The target language to translate to")] string targetLanguage)
    {
        try
        {
            // If target is English or "en", return as-is
            if (targetLanguage.Equals("English", StringComparison.OrdinalIgnoreCase) || 
                targetLanguage.Equals("en", StringComparison.OrdinalIgnoreCase))
            {
                return text;
            }

            // If text is within token limit, translate directly
            if (text.Length <= AppConstants.Translation.MaxChunkSizeForTranslation)
            {
                var arguments = new KernelArguments
                {
                    ["text"] = text,
                    ["source_language"] = "English",
                    ["target_language"] = targetLanguage
                };

                var promptWithTarget = _translatePrompt.Replace("to English", $"to {targetLanguage}");
                var result = await _kernel.InvokePromptAsync(promptWithTarget, arguments);
                return result.ToString().Trim();
            }

            // For large texts, chunk and translate
            _logger.LogInformation("Text length ({Length}) exceeds chunk size, translating in chunks", text.Length);
            var chunks = ChunkText(text, AppConstants.Translation.MaxChunkSizeForTranslation);
            var translatedChunks = new List<string>();

            for (int i = 0; i < chunks.Count; i++)
            {
                _logger.LogInformation("Translating chunk {Index}/{Total}", i + 1, chunks.Count);
                
                var arguments = new KernelArguments
                {
                    ["text"] = chunks[i],
                    ["source_language"] = "English",
                    ["target_language"] = targetLanguage
                };

                var promptWithTarget = _translatePrompt.Replace("to English", $"to {targetLanguage}");
                var result = await _kernel.InvokePromptAsync(promptWithTarget, arguments);
                translatedChunks.Add(result.ToString().Trim());
            }

            var fullTranslation = string.Join("\n\n", translatedChunks);
            _logger.LogInformation("Completed translation of {ChunkCount} chunks", chunks.Count);
            return fullTranslation;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error translating to {Language}", targetLanguage);
            throw;
        }
    }

    /// <summary>
    /// Splits text into chunks of specified size, respecting paragraph boundaries where possible
    /// </summary>
    private List<string> ChunkText(string text, int chunkSize)
    {
        var chunks = new List<string>();
        
        if (string.IsNullOrWhiteSpace(text))
        {
            return chunks;
        }

        var remainingText = text;
        
        while (remainingText.Length > 0)
        {
            if (remainingText.Length <= chunkSize)
            {
                chunks.Add(remainingText);
                break;
            }

            // Try to find a paragraph break near the chunk size
            var chunkEnd = chunkSize;
            var searchStart = Math.Max(0, chunkSize - 500); // Look back up to 500 chars for a break
            
            // Look for paragraph breaks (double newline)
            var paragraphBreak = remainingText.LastIndexOf("\n\n", chunkEnd, chunkEnd - searchStart);
            if (paragraphBreak > 0)
            {
                chunkEnd = paragraphBreak + 2; // Include the newlines
            }
            else
            {
                // Look for single newline
                var lineBreak = remainingText.LastIndexOf("\n", chunkEnd, Math.Min(chunkEnd, chunkEnd - searchStart));
                if (lineBreak > 0)
                {
                    chunkEnd = lineBreak + 1;
                }
                else
                {
                    // Look for sentence end
                    var sentenceEnd = Math.Max(
                        remainingText.LastIndexOf(". ", chunkEnd, Math.Min(chunkEnd, chunkEnd - searchStart)),
                        remainingText.LastIndexOf("! ", chunkEnd, Math.Min(chunkEnd, chunkEnd - searchStart))
                    );
                    sentenceEnd = Math.Max(sentenceEnd,
                        remainingText.LastIndexOf("? ", chunkEnd, Math.Min(chunkEnd, chunkEnd - searchStart))
                    );
                    
                    if (sentenceEnd > 0)
                    {
                        chunkEnd = sentenceEnd + 2; // Include the punctuation and space
                    }
                }
            }

            chunks.Add(remainingText.Substring(0, chunkEnd));
            remainingText = remainingText.Substring(chunkEnd);
        }

        return chunks;
    }
}
