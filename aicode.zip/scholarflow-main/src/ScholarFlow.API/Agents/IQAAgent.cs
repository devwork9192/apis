using ScholarFlow.API.DTOs.Chat;

namespace ScholarFlow.API.Agents;

/// <summary>
/// Agent for question answering with multilingual support
/// </summary>
public interface IQAAgent
{
    /// <summary>
    /// Answers a question using RAG and supports multiple languages
    /// </summary>
    /// <param name="query">The question to answer</param>
    /// <param name="language">Optional language code (ISO 639-1)</param>
    /// <param name="topK">Number of papers to retrieve (default: 5)</param>
    /// <param name="submissionId">Optional: Limit search to specific submission</param>
    /// <returns>Answer with sources and citations</returns>
    Task<ChatResponse> AnswerQuestionAsync(
        string query, 
        string? language = null, 
        int topK = 5, 
        Guid? submissionId = null);
}
