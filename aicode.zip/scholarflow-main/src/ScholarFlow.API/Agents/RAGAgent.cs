using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Memory;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Agents;

public interface IRAGAgent
{
    Task<RAGResult> StoreDocumentAsync(Submission submission);
}

/// <summary>
/// Agent for RAG (Retrieval-Augmented Generation) operations
/// Handles document embedding and vector storage for semantic search
/// </summary>
public class RAGAgent : IRAGAgent
{
    private readonly IEmbeddingService _embeddingService;
    private readonly IVectorStoreService _vectorStoreService;
    private readonly ILogger<RAGAgent> _logger;

    public RAGAgent(
        IEmbeddingService embeddingService,
        IVectorStoreService vectorStoreService,
        ILogger<RAGAgent> logger)
    {
        _embeddingService = embeddingService;
        _vectorStoreService = vectorStoreService;
        _logger = logger;
    }

    /// <summary>
    /// Stores a research paper in the vector database for RAG retrieval
    /// </summary>
    [KernelFunction, Description("Stores a research paper with embeddings in the vector database for semantic search")]
    public async Task<RAGResult> StoreDocumentAsync(
        [Description("The submission containing the research paper")] Submission submission)
    {
        try
        {
            _logger.LogInformation("Starting RAG storage for submission: {SubmissionId}", submission.Id);

            // Determine which text to use (translated if available, otherwise raw)
            var textToEmbed = submission.WasTranslated 
                ? submission.TranslatedText 
                : submission.RawText;

            if (string.IsNullOrWhiteSpace(textToEmbed))
            {
                _logger.LogWarning("No text available for embedding. Submission: {SubmissionId}", submission.Id);
                return new RAGResult
                {
                    StoredSuccessfully = false,
                    ErrorMessage = "No text content available for RAG storage"
                };
            }

            // Truncate text if too long (keeping first 30k chars for embedding)
            var truncatedText = textToEmbed.Length > 30000 
                ? textToEmbed.Substring(0, 30000) 
                : textToEmbed;

            _logger.LogDebug("Generating embedding for {Length} characters", truncatedText.Length);

            // Generate embedding for the document
            var embedding = await _embeddingService.GenerateEmbeddingAsync(truncatedText);

            // Prepare metadata
            var metadata = new Dictionary<string, object>
            {
                ["title"] = submission.Title ?? "Untitled",
                ["authors"] = submission.Authors ?? "Unknown",
                ["language"] = submission.DetectedLanguage ?? "Unknown",
                ["wasTranslated"] = submission.WasTranslated,
                ["uploadedAt"] = submission.UploadedAt,
                ["abstract"] = submission.Abstract ?? string.Empty
            };

            // Store in vector database
            await _vectorStoreService.StoreDocumentAsync(
                submission.Id,
                truncatedText,
                embedding,
                metadata);

            _logger.LogInformation("Successfully stored document in vector store");

            // Search for related documents (top 5)
            var relatedDocs = await _vectorStoreService.SearchByEmbeddingAsync(embedding, topK: 5);
            var relatedIds = relatedDocs
                .Where(r => r.SubmissionId != submission.Id) // Exclude self
                .Select(r => r.SubmissionId)
                .ToList();

            _logger.LogInformation("Found {Count} related documents", relatedIds.Count);

            return new RAGResult
            {
                StoredSuccessfully = true,
                RelatedDocumentsCount = relatedIds.Count,
                RelatedSubmissionIds = relatedIds
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to store document in RAG. Submission: {SubmissionId}", submission.Id);
            return new RAGResult
            {
                StoredSuccessfully = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
