using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.DTOs.Agents;

namespace ScholarFlow.API.Agents;

public interface IExtractionAgent
{
    Task<ExtractionResult> ExtractMetadataAsync(string text);
}

/// <summary>
/// Plugin for extracting metadata from research papers
/// </summary>
public class ExtractionAgent : IExtractionAgent
{
    private readonly Kernel _kernel;
    private readonly ILogger<ExtractionAgent> _logger;
    private readonly string _extractionPrompt;

    public ExtractionAgent(Kernel kernel, ILogger<ExtractionAgent> logger)
    {
        _kernel = kernel;
        _logger = logger;
        
        // Load prompt template from file
        var promptPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Prompts", "Extraction", "skprompt.txt");
        _extractionPrompt = File.ReadAllText(promptPath);
    }

    /// <summary>
    /// Extracts metadata fields from the paper text using GPT
    /// </summary>
    [KernelFunction, Description("Extracts metadata (title, authors, abstract, etc.) from research paper text")]
    public async Task<ExtractionResult> ExtractMetadataAsync(
        [Description("The full text of the research paper")] string text)
    {
        try
        {
            _logger.LogInformation("Starting metadata extraction");

            // Limit text to 8000 characters to avoid token limits
            var truncatedText = text.Length > 8000 ? text.Substring(0, 8000) : text;

            var arguments = new KernelArguments
            {
                ["text"] = truncatedText
            };

            var result = await _kernel.InvokePromptAsync(_extractionPrompt, arguments);
            var extractedText = result.ToString();

            _logger.LogInformation("Raw extraction result length: {Length}", extractedText.Length);

            var extraction = ParseExtractionResult(extractedText);
            extraction.ExtractionSuccessful = true;

            _logger.LogInformation("Metadata extraction completed successfully");
            return extraction;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during metadata extraction");
            return new ExtractionResult
            {
                ExtractionSuccessful = false,
                ErrorMessage = ex.Message
            };
        }
    }

    private ExtractionResult ParseExtractionResult(string extractedText)
    {
        var result = new ExtractionResult();

        try
        {
            var lines = extractedText.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            
            foreach (var line in lines)
            {
                var trimmedLine = line.Trim();
                
                if (trimmedLine.StartsWith("TITLE:", StringComparison.OrdinalIgnoreCase))
                {
                    result.Title = ExtractValue(trimmedLine, "TITLE:");
                }
                else if (trimmedLine.StartsWith("AUTHORS:", StringComparison.OrdinalIgnoreCase))
                {
                    result.Authors = ExtractValue(trimmedLine, "AUTHORS:");
                }
                else if (trimmedLine.StartsWith("AFFILIATIONS:", StringComparison.OrdinalIgnoreCase))
                {
                    result.Affiliations = ExtractValue(trimmedLine, "AFFILIATIONS:");
                }
                else if (trimmedLine.StartsWith("ABSTRACT:", StringComparison.OrdinalIgnoreCase))
                {
                    result.Abstract = ExtractValue(trimmedLine, "ABSTRACT:");
                }
                else if (trimmedLine.StartsWith("KEYWORDS:", StringComparison.OrdinalIgnoreCase))
                {
                    result.Keywords = ExtractValue(trimmedLine, "KEYWORDS:");
                }
                else if (trimmedLine.StartsWith("REFERENCES:", StringComparison.OrdinalIgnoreCase))
                {
                    result.References = ExtractValue(trimmedLine, "REFERENCES:");
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error parsing extraction result, returning partial data");
        }

        return result;
    }

    private string? ExtractValue(string line, string prefix)
    {
        var value = line.Substring(prefix.Length).Trim();
        
        // Handle "Not found" or empty responses
        if (string.IsNullOrWhiteSpace(value) || 
            value.Equals("Not found", StringComparison.OrdinalIgnoreCase) ||
            value.Equals("N/A", StringComparison.OrdinalIgnoreCase))
        {
            return null;
        }

        return value;
    }
}
