using Microsoft.Extensions.Options;
using Microsoft.SemanticKernel;
using System.ComponentModel;
using ScholarFlow.API.Configuration;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Agents;

public interface IValidationAgent
{
    Task<ValidationResult> ValidateAsync(Submission submission);
}

/// <summary>
/// Agent responsible for validating research paper submissions
/// </summary>
public class ValidationAgent : IValidationAgent
{
    private readonly ValidationRulesSettings _rules;
    private readonly ILogger<ValidationAgent> _logger;
    private readonly IPlagiarismService _plagiarismService;
    private readonly IContentSafetyService _contentSafetyService;

    public ValidationAgent(
        IOptions<ValidationRulesSettings> rules,
        ILogger<ValidationAgent> logger,
        IPlagiarismService plagiarismService,
        IContentSafetyService contentSafetyService)
    {
        _rules = rules.Value;
        _logger = logger;
        _plagiarismService = plagiarismService;
        _contentSafetyService = contentSafetyService;
    }

    /// <summary>
    /// Validates a submission against all rules
    /// </summary>
    [KernelFunction, Description("Validates research paper submission against configured rules (metadata completeness, page count, word count, plagiarism, toxicity)")]
    public async Task<ValidationResult> ValidateAsync(
        [Description("The submission to validate")] Submission submission)
    {
        try
        {
            _logger.LogInformation("Starting validation for submission: {SubmissionId}", submission.Id);

            var result = new ValidationResult
            {
                IsValid = true
            };

            // 1. Validate required metadata fields
            ValidateMetadata(submission, result);

            // 2. Validate page count
            ValidatePageCount(submission, result);

            // 3. Validate content structure (check for required sections)
            await ValidateContentStructureAsync(submission, result);

            // 4. Check for plagiarism
            await CheckPlagiarismAsync(submission, result);

            // 5. Check for toxicity/inappropriate content
            await CheckContentSafetyAsync(submission, result);

            // 6. Determine if human review is needed
            DetermineHumanReviewRequirement(result);

            _logger.LogInformation("Validation completed for submission: {SubmissionId}. Valid: {IsValid}, Warnings: {WarningCount}, Errors: {ErrorCount}",
                submission.Id, result.IsValid, result.Warnings.Count, result.Errors.Count);

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during validation for submission: {SubmissionId}", submission.Id);
            return new ValidationResult
            {
                IsValid = false,
                ErrorMessage = ex.Message,
                Errors = new List<string> { $"Validation error: {ex.Message}" }
            };
        }
    }

    private void ValidateMetadata(Submission submission, ValidationResult result)
    {
        // Check Title
        if (string.IsNullOrWhiteSpace(submission.Title))
        {
            result.Errors.Add("Title is missing or empty");
            result.IsValid = false;
            result.HasTitle = false;
        }
        else
        {
            result.HasTitle = true;
            
            // Check title length
            if (submission.Title.Length < 10)
            {
                result.Warnings.Add("Title is very short (less than 10 characters)");
            }
            else if (submission.Title.Length > 300)
            {
                result.Warnings.Add("Title is very long (more than 300 characters)");
            }
        }

        // Check Authors
        if (string.IsNullOrWhiteSpace(submission.Authors))
        {
            result.Errors.Add("Authors field is missing or empty");
            result.IsValid = false;
            result.HasAuthors = false;
        }
        else
        {
            result.HasAuthors = true;
            
            // Check if multiple authors are comma-separated
            var authorCount = submission.Authors.Split(',', StringSplitOptions.RemoveEmptyEntries).Length;
            if (authorCount == 0)
            {
                result.Errors.Add("No valid authors found");
                result.IsValid = false;
            }
            else if (authorCount > 20)
            {
                result.Warnings.Add($"Unusually high number of authors ({authorCount})");
            }
        }

        // Check Abstract
        if (string.IsNullOrWhiteSpace(submission.Abstract))
        {
            result.Errors.Add("Abstract is missing or empty");
            result.IsValid = false;
            result.HasAbstract = false;
        }
        else
        {
            result.HasAbstract = true;
            
            // Check abstract length
            if (submission.Abstract.Length < 100)
            {
                result.Warnings.Add("Abstract is very short (less than 100 characters)");
            }
            else if (submission.Abstract.Length > 3000)
            {
                result.Warnings.Add("Abstract is very long (more than 3000 characters)");
            }
        }

        // Optional fields - warnings only
        if (string.IsNullOrWhiteSpace(submission.Affiliations))
        {
            result.Warnings.Add("Affiliations not provided or not extracted");
        }

        if (string.IsNullOrWhiteSpace(submission.Keywords))
        {
            result.Warnings.Add("Keywords not provided or not extracted");
        }
    }

    private void ValidatePageCount(Submission submission, ValidationResult result)
    {
        if (submission.PageCount < _rules.MinPageCount)
        {
            result.Errors.Add($"Page count ({submission.PageCount}) is below minimum ({_rules.MinPageCount})");
            result.IsValid = false;
            result.PageCountValid = false;
        }
        else if (submission.PageCount > _rules.MaxPageCount)
        {
            result.Errors.Add($"Page count ({submission.PageCount}) exceeds maximum ({_rules.MaxPageCount})");
            result.IsValid = false;
            result.PageCountValid = false;
        }
        else
        {
            result.PageCountValid = true;
        }

        // Warning for scanned documents
        if (submission.IsScanned)
        {
            result.Warnings.Add("Document appears to be scanned. OCR quality may affect extraction accuracy.");
        }
    }

    private async Task ValidateContentStructureAsync(Submission submission, ValidationResult result)
    {
        // Get the text to analyze (translated or raw)
        var textToAnalyze = submission.WasTranslated ? submission.TranslatedText : submission.RawText;

        if (string.IsNullOrWhiteSpace(textToAnalyze))
        {
            result.Errors.Add("No text content available for validation");
            result.IsValid = false;
            result.ContainsRequiredSections = false;
            return;
        }

        var textLength = textToAnalyze.Length;
        var textPreview = textToAnalyze.Length > 200 ? textToAnalyze.Substring(0, 200) : textToAnalyze;
        
        _logger.LogInformation("Validating content structure. Text length: {Length} characters, Page count: {PageCount}. Preview: {Preview}...", 
            textLength, submission.PageCount, textPreview.Replace("\n", " ").Replace("\r", ""));

        // Check for common research paper sections
        var requiredSections = _rules.RequiredSections ?? new List<string>();
        var foundSections = new List<string>();
        var missingSections = new List<string>();

        // Common section headers to check
        var commonSections = new[]
        {
            "introduction",
            "method",
            "result",
            "conclusion",
            "reference",
            "abstract"
        };

        // If no specific rules configured, use common sections
        var sectionsToCheck = requiredSections.Count > 0 ? requiredSections.ToArray() : commonSections;

        foreach (var section in sectionsToCheck)
        {
            if (textToAnalyze.Contains(section, StringComparison.OrdinalIgnoreCase))
            {
                foundSections.Add(section);
            }
            else
            {
                missingSections.Add(section);
            }
        }

        // If less than 50% of expected sections found, add warning
        if (foundSections.Count < sectionsToCheck.Length / 2)
        {
            result.Warnings.Add($"Some expected sections may be missing: {string.Join(", ", missingSections)}");
            result.ContainsRequiredSections = false;
        }
        else
        {
            result.ContainsRequiredSections = true;
        }

        // Check overall content quality - use more robust word counting
        // Split by any whitespace (spaces, tabs, newlines) and filter empty entries
        var words = textToAnalyze.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        var wordCount = words.Length;
        var expectedMinWords = submission.PageCount * 200; // Rough estimate: ~200-300 words per page minimum

        _logger.LogInformation("Word count: {WordCount} (first 5 words: {FirstWords}), Expected minimum for {PageCount} pages: ~{ExpectedMin}", 
            wordCount, 
            string.Join(", ", words.Take(5)),
            submission.PageCount, 
            expectedMinWords);

        // If extraction was successful with good metadata, don't warn about word count
        // A detailed abstract suggests the text extraction worked properly
        var hasGoodMetadata = !string.IsNullOrWhiteSpace(submission.Abstract) && submission.Abstract.Length > 200;
        
        if (hasGoodMetadata)
        {
            _logger.LogInformation("Extraction produced detailed metadata (abstract: {AbstractLength} chars), skipping word count validation", 
                submission.Abstract?.Length ?? 0);
        }
        else if (wordCount < expectedMinWords)
        {
            result.Warnings.Add($"Document has low word count ({wordCount} words) for {submission.PageCount} pages. Expected at least {expectedMinWords} words. This may indicate extraction issues or sparse content.");
        }
        else if (wordCount < 1000 && submission.PageCount >= 8)
        {
            result.Warnings.Add($"Document has low word count ({wordCount} words) for an {submission.PageCount}-page document. Text extraction may have been incomplete.");
        }

        await Task.CompletedTask; // For async consistency
    }

    private async Task CheckPlagiarismAsync(Submission submission, ValidationResult result)
    {
        try
        {
            // Get the text to analyze (translated or raw)
            var textToAnalyze = submission.WasTranslated ? submission.TranslatedText : submission.RawText;

            if (string.IsNullOrWhiteSpace(textToAnalyze))
            {
                _logger.LogWarning("No text available for plagiarism check for submission: {SubmissionId}", submission.Id);
                return;
            }

            _logger.LogInformation("Checking plagiarism for submission: {SubmissionId}", submission.Id);

            var plagiarismResult = await _plagiarismService.CheckPlagiarismAsync(
                textToAnalyze, 
                submission.Id, 
                0.85); // Threshold of 85% similarity

            if (plagiarismResult.CheckSuccessful)
            {
                result.PlagiarismScore = plagiarismResult.PlagiarismScore;

                if (plagiarismResult.IsAboveThreshold)
                {
                    result.Errors.Add($"High plagiarism detected: {plagiarismResult.PlagiarismScore:P0} similarity with existing submissions");
                    result.IsValid = false;
                    
                    if (plagiarismResult.SimilarSubmissions.Any())
                    {
                        var topMatch = plagiarismResult.SimilarSubmissions.First();
                        result.Warnings.Add($"Most similar submission: ID {topMatch.SubmissionId} ({topMatch.SimilarityScore:P0} similarity)");
                    }
                }
                // 25% deviation threshold: 60-85% similarity requires human review
                else if (plagiarismResult.PlagiarismScore >= 0.60 && plagiarismResult.PlagiarismScore < _rules.PlagiarismThreshold)
                {
                    result.Warnings.Add($"Moderate plagiarism detected: {plagiarismResult.PlagiarismScore:P0} similarity. Requires human review.");
                    result.RequiresHumanReview = true;
                    
                    if (plagiarismResult.SimilarSubmissions.Any())
                    {
                        var topMatch = plagiarismResult.SimilarSubmissions.First();
                        result.Warnings.Add($"Most similar submission: ID {topMatch.SubmissionId} ({topMatch.SimilarityScore:P0} similarity)");
                    }
                }
                else if (plagiarismResult.PlagiarismScore >= 0.50)
                {
                    result.Warnings.Add($"Some similarity detected: {plagiarismResult.PlagiarismScore:P0} with existing submissions");
                }

                _logger.LogInformation("Plagiarism check completed for submission: {SubmissionId}. Score: {Score:P0}", 
                    submission.Id, result.PlagiarismScore);
            }
            else
            {
                _logger.LogWarning("Plagiarism check failed for submission: {SubmissionId}. Error: {Error}", 
                    submission.Id, plagiarismResult.ErrorMessage);
                result.Warnings.Add($"Plagiarism check could not be completed: {plagiarismResult.ErrorMessage}");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during plagiarism check for submission: {SubmissionId}", submission.Id);
            result.Warnings.Add($"Plagiarism check error: {ex.Message}");
        }
    }

    private async Task CheckContentSafetyAsync(Submission submission, ValidationResult result)
    {
        try
        {
            // Get the text to analyze (translated or raw)
            var textToAnalyze = submission.WasTranslated ? submission.TranslatedText : submission.RawText;

            if (string.IsNullOrWhiteSpace(textToAnalyze))
            {
                _logger.LogWarning("No text available for content safety check for submission: {SubmissionId}", submission.Id);
                return;
            }

            _logger.LogInformation("Checking content safety for submission: {SubmissionId}", submission.Id);

            var safetyResult = await _contentSafetyService.AnalyzeTextAsync(
                textToAnalyze, 
                0.7); // Threshold of 70% toxicity

            if (safetyResult.CheckSuccessful)
            {
                result.ToxicityScore = safetyResult.ToxicityScore;

                if (safetyResult.IsAboveThreshold)
                {
                    result.Errors.Add($"Inappropriate content detected: {safetyResult.ToxicityScore:P0} toxicity score");
                    result.IsValid = false;

                    if (safetyResult.FlaggedCategories.Any())
                    {
                        result.Warnings.Add($"Flagged categories: {string.Join(", ", safetyResult.FlaggedCategories)}");
                    }
                }
                // 25% deviation threshold: 45-70% toxicity requires human review
                else if (safetyResult.ToxicityScore >= 0.45 && safetyResult.ToxicityScore < _rules.ToxicityThreshold)
                {
                    result.Warnings.Add($"Moderate toxicity detected: {safetyResult.ToxicityScore:P0} toxicity score. Requires human review.");
                    result.RequiresHumanReview = true;
                    
                    if (safetyResult.FlaggedCategories.Any())
                    {
                        result.Warnings.Add($"Flagged categories: {string.Join(", ", safetyResult.FlaggedCategories)}");
                    }
                }
                else if (safetyResult.ToxicityScore >= 0.35)
                {
                    result.Warnings.Add($"Potential content concerns: {safetyResult.ToxicityScore:P0} toxicity score");
                }

                _logger.LogInformation("Content safety check completed for submission: {SubmissionId}. Score: {Score:P0}", 
                    submission.Id, result.ToxicityScore);
            }
            else
            {
                _logger.LogWarning("Content safety check failed for submission: {SubmissionId}. Error: {Error}", 
                    submission.Id, safetyResult.ErrorMessage);
                result.Warnings.Add($"Content safety check could not be completed: {safetyResult.ErrorMessage}");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during content safety check for submission: {SubmissionId}", submission.Id);
            result.Warnings.Add($"Content safety check error: {ex.Message}");
        }
    }

    private void DetermineHumanReviewRequirement(ValidationResult result)
    {
        // ALL submissions require human review/approval
        // Set flag to true for ALL, but track priority level
        result.RequiresHumanReview = true;
        
        // High priority review needed if:
        // 1. There are any validation errors
        // 2. Too many warnings (5+)
        // 3. Quality score is below threshold
        
        // Note: Errors and warnings lists already contain details about:
        // - High plagiarism (>85%)
        // - Moderate plagiarism (60-85%) - 25% deviation threshold
        // - High toxicity (>70%)
        // - Moderate toxicity (45-70%) - 25% deviation threshold
        // - Missing metadata
        // - Page count issues
        
        // The presence of errors/warnings indicates priority level,
        // but all submissions go through human review workflow
    }
}
