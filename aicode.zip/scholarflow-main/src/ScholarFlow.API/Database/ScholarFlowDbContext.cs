using Microsoft.EntityFrameworkCore;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Database;

public class ScholarFlowDbContext : DbContext
{
    public ScholarFlowDbContext(DbContextOptions<ScholarFlowDbContext> options)
        : base(options)
    {
    }

    public DbSet<Submission> Submissions { get; set; }
    public DbSet<AuditLog> AuditLogs { get; set; }
    public DbSet<ChatMessage> ChatMessages { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Configure Submission entity
        modelBuilder.Entity<Submission>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.FileName).IsRequired();
            entity.Property(e => e.FilePath).IsRequired();
            entity.HasIndex(e => e.Status);
            entity.HasIndex(e => e.UploadedAt);
        });

        // Configure AuditLog entity
        modelBuilder.Entity<AuditLog>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasOne(e => e.Submission)
                  .WithMany(s => s.AuditLogs)
                  .HasForeignKey(e => e.SubmissionId)
                  .OnDelete(DeleteBehavior.Cascade);
            entity.HasIndex(e => e.SubmissionId);
            entity.HasIndex(e => e.Timestamp);
        });

        // Configure ChatMessage entity
        modelBuilder.Entity<ChatMessage>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasOne(e => e.Submission)
                  .WithMany()
                  .HasForeignKey(e => e.SubmissionId)
                  .OnDelete(DeleteBehavior.SetNull);
            entity.HasIndex(e => e.SubmissionId);
            entity.HasIndex(e => e.Timestamp);
            entity.Property(e => e.Role).IsRequired();
            entity.Property(e => e.Content).IsRequired();
        });
    }
}
