namespace ScholarFlow.API.Common;

/// <summary>
/// Application-wide constants
/// </summary>
public static class AppConstants
{
    /// <summary>
    /// Status values for health checks and processing
    /// </summary>
    public static class Status
    {
        public const string Healthy = "healthy";
        public const string Unhealthy = "unhealthy";
        public const string Uploaded = "Uploaded";
        public const string Processing = "Processing";
        public const string Preprocessed = "Preprocessed";
        public const string Failed = "Failed";
    }

    /// <summary>
    /// Processing stage names
    /// </summary>
    public static class Stage
    {
        public const string Upload = "Upload";
        public const string Preprocess = "Preprocess";
        public const string Translation = "Translation";
        public const string Extraction = "Extraction";
        public const string Validation = "Validation";
    }

    /// <summary>
    /// Health check component names
    /// </summary>
    public static class HealthComponents
    {
        public const string Database = "database";
        public const string AIService = "ai_service";
        public const string System = "system";
    }

    /// <summary>
    /// Default user identifiers
    /// </summary>
    public static class Users
    {
        public const string Admin = "admin";
        public const string System = "system";
        public const string Anonymous = "anonymous";
    }

    /// <summary>
    /// File validation constraints
    /// </summary>
    public static class FileConstraints
    {
        public const long MaxFileSizeBytes = 50 * 1024 * 1024; // 50MB
        public const int MaxFileSizeMB = 50;
        public const string PdfExtension = ".pdf";
        public const string PdfMimeType = "application/pdf";
    }

    /// <summary>
    /// Configuration keys
    /// </summary>
    public static class ConfigKeys
    {
        public const string StorageUploadPath = "Storage:UploadPath";
        public const string StorageDatabasePath = "Storage:DatabasePath";
        public const string AzureOpenAIEndpoint = "AzureOpenAI:Endpoint";
        public const string AzureOpenAIApiKey = "AzureOpenAI:ApiKey";
        public const string AzureOpenAIChatDeployment = "AzureOpenAI:ChatDeploymentName";
        public const string AzureOpenAIEmbeddingDeployment = "AzureOpenAI:EmbeddingDeploymentName";
    }

    /// <summary>
    /// Default paths and filenames
    /// </summary>
    public static class Paths
    {
        public const string DefaultUploadPath = "uploads";
        public const string DefaultDatabaseName = "scholarflow.db";
    }

    /// <summary>
    /// Language detection constants
    /// </summary>
    public static class LanguageDetection
    {
        public const string UnknownLanguage = "Unknown";
        public const string English = "English";
        public const int TextSampleSizeForDetection = 1000;
    }

    /// <summary>
    /// Translation agent constants
    /// </summary>
    public static class Translation
    {
        /// <summary>
        /// Maximum characters per chunk for translation to avoid token limit (8192 tokens)
        /// Using 6000 chars (~1500 tokens) to leave room for prompt overhead
        /// </summary>
        public const int MaxChunkSizeForTranslation = 6000;
    }

    /// <summary>
    /// AI prompts
    /// </summary>
    public static class Prompts
    {
        public const string HealthCheckPrompt = "Respond with only the word 'OK' if you can read this.";
    }

    /// <summary>
    /// Standard messages
    /// </summary>
    public static class Messages
    {
        // Success messages
        public const string FileUploadedSuccessfully = "File uploaded successfully. Use /process endpoint to start processing.";
        public const string PreprocessingCompletedSuccessfully = "Preprocessing completed successfully";
        public const string AIServiceConnectedAndResponding = "Azure OpenAI connected and responding";

        // Error messages
        public const string NoFileProvided = "No file provided";
        public const string SubmissionNotFound = "Submission not found";
        public const string FileIsEmptyOrNull = "File is empty or null";
        public const string OnlyPdfFilesSupported = "Only PDF files are supported";
        public const string SubmissionNotFoundOrProcessingFailed = "Submission not found or processing failed";
        public const string ErrorUploadingFile = "An error occurred while uploading the file";
        public const string ErrorProcessingSubmission = "An error occurred while processing the submission";
        public const string ErrorRetrievingSubmissionStatus = "An error occurred while retrieving submission status";
        public const string ErrorRetrievingSubmission = "An error occurred while retrieving submission";
        public const string HealthCheckFailed = "Health check failed";
        public const string DatabaseConnectionFailed = "Database connection failed";
        public const string AIServiceConnectionFailed = "AI service connection failed";

        // Info messages
        public const string DatabaseConnectedWithSubmissionCount = "Connected. Total submissions: {0}";
    }

    /// <summary>
    /// Heuristics for document analysis
    /// </summary>
    public static class DocumentHeuristics
    {
        public const int MinTextLengthPerPageForScanned = 50;
        public const double ScannedPageThresholdPercentage = 0.3; // 30% of pages with low text
    }

    /// <summary>
    /// HTTP Status codes (for clarity)
    /// </summary>
    public static class HttpStatusCodes
    {
        public const int Ok = 200;
        public const int BadRequest = 400;
        public const int NotFound = 404;
        public const int InternalServerError = 500;
        public const int ServiceUnavailable = 503;
    }
}
