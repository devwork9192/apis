namespace ScholarFlow.API.DTOs.Auth;

/// <summary>
/// Login response with JWT token
/// </summary>
public class LoginResponse
{
    /// <summary>
    /// JWT access token
    /// </summary>
    public string Token { get; set; } = string.Empty;

    /// <summary>
    /// User role (Author or Reviewer)
    /// </summary>
    public string Role { get; set; } = string.Empty;

    /// <summary>
    /// Username/email
    /// </summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Token expiration timestamp
    /// </summary>
    public DateTime ExpiresAt { get; set; }
}
