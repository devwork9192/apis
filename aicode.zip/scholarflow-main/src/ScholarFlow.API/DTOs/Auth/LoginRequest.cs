using System.ComponentModel.DataAnnotations;

namespace ScholarFlow.API.DTOs.Auth;

/// <summary>
/// Login request with credentials
/// </summary>
public class LoginRequest
{
    /// <summary>
    /// Username or email
    /// </summary>
    [Required]
    [EmailAddress]
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// User password
    /// </summary>
    [Required]
    [MinLength(6)]
    public string Password { get; set; } = string.Empty;
}
