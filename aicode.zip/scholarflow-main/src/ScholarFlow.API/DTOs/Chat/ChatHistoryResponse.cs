namespace ScholarFlow.API.DTOs.Chat;

/// <summary>
/// Response containing chat history for a submission
/// </summary>
public class ChatHistoryResponse
{
    /// <summary>
    /// Submission ID
    /// </summary>
    public Guid SubmissionId { get; set; }
    
    /// <summary>
    /// Chat messages in chronological order
    /// </summary>
    public List<ChatMessageDto> Messages { get; set; } = new();
}

/// <summary>
/// A single chat message
/// </summary>
public class ChatMessageDto
{
    /// <summary>
    /// Message ID
    /// </summary>
    public Guid Id { get; set; }
    
    /// <summary>
    /// Role: "user" or "assistant"
    /// </summary>
    public string Role { get; set; } = string.Empty;
    
    /// <summary>
    /// Message content (question or answer)
    /// </summary>
    public string Content { get; set; } = string.Empty;
    
    /// <summary>
    /// Language of the message
    /// </summary>
    public string? Language { get; set; }
    
    /// <summary>
    /// Submissions cited in this message (for assistant messages)
    /// </summary>
    public List<Guid> CitedSubmissions { get; set; } = new();
    
    /// <summary>
    /// Timestamp of the message
    /// </summary>
    public DateTime Timestamp { get; set; }
}
