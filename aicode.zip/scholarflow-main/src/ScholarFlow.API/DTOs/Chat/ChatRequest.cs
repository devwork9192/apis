using System.ComponentModel.DataAnnotations;

namespace ScholarFlow.API.DTOs.Chat;

/// <summary>
/// Request to ask a question about research papers
/// </summary>
public class ChatRequest
{
    /// <summary>
    /// The question to ask (e.g., "What are the main findings about AI?")
    /// </summary>
    [Required(ErrorMessage = "Query is required")]
    [StringLength(2000, MinimumLength = 3, ErrorMessage = "Query must be between 3 and 2000 characters")]
    public string Query { get; set; } = string.Empty;
    
    /// <summary>
    /// Language code (ISO 639-1) - auto-detected if not provided
    /// Examples: "en", "es", "fr", "de", "ja", "zh"
    /// </summary>
    [StringLength(10)]
    public string? Language { get; set; }
    
    /// <summary>
    /// Number of relevant papers to retrieve (default: 3)
    /// </summary>
    [Range(1, 20, ErrorMessage = "TopK must be between 1 and 20")]
    public int TopK { get; set; } = 3;
    
    /// <summary>
    /// Optional: Specific submission ID to ask about (null = search all papers)
    /// </summary>
    public Guid? SubmissionId { get; set; }
}
