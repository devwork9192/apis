namespace ScholarFlow.API.DTOs.Chat;

/// <summary>
/// Response containing the answer to a research question
/// </summary>
public class ChatResponse
{
    /// <summary>
    /// The generated answer based on research papers
    /// </summary>
    public string Answer { get; set; } = string.Empty;
    
    /// <summary>
    /// Source papers used to generate the answer
    /// </summary>
    public List<SourceReference> Sources { get; set; } = new();
    
    /// <summary>
    /// Detected or specified language of the query
    /// </summary>
    public string DetectedLanguage { get; set; } = string.Empty;
    
    /// <summary>
    /// IDs of submissions cited in the answer
    /// </summary>
    public List<Guid> CitedSubmissions { get; set; } = new();
    
    /// <summary>
    /// Query translated to English (if translation was needed)
    /// </summary>
    public string? TranslatedQuery { get; set; }
    
    /// <summary>
    /// Whether the answer was translated back to the original language
    /// </summary>
    public bool WasTranslated { get; set; }
}

/// <summary>
/// Reference to a source paper used in the answer
/// </summary>
public class SourceReference
{
    /// <summary>
    /// ID of the submission
    /// </summary>
    public Guid SubmissionId { get; set; }
    
    /// <summary>
    /// Title of the paper
    /// </summary>
    public string Title { get; set; } = string.Empty;
    
    /// <summary>
    /// Authors of the paper
    /// </summary>
    public string? Authors { get; set; }
    
    /// <summary>
    /// Relevance score (0-1, higher is more relevant)
    /// </summary>
    public float RelevanceScore { get; set; }
    
    /// <summary>
    /// Excerpt from the paper relevant to the query
    /// </summary>
    public string Excerpt { get; set; } = string.Empty;
}
