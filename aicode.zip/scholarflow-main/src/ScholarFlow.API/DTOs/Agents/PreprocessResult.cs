namespace ScholarFlow.API.DTOs.Agents;

public class PreprocessResult
{
    public string RawText { get; set; } = string.Empty;
    public string DetectedLanguage { get; set; } = string.Empty;
    public bool IsScanned { get; set; }
    public int PageCount { get; set; }
}
