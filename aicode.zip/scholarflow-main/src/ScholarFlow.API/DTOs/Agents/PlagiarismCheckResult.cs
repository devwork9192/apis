namespace ScholarFlow.API.DTOs.Agents;

/// <summary>
/// Result of plagiarism detection check
/// </summary>
public class PlagiarismCheckResult
{
    /// <summary>
    /// Overall plagiarism score (0-1, where 1 is highest similarity)
    /// </summary>
    public double PlagiarismScore { get; set; }
    
    /// <summary>
    /// Whether the score exceeds the configured threshold
    /// </summary>
    public bool IsAboveThreshold { get; set; }
    
    /// <summary>
    /// List of similar submissions found
    /// </summary>
    public List<SimilarSubmission> SimilarSubmissions { get; set; } = new();
    
    /// <summary>
    /// Additional details about the check
    /// </summary>
    public string Details { get; set; } = string.Empty;
    
    /// <summary>
    /// Whether the check was successful
    /// </summary>
    public bool CheckSuccessful { get; set; }
    
    /// <summary>
    /// Error message if check failed
    /// </summary>
    public string? ErrorMessage { get; set; }
}

/// <summary>
/// Information about a similar submission
/// </summary>
public class SimilarSubmission
{
    public Guid SubmissionId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Authors { get; set; } = string.Empty;
    public double SimilarityScore { get; set; }
    public DateTime SubmittedAt { get; set; }
}
