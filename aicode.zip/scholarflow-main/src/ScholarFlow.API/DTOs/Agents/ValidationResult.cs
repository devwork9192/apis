namespace ScholarFlow.API.DTOs.Agents;

/// <summary>
/// Result of validation process
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Warnings { get; set; } = new();
    public List<string> Errors { get; set; } = new();
    public bool RequiresHumanReview { get; set; }
    public string? ErrorMessage { get; set; }
    
    // Validation details
    public bool HasTitle { get; set; }
    public bool HasAuthors { get; set; }
    public bool HasAbstract { get; set; }
    public bool PageCountValid { get; set; }
    public bool ContainsRequiredSections { get; set; }
    
    // Quality scores (0-1)
    public double? PlagiarismScore { get; set; }
    public double? ToxicityScore { get; set; }
    public double? QualityScore { get; set; }
}
