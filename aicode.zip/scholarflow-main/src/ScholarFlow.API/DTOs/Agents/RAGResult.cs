namespace ScholarFlow.API.DTOs.Agents;

/// <summary>
/// Result of RAG (Retrieval-Augmented Generation) processing
/// </summary>
public class RAGResult
{
    /// <summary>
    /// Whether the document was successfully stored in the vector database
    /// </summary>
    public bool StoredSuccessfully { get; set; }
    
    /// <summary>
    /// Number of similar documents found (for verification/testing)
    /// </summary>
    public int RelatedDocumentsCount { get; set; }
    
    /// <summary>
    /// IDs of the most similar documents
    /// </summary>
    public List<Guid> RelatedSubmissionIds { get; set; } = new();
    
    /// <summary>
    /// Error message if storage failed
    /// </summary>
    public string? ErrorMessage { get; set; }
}
