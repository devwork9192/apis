namespace ScholarFlow.API.DTOs.Agents;

/// <summary>
/// Result of content safety/toxicity analysis
/// </summary>
public class ContentSafetyResult
{
    /// <summary>
    /// Overall toxicity score (0-1, where 1 is highest toxicity)
    /// </summary>
    public double ToxicityScore { get; set; }
    
    /// <summary>
    /// Whether the score exceeds the configured threshold
    /// </summary>
    public bool IsAboveThreshold { get; set; }
    
    /// <summary>
    /// Hate speech severity (0-1)
    /// </summary>
    public double HateSeverity { get; set; }
    
    /// <summary>
    /// Sexual content severity (0-1)
    /// </summary>
    public double SexualSeverity { get; set; }
    
    /// <summary>
    /// Violence content severity (0-1)
    /// </summary>
    public double ViolenceSeverity { get; set; }
    
    /// <summary>
    /// Self-harm content severity (0-1)
    /// </summary>
    public double SelfHarmSeverity { get; set; }
    
    /// <summary>
    /// Categories that were flagged
    /// </summary>
    public List<string> FlaggedCategories { get; set; } = new();
    
    /// <summary>
    /// Additional details about the analysis
    /// </summary>
    public string Details { get; set; } = string.Empty;
    
    /// <summary>
    /// Whether the check was successful
    /// </summary>
    public bool CheckSuccessful { get; set; }
    
    /// <summary>
    /// Error message if check failed
    /// </summary>
    public string? ErrorMessage { get; set; }
}
