namespace ScholarFlow.API.DTOs.Agents;

public class ExtractionResult
{
    public string? Title { get; set; }
    public string? Authors { get; set; }
    public string? Affiliations { get; set; }
    public string? Abstract { get; set; }
    public string? Keywords { get; set; }
    public int? PublicationYear { get; set; }
    public string? Journal { get; set; }
    public string? References { get; set; }
    public bool ExtractionSuccessful { get; set; }
    public string? ErrorMessage { get; set; }
}
