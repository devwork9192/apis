namespace ScholarFlow.API.DTOs.Agents;

/// <summary>
/// Result of summary generation process
/// </summary>
public class SummaryResult
{
    public string? Summary { get; set; }
    public bool SummarySuccessful { get; set; }
    public string? ErrorMessage { get; set; }
    public int SummaryWordCount { get; set; }
}
