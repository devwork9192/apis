namespace ScholarFlow.API.DTOs.Agents;

/// <summary>
/// Result of file ingestion by IngestionAgent
/// </summary>
public class IngestionResult
{
    public bool Success { get; set; }
    public Guid SubmissionId { get; set; }
    public string? ErrorMessage { get; set; }
    public string? FilePath { get; set; }
    public string FileName { get; set; } = string.Empty;
    public long FileSizeBytes { get; set; }
    public int PageCount { get; set; }
    public string? RawText { get; set; }
}
