namespace ScholarFlow.API.DTOs.Health;

public class ComponentHealth
{
    public string Status { get; set; } = string.Empty;
    public string? Message { get; set; }
    public long? ResponseTimeMs { get; set; }
}
