namespace ScholarFlow.API.DTOs.Health;

public class HealthCheckResponse
{
    public string Status { get; set; } = string.Empty;
    public Dictionary<string, ComponentHealth> Components { get; set; } = new();
    public DateTime Timestamp { get; set; }
}
