using ScholarFlow.API.Models;

namespace ScholarFlow.API.DTOs.HumanReview;

/// <summary>
/// Response after review action
/// </summary>
public class ReviewResponse
{
    public Guid SubmissionId { get; set; }
    public SubmissionStatus Status { get; set; }
    public string Message { get; set; } = string.Empty;
    public DateTime ReviewedAt { get; set; }
    public string ReviewedBy { get; set; } = string.Empty;
}

/// <summary>
/// Summary for a submission requiring review
/// </summary>
public class ReviewSummaryResponse
{
    public Guid SubmissionId { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string? Title { get; set; }
    public string? Authors { get; set; }
    public DateTime UploadedAt { get; set; }
    public string UploadedBy { get; set; } = string.Empty;
    
    // Validation Issues
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    
    // Priority indicator for review queue
    // "High" = Has errors or 5+ warnings (needs immediate attention)
    // "Normal" = Clean submission (routine approval)
    public string ReviewPriority { get; set; } = "Normal";
    
    // Risk Scores
    public double? PlagiarismScore { get; set; }
    public double? ToxicityScore { get; set; }
    
    // Review Status
    public bool RequiresHumanReview { get; set; }
    public string? RejectionReason { get; set; }
    public string? ReviewedBy { get; set; }
    public DateTime? ReviewedAt { get; set; }
    
    // Additional Context
    public int PageCount { get; set; }
    public string? DetectedLanguage { get; set; }
    public bool WasTranslated { get; set; }
}
