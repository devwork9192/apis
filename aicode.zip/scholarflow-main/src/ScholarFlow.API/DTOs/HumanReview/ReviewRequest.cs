using System.ComponentModel.DataAnnotations;

namespace ScholarFlow.API.DTOs.HumanReview;

/// <summary>
/// Request to approve a submission
/// </summary>
public class ApproveRequest
{
    /// <summary>
    /// Admin notes/comments for approval
    /// </summary>
    public string? Notes { get; set; }
    
    /// <summary>
    /// Name of the reviewer
    /// </summary>
    [Required]
    public string ReviewedBy { get; set; } = string.Empty;
}

/// <summary>
/// Request to reject a submission
/// </summary>
public class RejectRequest
{
    /// <summary>
    /// Reason for rejection (required)
    /// </summary>
    [Required]
    [MinLength(10)]
    public string RejectionReason { get; set; } = string.Empty;
    
    /// <summary>
    /// Name of the reviewer
    /// </summary>
    [Required]
    public string ReviewedBy { get; set; } = string.Empty;
}

/// <summary>
/// Request to override validation findings
/// </summary>
public class OverrideRequest
{
    /// <summary>
    /// Override plagiarism score (0-1)
    /// </summary>
    public double? OverridePlagiarismScore { get; set; }
    
    /// <summary>
    /// Override toxicity score (0-1)
    /// </summary>
    public double? OverrideToxicityScore { get; set; }
    
    /// <summary>
    /// Mark as valid despite validation errors
    /// </summary>
    public bool? ApproveAnyway { get; set; }
    
    /// <summary>
    /// Reason for override (required)
    /// </summary>
    [Required]
    [MinLength(10)]
    public string OverrideReason { get; set; } = string.Empty;
    
    /// <summary>
    /// Name of the reviewer
    /// </summary>
    [Required]
    public string ReviewedBy { get; set; } = string.Empty;
}
