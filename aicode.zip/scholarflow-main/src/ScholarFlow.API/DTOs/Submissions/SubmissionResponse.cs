namespace ScholarFlow.API.DTOs.Submissions;

public class SubmissionResponse
{
    public Guid Id { get; set; }
    public string Status { get; set; } = string.Empty;
    public string Stage { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}
