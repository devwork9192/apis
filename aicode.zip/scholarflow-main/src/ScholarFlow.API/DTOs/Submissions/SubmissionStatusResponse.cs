namespace ScholarFlow.API.DTOs.Submissions;

public class SubmissionStatusResponse
{
    public Guid Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string CurrentStage { get; set; } = string.Empty;
    public string? DetectedLanguage { get; set; }
    public int PageCount { get; set; }
    public bool WasTranslated { get; set; }
    
    // Extraction fields
    public string? Title { get; set; }
    public string? Authors { get; set; }
    public string? Affiliations { get; set; }
    public string? Abstract { get; set; }
    public string? Keywords { get; set; }
    
    // Validation results
    public string? ValidationWarnings { get; set; }
    
    // Summary
    public string? Summary { get; set; }
    
    public string? ErrorMessage { get; set; }
    public DateTime UploadedAt { get; set; }
    public DateTime? ProcessedAt { get; set; }
}
