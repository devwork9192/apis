namespace ScholarFlow.API.DTOs.Submissions;

/// <summary>
/// Response DTO for listing submissions (dashboard view)
/// </summary>
public class SubmissionListResponse
{
    public Guid Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime UploadedAt { get; set; }
    public int PageCount { get; set; }
    public string? DetectedLanguage { get; set; }
    public string? ErrorMessage { get; set; }
    public string UploadedBy { get; set; } = string.Empty;
}
