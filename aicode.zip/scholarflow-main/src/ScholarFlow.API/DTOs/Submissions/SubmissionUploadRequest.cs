namespace ScholarFlow.API.DTOs.Submissions;

public class SubmissionUploadRequest
{
    public IFormFile File { get; set; } = null!;
    public string? UploadedBy { get; set; }
}
