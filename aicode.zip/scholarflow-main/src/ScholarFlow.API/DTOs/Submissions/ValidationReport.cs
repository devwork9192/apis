namespace ScholarFlow.API.DTOs.Submissions;

/// <summary>
/// Comprehensive validation report for a submission
/// </summary>
public class ValidationReport
{
    public Guid SubmissionId { get; set; }
    public DateTime GeneratedAt { get; set; }
    public string OverallStatus { get; set; } = string.Empty; // Pass, Fail, Review
    public string Summary { get; set; } = string.Empty;
    
    // Validation sections
    public MetadataValidationSection MetadataValidation { get; set; } = new();
    public ContentValidationSection ContentValidation { get; set; } = new();
    public QualityChecksSection QualityChecks { get; set; } = new();
    public PlagiarismCheckSection PlagiarismCheck { get; set; } = new();
    public ToxicityCheckSection ToxicityCheck { get; set; } = new();
    
    // Actionable items
    public List<string> Recommendations { get; set; } = new();
    public bool RequiresHumanReview { get; set; }
}

public class MetadataValidationSection
{
    public string Status { get; set; } = string.Empty;
    public bool HasTitle { get; set; }
    public bool HasAuthors { get; set; }
    public bool HasAbstract { get; set; }
    public List<string> Issues { get; set; } = new();
}

public class ContentValidationSection
{
    public string Status { get; set; } = string.Empty;
    public bool PageCountValid { get; set; }
    public int PageCount { get; set; }
    public bool ContainsRequiredSections { get; set; }
    public List<string> FoundSections { get; set; } = new();
    public List<string> MissingSections { get; set; } = new();
    public List<string> Issues { get; set; } = new();
}

public class QualityChecksSection
{
    public string Status { get; set; } = string.Empty;
    public double? QualityScore { get; set; }
    public int WordCount { get; set; }
    public List<string> Issues { get; set; } = new();
}

public class PlagiarismCheckSection
{
    public string Status { get; set; } = string.Empty;
    public double? Score { get; set; }
    public bool Checked { get; set; }
    public bool IsAboveThreshold { get; set; }
    public int SimilarSubmissionsFound { get; set; }
    public List<string> Issues { get; set; } = new();
}

public class ToxicityCheckSection
{
    public string Status { get; set; } = string.Empty;
    public double? Score { get; set; }
    public bool Checked { get; set; }
    public bool IsAboveThreshold { get; set; }
    public List<string> FlaggedCategories { get; set; } = new();
    public List<string> Issues { get; set; } = new();
}
