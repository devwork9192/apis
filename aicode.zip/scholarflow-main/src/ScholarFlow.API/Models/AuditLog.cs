using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using ScholarFlow.API.Common;

namespace ScholarFlow.API.Models;

public class AuditLog
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();
    
    public Guid SubmissionId { get; set; }
    
    [JsonIgnore] // Prevent circular reference when serializing Submission.AuditLogs
    public Submission? Submission { get; set; }
    
    public string Action { get; set; } = string.Empty;
    public string? Details { get; set; }
    public string PerformedBy { get; set; } = AppConstants.Users.System;
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    
    // For tracking agent actions
    public string? AgentName { get; set; }
    public ProcessingStage? Stage { get; set; }
}
