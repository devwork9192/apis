using System.ComponentModel.DataAnnotations;
using ScholarFlow.API.Common;

namespace ScholarFlow.API.Models;

public class Submission
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();
    
    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public long FileSizeBytes { get; set; }
    public string? Description { get; set; }  // User-provided description
    
    public SubmissionStatus Status { get; set; } = SubmissionStatus.Uploaded;
    public ProcessingStage CurrentStage { get; set; } = ProcessingStage.Upload;
    
    // Preprocessing
    public string? RawText { get; set; }
    public string? DetectedLanguage { get; set; }
    public bool IsScanned { get; set; }
    public int PageCount { get; set; }
    
    // Translation
    public string? OriginalText { get; set; }  // Stored if translated
    public string? TranslatedText { get; set; }  // English version
    public bool WasTranslated { get; set; }
    
    // Extraction
    public string? Title { get; set; }
    public string? Authors { get; set; }
    public string? Affiliations { get; set; }
    public string? Abstract { get; set; }
    public string? Keywords { get; set; }
    public  int? PublicationYear { get; set; }
    public string? Journal { get; set; }
    
    // Validation
    public bool IsValid { get; set; } = false;
    public string? ValidationErrors { get; set; }  // JSON or newline-separated errors
    public string? ValidationWarnings { get; set; }  // JSON or newline-separated warnings
    public double? PlagiarismScore { get; set; }  // 0-1 scale, null if not checked
    public double? ToxicityScore { get; set; }  // 0-1 scale, null if not checked
    public bool? RequiresHumanReview { get; set; }  // Determined by validation rules
    
    // Summary
    public string? Summary { get; set; }
    
    // Human Review (Admin)
    public string? RejectionReason { get; set; }
    public string? ReviewedBy { get; set; }
    public DateTime? ReviewedAt { get; set; }
    
    // Metadata
    public string? ErrorMessage { get; set; }
    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ProcessedAt { get; set; }
    public string UploadedBy { get; set; } = AppConstants.Users.System;
    
    // Navigation properties
    public List<AuditLog> AuditLogs { get; set; } = new();
}
