namespace ScholarFlow.API.Models;

public enum SubmissionStatus
{
    Uploaded,
    Preprocessing,
    LanguageDetected,
    Translating,
    Translated,
    Extracting,
    Extracted,
    Validating,
    Validated,
    Summarizing,
    Summarized,
    PendingReview,
    Approved,
    Rejected,
    Failed
}

public enum ProcessingStage
{
    Upload,
    Preprocess,
    Translation,
    Extraction,
    Validation,
    Summary,
    HumanReview,
    RAG,
    Completed
}
