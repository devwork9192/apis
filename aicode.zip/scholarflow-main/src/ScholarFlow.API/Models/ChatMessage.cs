using System.ComponentModel.DataAnnotations;

namespace ScholarFlow.API.Models;

/// <summary>
/// Represents a chat message in the Q&A conversational interface
/// </summary>
public class ChatMessage
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();
    
    /// <summary>
    /// Optional: ID of the submission this chat is about
    /// Null for general questions about the knowledge base
    /// </summary>
    public Guid? SubmissionId { get; set; }
    
    /// <summary>
    /// Role of the message sender (user or assistant)
    /// </summary>
    public string Role { get; set; } = string.Empty; // "user" or "assistant"
    
    /// <summary>
    /// The message content
    /// </summary>
    public string Content { get; set; } = string.Empty;
    
    /// <summary>
    /// Language of the message (for multilingual support)
    /// </summary>
    public string? Language { get; set; }
    
    /// <summary>
    /// Timestamp of the message
    /// </summary>
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    
    /// <summary>
    /// User who sent the message
    /// </summary>
    public string SentBy { get; set; } = "anonymous";
    
    /// <summary>
    /// Reference IDs of submissions cited in the response (JSON array)
    /// </summary>
    public string? CitedSubmissions { get; set; }
    
    /// <summary>
    /// Navigation property
    /// </summary>
    public Submission? Submission { get; set; }
}
