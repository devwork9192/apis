using Microsoft.SemanticKernel;

namespace ScholarFlow.API.Filters;

/// <summary>
/// Filter for logging function invocations in Semantic Kernel
/// </summary>
public class LoggingFilter : IFunctionInvocationFilter
{
    private readonly ILogger<LoggingFilter> _logger;

    public LoggingFilter(ILogger<LoggingFilter> logger)
    {
        _logger = logger;
    }

    public async Task OnFunctionInvocationAsync(FunctionInvocationContext context, Func<FunctionInvocationContext, Task> next)
    {
        var functionName = $"{context.Function.PluginName}.{context.Function.Name}";
        
        _logger.LogInformation(
            "[SK Function Invoking] {FunctionName} with arguments: {Arguments}",
            functionName,
            string.Join(", ", context.Arguments.Select(a => $"{a.Key}={TruncateValue(a.Value)}")));

        var startTime = DateTime.UtcNow;

        try
        {
            await next(context);

            var duration = DateTime.UtcNow - startTime;
            
            _logger.LogInformation(
                "[SK Function Invoked] {FunctionName} completed in {Duration}ms. Result length: {ResultLength}",
                functionName,
                duration.TotalMilliseconds,
                context.Result?.ToString()?.Length ?? 0);
        }
        catch (Exception ex)
        {
            var duration = DateTime.UtcNow - startTime;
            
            _logger.LogError(ex,
                "[SK Function Failed] {FunctionName} failed after {Duration}ms",
                functionName,
                duration.TotalMilliseconds);
            
            throw;
        }
    }

    private static string TruncateValue(object? value)
    {
        if (value == null) return "null";
        
        var stringValue = value.ToString() ?? string.Empty;
        return stringValue.Length > 100 
            ? stringValue.Substring(0, 100) + "..." 
            : stringValue;
    }
}
