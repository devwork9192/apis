using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ScholarFlow.API.Common;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Controllers;

[Authorize(Roles = "Author,Reviewer")]
[ApiController]
[Route("api/[controller]")]
public class ProcessController : ControllerBase
{
    private readonly IProcessService _processService;
    private readonly ILogger<ProcessController> _logger;

    public ProcessController(
        IProcessService processService,
        ILogger<ProcessController> logger)
    {
        _processService = processService;
        _logger = logger;
    }

    /// <summary>
    /// Process a research paper submission - ingests file and runs complete processing pipeline
    /// </summary>
    /// <param name="file">PDF file to process</param>
    /// <param name="uploadedBy">Username of person uploading (defaults to System)</param>
    /// <param name="title">Optional title for the submission</param>
    /// <param name="description">Optional description for the submission</param>
    /// <returns>Submission response with ID, status, and processing stage</returns>
    [HttpPost]
    [ProducesResponseType(typeof(SubmissionResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<SubmissionResponse>> ProcessSubmission(
        [FromForm] IFormFile file,
        [FromForm] string? uploadedBy = AppConstants.Users.System,
        [FromForm] string? title = null,
        [FromForm] string? description = null)
    {
        try
        {
            _logger.LogInformation("[PROCESS-CONTROLLER] Received process request: {FileName}", file?.FileName);

            if (file == null)
            {
                return BadRequest(new { error = AppConstants.Messages.NoFileProvided });
            }

            var result = await _processService.ProcessSubmissionAsync(file, uploadedBy ?? AppConstants.Users.System, title, description);

            _logger.LogInformation("[PROCESS-CONTROLLER] Process completed successfully: {SubmissionId}", result.Id);

            return Ok(result);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "[PROCESS-CONTROLLER] Invalid submission");
            return BadRequest(new { error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "[PROCESS-CONTROLLER] Processing failed");
            return StatusCode(StatusCodes.Status500InternalServerError, new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[PROCESS-CONTROLLER] Unexpected error processing submission");
            return StatusCode(StatusCodes.Status500InternalServerError, 
                new { error = "An error occurred while processing the submission" });
        }
    }
}
