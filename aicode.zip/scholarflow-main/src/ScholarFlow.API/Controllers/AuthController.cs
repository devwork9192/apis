using Microsoft.AspNetCore.Mvc;
using ScholarFlow.API.DTOs.Auth;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly ILogger<AuthController> _logger;

    public AuthController(IAuthService authService, ILogger<AuthController> logger)
    {
        _authService = authService;
        _logger = logger;
    }

    /// <summary>
    /// Authenticate user and obtain JWT token
    /// </summary>
    /// <param name="request">Login credentials</param>
    /// <returns>JWT token and user information</returns>
    [HttpPost("login")]
    [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginRequest request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var response = await _authService.AuthenticateAsync(request.Username, request.Password);

            if (response == null)
            {
                _logger.LogWarning("Failed login attempt for user: {Username}", request.Username);
                return Unauthorized(new { message = "Invalid username or password" });
            }

            _logger.LogInformation("User {Username} logged in successfully", request.Username);
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during login for user: {Username}", request.Username);
            return StatusCode(500, new { message = "An error occurred during authentication" });
        }
    }

    /// <summary>
    /// Validate if user credentials are correct (for testing purposes)
    /// </summary>
    /// <param name="request">Login credentials</param>
    /// <returns>Validation result</returns>
    [HttpPost("validate")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public IActionResult ValidateCredentials([FromBody] LoginRequest request)
    {
        try
        {
            var isValid = _authService.ValidateCredentials(request.Username, request.Password);

            if (!isValid)
            {
                return Unauthorized(new { message = "Invalid credentials" });
            }

            return Ok(new { message = "Credentials are valid" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validating credentials");
            return StatusCode(500, new { message = "An error occurred during validation" });
        }
    }
}
