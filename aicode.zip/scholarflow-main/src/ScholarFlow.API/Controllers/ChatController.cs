using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ScholarFlow.API.DTOs.Chat;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Controllers;

[Authorize(Roles = "Author,Reviewer")]
[ApiController]
[Route("api/[controller]")]
public class ChatController : ControllerBase
{
    private readonly IChatService _chatService;
    private readonly ILogger<ChatController> _logger;

    public ChatController(IChatService chatService, ILogger<ChatController> logger)
    {
        _chatService = chatService;
        _logger = logger;
    }

    /// <summary>
    /// Ask a question about research papers (searches all papers or a specific one)
    /// </summary>
    /// <param name="request">Chat request with query and options</param>
    /// <returns>Answer with sources and citations</returns>
    [HttpPost]
    [ProducesResponseType(typeof(ChatResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ChatResponse>> AskQuestion([FromBody] ChatRequest request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var response = await _chatService.AskQuestionAsync(request);
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing chat request");
            return StatusCode(500, new { error = "Failed to process question", details = ex.Message });
        }
    }

    /// <summary>
    /// Ask a question about a specific research paper
    /// </summary>
    /// <param name="submissionId">The submission ID to ask about</param>
    /// <param name="request">Chat request with query</param>
    /// <returns>Answer about the specific paper</returns>
    [HttpPost("{submissionId}")]
    [ProducesResponseType(typeof(ChatResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ChatResponse>> AskAboutSubmission(Guid submissionId, [FromBody] ChatRequest request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Override SubmissionId with path parameter
            request.SubmissionId = submissionId;

            var response = await _chatService.AskQuestionAsync(request);
            
            if (response.Sources.Count == 0 && response.Answer.Contains("not found"))
            {
                return NotFound(new { error = $"Submission {submissionId} not found" });
            }

            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing chat request for submission: {SubmissionId}", submissionId);
            return StatusCode(500, new { error = "Failed to process question", details = ex.Message });
        }
    }

    /// <summary>
    /// Get chat history for a specific submission
    /// </summary>
    /// <param name="submissionId">The submission ID</param>
    /// <returns>List of chat messages</returns>
    [HttpGet("{submissionId}/history")]
    [ProducesResponseType(typeof(ChatHistoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ChatHistoryResponse>> GetChatHistory(Guid submissionId)
    {
        try
        {
            var history = await _chatService.GetChatHistoryAsync(submissionId);
            return Ok(history);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving chat history for submission: {SubmissionId}", submissionId);
            return StatusCode(500, new { error = "Failed to retrieve chat history", details = ex.Message });
        }
    }

    /// <summary>
    /// Delete chat history for a specific submission
    /// </summary>
    /// <param name="submissionId">The submission ID</param>
    /// <returns>Success confirmation</returns>
    [HttpDelete("{submissionId}/history")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> DeleteChatHistory(Guid submissionId)
    {
        try
        {
            await _chatService.DeleteChatHistoryAsync(submissionId);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting chat history for submission: {SubmissionId}", submissionId);
            return StatusCode(500, new { error = "Failed to delete chat history", details = ex.Message });
        }
    }

    /// <summary>
    /// Get chat history for general questions (not tied to specific submission)
    /// </summary>
    /// <returns>List of general chat messages</returns>
    [HttpGet("history")]
    [ProducesResponseType(typeof(ChatHistoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ChatHistoryResponse>> GetGeneralChatHistory()
    {
        try
        {
            // Use Guid.Empty to represent general/global chat not tied to a submission
            var history = await _chatService.GetChatHistoryAsync(Guid.Empty);
            return Ok(history);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving general chat history");
            return StatusCode(500, new { error = "Failed to retrieve chat history", details = ex.Message });
        }
    }

    /// <summary>
    /// Delete general chat history (not tied to specific submission)
    /// </summary>
    /// <returns>Success confirmation</returns>
    [HttpDelete("history")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> DeleteGeneralChatHistory()
    {
        try
        {
            await _chatService.DeleteChatHistoryAsync(Guid.Empty);
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting general chat history");
            return StatusCode(500, new { error = "Failed to delete chat history", details = ex.Message });
        }
    }
}
