using Microsoft.AspNetCore.Mvc;
using ScholarFlow.API.Common;
using ScholarFlow.API.DTOs.Health;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HealthController : ControllerBase
{
    private readonly IHealthService _healthService;
    private readonly ILogger<HealthController> _logger;

    public HealthController(
        IHealthService healthService,
        ILogger<HealthController> logger)
    {
        _healthService = healthService;
        _logger = logger;
    }

    /// <summary>
    /// Checks the health of the API and its dependencies (Database and AI service)
    /// </summary>
    /// <returns>Health status of all components</returns>
    [HttpGet]
    [ProducesResponseType(typeof(HealthCheckResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(HealthCheckResponse), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<HealthCheckResponse>> GetHealth()
    {
        try
        {
            var response = await _healthService.CheckHealthAsync();

            var statusCode = response.Status == AppConstants.Status.Healthy 
                ? StatusCodes.Status200OK 
                : StatusCodes.Status503ServiceUnavailable;

            return StatusCode(statusCode, response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error performing health check");
            return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new HealthCheckResponse
            {
                Status = AppConstants.Status.Unhealthy,
                Timestamp = DateTime.UtcNow,
                Components = new Dictionary<string, ComponentHealth>
                {
                    [AppConstants.HealthComponents.System] = new ComponentHealth
                    {
                        Status = AppConstants.Status.Unhealthy,
                        Message = $"{AppConstants.Messages.HealthCheckFailed}: {ex.Message}"
                    }
                }
            });
        }
    }
}
