using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ScholarFlow.API.Common;
using ScholarFlow.API.DTOs.Submissions;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class SubmissionsController : ControllerBase
{
    private readonly ISubmissionService _submissionService;
    private readonly IReportService _reportService;
    private readonly ILogger<SubmissionsController> _logger;

    public SubmissionsController(
        ISubmissionService submissionService,
        IReportService reportService,
        ILogger<SubmissionsController> logger)
    {
        _submissionService = submissionService;
        _reportService = reportService;
        _logger = logger;
    }

    /// <summary>
    /// Get all submissions (dashboard list)
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<SubmissionListResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<SubmissionListResponse>>> GetAllSubmissions()
    {
        try
        {
            var submissions = await _submissionService.GetAllAsync();
            return Ok(submissions);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting all submissions");
            return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = "An error occurred while retrieving submissions" });
        }
    }

    /// <summary>
    /// Get submission status
    /// </summary>
    [HttpGet("{id}/status")]
    [ProducesResponseType(typeof(SubmissionStatusResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<SubmissionStatusResponse>> GetSubmissionStatus(Guid id)
    {
        try
        {
            var status = await _submissionService.GetStatusAsync(id);

            if (status == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            return Ok(status);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting submission status: {SubmissionId}", id);
            return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = AppConstants.Messages.ErrorRetrievingSubmissionStatus });
        }
    }

    /// <summary>
    /// Get full submission details
    /// </summary>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(Submission), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Submission>> GetSubmission(Guid id)
    {
        try
        {
            var submission = await _submissionService.GetByIdAsync(id);

            if (submission == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            return Ok(submission);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting submission: {SubmissionId}", id);
            return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = AppConstants.Messages.ErrorRetrievingSubmission });
        }
    }

    /// <summary>
    /// Get audit log for a submission (activity timeline)
    /// </summary>
    [HttpGet("{id}/audit")]
    [ProducesResponseType(typeof(List<AuditLog>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<List<AuditLog>>> GetSubmissionAudit(Guid id)
    {
        try
        {
            // First check if submission exists
            var submission = await _submissionService.GetByIdAsync(id);
            if (submission == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            var auditLogs = await _submissionService.GetAuditLogsAsync(id);
            return Ok(auditLogs);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting audit logs for submission: {SubmissionId}", id);
            return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = "An error occurred while retrieving audit logs" });
        }
    }

    /// <summary>
    /// Get validation report for a submission (JSON format)
    /// </summary>
    [HttpGet("{id}/validation-report")]
    [ProducesResponseType(typeof(ValidationReport), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ValidationReport>> GetValidationReport(Guid id)
    {
        try
        {
            // First check if submission exists
            var submission = await _submissionService.GetByIdAsync(id);
            if (submission == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            var report = await _reportService.GenerateValidationReportAsync(id);
            if (report == null)
            {
                return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = "Failed to generate validation report" });
            }

            return Ok(report);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating validation report for submission: {SubmissionId}", id);
            return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = "An error occurred while generating validation report" });
        }
    }

    /// <summary>
    /// Get validation report for a submission (HTML format)
    /// </summary>
    [HttpGet("{id}/validation-report/html")]
    [ProducesResponseType(typeof(string), StatusCodes.Status200OK, "text/html")]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetValidationReportHtml(Guid id)
    {
        try
        {
            // First check if submission exists
            var submission = await _submissionService.GetByIdAsync(id);
            if (submission == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            var html = await _reportService.GenerateValidationReportHtmlAsync(id);
            if (html == null)
            {
                return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = "Failed to generate HTML validation report" });
            }

            return Content(html, "text/html");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating HTML validation report for submission: {SubmissionId}", id);
            return StatusCode(AppConstants.HttpStatusCodes.InternalServerError, new { error = "An error occurred while generating HTML validation report" });
        }
    }
}
