using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ScholarFlow.API.Common;
using ScholarFlow.API.DTOs.HumanReview;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Controllers;

/// <summary>
/// Controller for human review workflow operations
/// </summary>
[Authorize(Roles = "Reviewer")]
[ApiController]
[Route("api/review")]
public class HumanReviewController : ControllerBase
{
    private readonly IHumanReviewService _reviewService;
    private readonly ILogger<HumanReviewController> _logger;

    public HumanReviewController(
        IHumanReviewService reviewService,
        ILogger<HumanReviewController> logger)
    {
        _reviewService = reviewService;
        _logger = logger;
    }

    /// <summary>
    /// Get all submissions pending human review
    /// </summary>
    [HttpGet("pending")]
    [ProducesResponseType(typeof(List<ReviewSummaryResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<List<ReviewSummaryResponse>>> GetPendingReviews()
    {
        try
        {
            var reviews = await _reviewService.GetPendingReviewsAsync();
            return Ok(reviews);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching pending reviews");
            return StatusCode(
                AppConstants.HttpStatusCodes.InternalServerError, 
                new { error = "An error occurred while fetching pending reviews" }
            );
        }
    }

    /// <summary>
    /// Get review summary for a specific submission
    /// </summary>
    [HttpGet("{id}/summary")]
    [ProducesResponseType(typeof(ReviewSummaryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReviewSummaryResponse>> GetReviewSummary(Guid id)
    {
        try
        {
            var summary = await _reviewService.GetReviewSummaryAsync(id);
            
            if (summary == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            return Ok(summary);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting review summary for submission: {SubmissionId}", id);
            return StatusCode(
                AppConstants.HttpStatusCodes.InternalServerError, 
                new { error = "An error occurred while fetching review summary" }
            );
        }
    }

    /// <summary>
    /// Approve a submission
    /// </summary>
    [HttpPost("{id}/approve")]
    [ProducesResponseType(typeof(ReviewResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ReviewResponse>> ApproveSubmission(
        Guid id, 
        [FromBody] ApproveRequest request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var response = await _reviewService.ApproveSubmissionAsync(id, request);
            
            if (response == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error approving submission: {SubmissionId}", id);
            return StatusCode(
                AppConstants.HttpStatusCodes.InternalServerError, 
                new { error = "An error occurred while approving submission" }
            );
        }
    }

    /// <summary>
    /// Reject a submission
    /// </summary>
    [HttpPost("{id}/reject")]
    [ProducesResponseType(typeof(ReviewResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ReviewResponse>> RejectSubmission(
        Guid id, 
        [FromBody] RejectRequest request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var response = await _reviewService.RejectSubmissionAsync(id, request);
            
            if (response == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error rejecting submission: {SubmissionId}", id);
            return StatusCode(
                AppConstants.HttpStatusCodes.InternalServerError, 
                new { error = "An error occurred while rejecting submission" }
            );
        }
    }

    /// <summary>
    /// Override validation findings for a submission
    /// </summary>
    [HttpPost("{id}/override")]
    [ProducesResponseType(typeof(ReviewResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ReviewResponse>> OverrideValidation(
        Guid id, 
        [FromBody] OverrideRequest request)
    {
        try
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Validate override scores are in range 0-1
            if (request.OverridePlagiarismScore.HasValue && 
                (request.OverridePlagiarismScore < 0 || request.OverridePlagiarismScore > 1))
            {
                return BadRequest(new { error = "Plagiarism score must be between 0 and 1" });
            }

            if (request.OverrideToxicityScore.HasValue && 
                (request.OverrideToxicityScore < 0 || request.OverrideToxicityScore > 1))
            {
                return BadRequest(new { error = "Toxicity score must be between 0 and 1" });
            }

            var response = await _reviewService.OverrideValidationAsync(id, request);
            
            if (response == null)
            {
                return NotFound(new { error = AppConstants.Messages.SubmissionNotFound });
            }

            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error overriding validation for submission: {SubmissionId}", id);
            return StatusCode(
                AppConstants.HttpStatusCodes.InternalServerError, 
                new { error = "An error occurred while overriding validation" }
            );
        }
    }
}
