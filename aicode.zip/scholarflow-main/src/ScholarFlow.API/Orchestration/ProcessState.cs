using ScholarFlow.API.Models;

namespace ScholarFlow.API.Orchestration;

/// <summary>
/// Represents the state of the research paper processing workflow
/// </summary>
public class ProcessState
{
    public Guid SubmissionId { get; set; }
    public string RawText { get; set; } = string.Empty;
    public string? DetectedLanguage { get; set; }
    public string? TranslatedText { get; set; }
    public string? ExtractedMetadata { get; set; }
    public bool IsValid { get; set; }
    public string? ValidationResult { get; set; }
    public string? Summary { get; set; }
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = new();
}

/// <summary>
/// Result of a process step execution
/// </summary>
public class StepResult
{
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
    public Dictionary<string, object> Data { get; set; } = new();
}

/// <summary>
/// Context passed to each process step
/// </summary>
public class ProcessContext
{
    public Guid SubmissionId { get; set; }
    public ProcessState State { get; set; } = new();
    public Submission Submission { get; set; } = null!;
}
