using ScholarFlow.API.Models;
using ScholarFlow.API.Orchestration.Steps;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Orchestration;

public interface IProcessOrchestrator
{
    Task<ProcessingResult> ExecuteWorkflowAsync(Submission submission, CancellationToken cancellationToken = default);
}

/// <summary>
/// Orchestrates research paper processing using a structured workflow pattern
/// Implements a process framework approach with discrete, testable steps
/// </summary>
public class ProcessOrchestrator : IProcessOrchestrator
{
    private readonly IServiceProvider _serviceProvider;
    private readonly IAuditService _auditService;
    private readonly ILogger<ProcessOrchestrator> _logger;
    private readonly List<Type> _workflowSteps;

    public ProcessOrchestrator(
        IServiceProvider serviceProvider,
        IAuditService auditService,
        ILogger<ProcessOrchestrator> logger)
    {
        _serviceProvider = serviceProvider;
        _auditService = auditService;
        _logger = logger;

        // Define the workflow pipeline
        _workflowSteps = new List<Type>
        {
            typeof(LanguageDetectionStep),
            typeof(TranslationStep),
            typeof(MetadataExtractionStep),
            typeof(ValidationStep),
            typeof(SummaryGenerationStep),
            typeof(RAGStep)
        };
    }

    /// <summary>
    /// Execute the complete research paper processing workflow
    /// </summary>
    public async Task<ProcessingResult> ExecuteWorkflowAsync(Submission submission, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[WORKFLOW] Starting workflow execution for submission: {SubmissionId}", submission.Id);

        var context = new ProcessContext
        {
            SubmissionId = submission.Id,
            Submission = submission,
            State = new ProcessState
            {
                SubmissionId = submission.Id,
                RawText = submission.RawText ?? string.Empty
            }
        };

        var result = new ProcessingResult { SubmissionId = submission.Id };

        try
        {
            // Log workflow start
            await _auditService.LogActionAsync(
                submission.Id,
                "WorkflowStarted",
                "Process framework workflow initiated",
                agentName: "ProcessOrchestrator",
                stage: ProcessingStage.Preprocess);

            // Execute each step in sequence
            foreach (var stepType in _workflowSteps)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    _logger.LogWarning("[WORKFLOW] Workflow cancelled for submission: {SubmissionId}", submission.Id);
                    result.Success = false;
                    result.ErrorMessage = "Workflow cancelled";
                    return result;
                }

                var step = _serviceProvider.GetService(stepType) as IProcessStep;
                if (step == null)
                {
                    throw new InvalidOperationException($"Failed to resolve process step: {stepType.Name}");
                }

                _logger.LogInformation("[WORKFLOW] Executing step: {StepName}", step.StepName);

                var stepResult = await step.ExecuteAsync(context, cancellationToken);

                if (!stepResult.Success)
                {
                    _logger.LogError("[WORKFLOW] Step {StepName} failed: {Error}", step.StepName, stepResult.ErrorMessage);
                    result.Success = false;
                    result.ErrorMessage = $"{step.StepName} failed: {stepResult.ErrorMessage}";
                    
                    await _auditService.LogActionAsync(
                        submission.Id,
                        "WorkflowFailed",
                        $"Failed at {step.StepName}: {stepResult.ErrorMessage}",
                        agentName: "ProcessOrchestrator",
                        stage: ProcessingStage.Preprocess);
                    
                    return result;
                }

                _logger.LogInformation("[WORKFLOW] Step {StepName} completed successfully", step.StepName);
            }

            // Map final state to result
            result.Success = true;
            result.DetectedLanguage = context.State.DetectedLanguage;
            result.TranslatedText = context.State.TranslatedText;
            result.ExtractedMetadata = context.State.ExtractedMetadata;
            result.IsValid = context.State.IsValid;
            result.ValidationResult = context.State.ValidationResult;
            result.Summary = context.State.Summary;
            result.RAGStored = context.State.Metadata.ContainsKey("RagStored") 
                && (bool)context.State.Metadata["RagStored"];
            result.RelatedDocumentsCount = context.State.Metadata.ContainsKey("RelatedDocumentsCount")
                ? (int)context.State.Metadata["RelatedDocumentsCount"]
                : 0;

            // Log workflow completion
            await _auditService.LogActionAsync(
                submission.Id,
                "WorkflowCompleted",
                "Process framework workflow completed successfully",
                agentName: "ProcessOrchestrator",
                stage: ProcessingStage.RAG);

            _logger.LogInformation("[WORKFLOW] Workflow completed successfully for submission: {SubmissionId}", submission.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[WORKFLOW] Unexpected error in workflow for submission: {SubmissionId}", submission.Id);
            result.Success = false;
            result.ErrorMessage = ex.Message;

            await _auditService.LogActionAsync(
                submission.Id,
                "WorkflowException",
                $"Workflow exception: {ex.Message}",
                agentName: "ProcessOrchestrator",
                stage: ProcessingStage.Preprocess);
        }

        return result;
    }
}

/// <summary>
/// Result of workflow execution
/// </summary>
public class ProcessingResult
{
    public Guid SubmissionId { get; set; }
    public bool Success { get; set; }
    public string? DetectedLanguage { get; set; }
    public bool RAGStored { get; set; }
    public int RelatedDocumentsCount { get; set; }
    public string? TranslatedText { get; set; }
    public string? ExtractedMetadata { get; set; }
    public bool IsValid { get; set; }
    public string? ValidationResult { get; set; }
    public string? Summary { get; set; }
    public string? ErrorMessage { get; set; }
}
