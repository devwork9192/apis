using ScholarFlow.API.Agents;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Orchestration.Steps;

/// <summary>
/// Process step for generating publication-ready summary
/// </summary>
public class SummaryGenerationStep : IProcessStep
{
    private readonly ISummaryAgent _summaryAgent;
    private readonly IAuditService _auditService;
    private readonly ILogger<SummaryGenerationStep> _logger;

    public string StepName => "SummaryGeneration";

    public SummaryGenerationStep(
        ISummaryAgent summaryAgent,
        IAuditService auditService,
        ILogger<SummaryGenerationStep> logger)
    {
        _summaryAgent = summaryAgent;
        _auditService = auditService;
        _logger = logger;
    }

    public async Task<StepResult> ExecuteAsync(ProcessContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("[PROCESS] Executing {StepName} for submission: {SubmissionId}", 
                StepName, context.SubmissionId);

            var summaryResult = await _summaryAgent.GenerateSummaryAsync(context.Submission);
            context.State.Summary = summaryResult.Summary;

            await _auditService.LogActionAsync(
                context.SubmissionId,
                "SummaryGenerated",
                $"Summary created ({summaryResult.SummaryWordCount} words)",
                agentName: "SummaryAgent",
                stage: ProcessingStage.Summary);

            _logger.LogInformation("[PROCESS] {StepName} completed. Words: {WordCount}", 
                StepName, summaryResult.SummaryWordCount);

            return new StepResult
            {
                Success = true,
                Data = new Dictionary<string, object> 
                { 
                    ["Summary"] = summaryResult.Summary ?? string.Empty,
                    ["WordCount"] = summaryResult.SummaryWordCount
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[PROCESS] Error in {StepName}", StepName);
            return new StepResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
