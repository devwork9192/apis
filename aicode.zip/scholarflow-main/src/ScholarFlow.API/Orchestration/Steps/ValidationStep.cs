using ScholarFlow.API.Agents;
using ScholarFlow.API.DTOs.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Orchestration.Steps;

/// <summary>
/// Process step for validating submission completeness
/// </summary>
public class ValidationStep : IProcessStep
{
    private readonly IValidationAgent _validationAgent;
    private readonly IAuditService _auditService;
    private readonly ILogger<ValidationStep> _logger;

    public string StepName => "Validation";

    public ValidationStep(
        IValidationAgent validationAgent,
        IAuditService auditService,
        ILogger<ValidationStep> logger)
    {
        _validationAgent = validationAgent;
        _auditService = auditService;
        _logger = logger;
    }

    public async Task<StepResult> ExecuteAsync(ProcessContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("[PROCESS] Executing {StepName} for submission: {SubmissionId}", 
                StepName, context.SubmissionId);

            var validationResult = await _validationAgent.ValidateAsync(context.Submission);
            
            // Update submission with validation results
            context.Submission.IsValid = validationResult.IsValid;
            context.Submission.PlagiarismScore = validationResult.PlagiarismScore;
            context.Submission.ToxicityScore = validationResult.ToxicityScore;
            context.Submission.RequiresHumanReview = validationResult.RequiresHumanReview;
            
            // Store errors and warnings
            if (validationResult.Errors != null && validationResult.Errors.Any())
            {
                context.Submission.ValidationErrors = string.Join("; ", validationResult.Errors);
            }
            if (validationResult.Warnings != null && validationResult.Warnings.Any())
            {
                context.Submission.ValidationWarnings = string.Join("; ", validationResult.Warnings);
            }
            
            context.State.IsValid = validationResult.IsValid;
            context.State.ValidationResult = validationResult.IsValid 
                ? "Valid" 
                : string.Join("; ", validationResult.Errors ?? new List<string>());

            await _auditService.LogActionAsync(
                context.SubmissionId,
                validationResult.IsValid ? "ValidationPassed" : "ValidationFailed",
                validationResult.IsValid ? "All validation checks passed" : context.State.ValidationResult,
                agentName: "ValidationAgent",
                stage: ProcessingStage.Validation);

            _logger.LogInformation("[PROCESS] {StepName} completed. Valid: {IsValid}, PlagiarismScore: {PlagiarismScore}, ToxicityScore: {ToxicityScore}", 
                StepName, validationResult.IsValid, validationResult.PlagiarismScore, validationResult.ToxicityScore);

            return new StepResult
            {
                Success = true,
                Data = new Dictionary<string, object> 
                { 
                    ["IsValid"] = validationResult.IsValid,
                    ["ValidationResult"] = context.State.ValidationResult ?? "Valid"
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[PROCESS] Error in {StepName}", StepName);
            return new StepResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
