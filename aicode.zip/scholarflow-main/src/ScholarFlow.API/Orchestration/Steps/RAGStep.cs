using ScholarFlow.API.Agents;
using ScholarFlow.API.Services;
using ScholarFlow.API.Models;

namespace ScholarFlow.API.Orchestration.Steps;

/// <summary>
/// Process step for RAG (Retrieval-Augmented Generation) operations
/// Stores document embeddings in vector database for semantic search
/// </summary>
public class RAGStep : IProcessStep
{
    private readonly IRAGAgent _ragAgent;
    private readonly IAuditService _auditService;
    private readonly ILogger<RAGStep> _logger;

    public string StepName => "RAG";

    public RAGStep(
        IRAGAgent ragAgent,
        IAuditService auditService,
        ILogger<RAGStep> logger)
    {
        _ragAgent = ragAgent;
        _auditService = auditService;
        _logger = logger;
    }

    public async Task<StepResult> ExecuteAsync(ProcessContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("[PROCESS] Executing {StepName} for submission: {SubmissionId}", 
                StepName, context.SubmissionId);

            var ragResult = await _ragAgent.StoreDocumentAsync(context.Submission);

            if (!ragResult.StoredSuccessfully)
            {
                _logger.LogWarning("[PROCESS] RAG storage failed: {Error}", ragResult.ErrorMessage);
                
                await _auditService.LogActionAsync(
                    context.SubmissionId,
                    "RAGStorageFailed",
                    $"Failed to store in vector database: {ragResult.ErrorMessage}",
                    agentName: "RAGAgent",
                    stage: ProcessingStage.RAG);

                return new StepResult
                {
                    Success = false,
                    ErrorMessage = ragResult.ErrorMessage
                };
            }

            // Store RAG metadata in context
            context.State.Metadata["RagStored"] = true;
            context.State.Metadata["RelatedDocumentsCount"] = ragResult.RelatedDocumentsCount;
            context.State.Metadata["RelatedSubmissionIds"] = ragResult.RelatedSubmissionIds;

            await _auditService.LogActionAsync(
                context.SubmissionId,
                "RAGStored",
                $"Document stored in vector database. Found {ragResult.RelatedDocumentsCount} related documents.",
                agentName: "RAGAgent",
                stage: ProcessingStage.RAG);

            _logger.LogInformation("[PROCESS] {StepName} completed. Related docs: {Count}", 
                StepName, ragResult.RelatedDocumentsCount);

            return new StepResult
            {
                Success = true,
                Data = new Dictionary<string, object>
                {
                    ["StoredSuccessfully"] = ragResult.StoredSuccessfully,
                    ["RelatedDocumentsCount"] = ragResult.RelatedDocumentsCount,
                    ["RelatedSubmissionIds"] = ragResult.RelatedSubmissionIds
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[PROCESS] Error in {StepName}", StepName);
            
            await _auditService.LogActionAsync(
                context.SubmissionId,
                "RAGException",
                $"RAG step exception: {ex.Message}",
                agentName: "RAGAgent",
                stage: ProcessingStage.RAG);

            return new StepResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
