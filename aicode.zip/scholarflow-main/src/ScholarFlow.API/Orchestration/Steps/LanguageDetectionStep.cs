using ScholarFlow.API.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Orchestration.Steps;

/// <summary>
/// Process step for detecting document language
/// </summary>
public class LanguageDetectionStep : IProcessStep
{
    private readonly IPreprocessAgent _preprocessAgent;
    private readonly IAuditService _auditService;
    private readonly ILogger<LanguageDetectionStep> _logger;

    public string StepName => "LanguageDetection";

    public LanguageDetectionStep(
        IPreprocessAgent preprocessAgent,
        IAuditService auditService,
        ILogger<LanguageDetectionStep> logger)
    {
        _preprocessAgent = preprocessAgent;
        _auditService = auditService;
        _logger = logger;
    }

    public async Task<StepResult> ExecuteAsync(ProcessContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("[PROCESS] Executing {StepName} for submission: {SubmissionId}", 
                StepName, context.SubmissionId);

            var detectedLanguage = await _preprocessAgent.DetectLanguageAsync(context.State.RawText);
            context.State.DetectedLanguage = detectedLanguage;

            await _auditService.LogActionAsync(
                context.SubmissionId,
                "LanguageDetected",
                $"Language: {detectedLanguage}",
                agentName: "PreprocessAgent",
                stage: ProcessingStage.Preprocess);

            _logger.LogInformation("[PROCESS] {StepName} completed. Language: {Language}", 
                StepName, detectedLanguage);

            return new StepResult
            {
                Success = true,
                Data = new Dictionary<string, object> { ["Language"] = detectedLanguage }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[PROCESS] Error in {StepName}", StepName);
            return new StepResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
