using ScholarFlow.API.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Orchestration.Steps;

/// <summary>
/// Process step for translating non-English documents
/// </summary>
public class TranslationStep : IProcessStep
{
    private readonly ITranslationAgent _translationAgent;
    private readonly IAuditService _auditService;
    private readonly ILogger<TranslationStep> _logger;

    public string StepName => "Translation";

    public TranslationStep(
        ITranslationAgent translationAgent,
        IAuditService auditService,
        ILogger<TranslationStep> logger)
    {
        _translationAgent = translationAgent;
        _auditService = auditService;
        _logger = logger;
    }

    public async Task<StepResult> ExecuteAsync(ProcessContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            var detectedLanguage = context.State.DetectedLanguage;
            var textToProcess = context.State.RawText;

            if (!string.IsNullOrWhiteSpace(detectedLanguage) && 
                !detectedLanguage.Equals("English", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogInformation("[PROCESS] Executing {StepName} from {Language} to English", 
                    StepName, detectedLanguage);

                var translatedText = await _translationAgent.TranslateToEnglishAsync(textToProcess, detectedLanguage);
                context.State.TranslatedText = translatedText;

                await _auditService.LogActionAsync(
                    context.SubmissionId,
                    "TranslationCompleted",
                    $"Translated from {detectedLanguage} to English",
                    agentName: "TranslationAgent",
                    stage: ProcessingStage.Translation);

                _logger.LogInformation("[PROCESS] {StepName} completed", StepName);

                return new StepResult
                {
                    Success = true,
                    Data = new Dictionary<string, object> { ["Translated"] = true }
                };
            }
            else
            {
                _logger.LogInformation("[PROCESS] {StepName} skipped - already in English", StepName);
                context.State.TranslatedText = textToProcess;

                await _auditService.LogActionAsync(
                    context.SubmissionId,
                    "TranslationSkipped",
                    "Document already in English",
                    agentName: "TranslationAgent",
                    stage: ProcessingStage.Translation);

                return new StepResult
                {
                    Success = true,
                    Data = new Dictionary<string, object> { ["Translated"] = false }
                };
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[PROCESS] Error in {StepName}", StepName);
            return new StepResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
