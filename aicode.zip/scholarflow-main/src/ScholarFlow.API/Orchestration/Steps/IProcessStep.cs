namespace ScholarFlow.API.Orchestration.Steps;

/// <summary>
/// Base interface for all process steps in the workflow
/// </summary>
public interface IProcessStep
{
    string StepName { get; }
    Task<StepResult> ExecuteAsync(ProcessContext context, CancellationToken cancellationToken = default);
}
