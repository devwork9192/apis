using System.Text.Json;
using ScholarFlow.API.Agents;
using ScholarFlow.API.Models;
using ScholarFlow.API.Services;

namespace ScholarFlow.API.Orchestration.Steps;

/// <summary>
/// Process step for extracting metadata from research paper
/// </summary>
public class MetadataExtractionStep : IProcessStep
{
    private readonly IExtractionAgent _extractionAgent;
    private readonly IAuditService _auditService;
    private readonly ILogger<MetadataExtractionStep> _logger;

    public string StepName => "MetadataExtraction";

    public MetadataExtractionStep(
        IExtractionAgent extractionAgent,
        IAuditService auditService,
        ILogger<MetadataExtractionStep> logger)
    {
        _extractionAgent = extractionAgent;
        _auditService = auditService;
        _logger = logger;
    }

    public async Task<StepResult> ExecuteAsync(ProcessContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            _logger.LogInformation("[PROCESS] Executing {StepName} for submission: {SubmissionId}", 
                StepName, context.SubmissionId);

            var textToProcess = context.State.TranslatedText ?? context.State.RawText;
            var metadata = await _extractionAgent.ExtractMetadataAsync(textToProcess);
            
            context.State.ExtractedMetadata = JsonSerializer.Serialize(metadata);

            // Update submission with extracted metadata
            context.Submission.Title = metadata.Title;
            context.Submission.Authors = metadata.Authors != null ? string.Join(", ", metadata.Authors) : null;
            context.Submission.Abstract = metadata.Abstract;
            context.Submission.Keywords = metadata.Keywords != null ? string.Join(", ", metadata.Keywords) : null;
            context.Submission.PublicationYear = metadata.PublicationYear;
            context.Submission.Journal = metadata.Journal;
            context.Submission.TranslatedText = textToProcess;

            await _auditService.LogActionAsync(
                context.SubmissionId,
                "MetadataExtracted",
                $"Title: {metadata.Title}, Authors: {metadata.Authors}",
                agentName: "ExtractionAgent",
                stage: ProcessingStage.Extraction);

            _logger.LogInformation("[PROCESS] {StepName} completed. Title: {Title}", 
                StepName, metadata.Title);

            return new StepResult
            {
                Success = true,
                Data = new Dictionary<string, object> { ["Title"] = metadata.Title ?? "Unknown" }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[PROCESS] Error in {StepName}", StepName);
            return new StepResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }
}
