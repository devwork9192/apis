# ScholarFlow

**Automated Multilingual Research Submission Processor**

A multi-agent AI system (POC) that automatically processes research paper submissions, validates compliance, and provides RAG-powered Q&A capabilities with a modern web interface.

> 📋 **For detailed project documentation, future enhancements, and capstone submission details, see [CAPSTONE_PROJECT_SUBMISSION.md](CAPSTONE_PROJECT_SUBMISSION.md)**

## Features

### Complete Feature Set
- ✅ PDF upload with drag-and-drop interface
- ✅ Text extraction (including OCR for scanned documents)
- ✅ Automatic language detection
- ✅ Translation to English (supports 100+ languages)
- ✅ Structured metadata extraction (title, authors, affiliations, abstract, keywords)
- ✅ Validation rules (page count, required sections)
- ✅ Plagiarism detection with vector embeddings
- ✅ Content safety checking (toxicity detection)
- ✅ Human-in-the-loop review workflow
- ✅ AI-generated summaries
- ✅ RAG pipeline with in-memory vector store
- ✅ Conversational Q&A with chat history
- ✅ Dark/Light theme UI
- ✅ Role-based access control (Researcher/Reviewer)

## Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                          USER INTERFACE (Browser)                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │   Upload     │  │  Dashboard   │  │   Chat UI    │             │
│  │  (Drag&Drop) │  │  (Tracking)  │  │  (RAG Q&A)   │             │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘             │
└─────────┼──────────────────┼──────────────────┼────────────────────┘
          │                  │                  │
          │    REST API (JWT Authentication)    │
          │                  │                  │
┌─────────▼──────────────────▼──────────────────▼────────────────────┐
│                      ASP.NET Core API                               │
│  ┌────────────────┐  ┌──────────────┐  ┌──────────────┐            │
│  │ProcessController│  │SubmissionCtrl│  │  ChatController│          │
│  └────────┬───────┘  └──────┬───────┘  └──────┬───────┘            │
│           │                  │                  │                    │
│           │                  │                  │                    │
│  ┌────────▼──────────────────▼──────────────────▼────────────────┐ │
│  │              Semantic Kernel Process Framework                  │ │
│  │                (Orchestration Layer - SK Built-in)              │ │
│  │                                                                  │ │
│  │  ProcessOrchestrator coordinates workflow steps:                │ │
│  │                                                                  │ │
│  │  Step 1: LanguageDetectionStep  ──► PreprocessAgent            │ │
│  │  Step 2: TranslationStep         ──► TranslationAgent          │ │
│  │  Step 3: MetadataExtractionStep  ──► ExtractionAgent           │ │
│  │  Step 4: ValidationStep          ──► ValidationAgent            │ │
│  │  Step 5: SummaryGenerationStep   ──► SummaryAgent              │ │
│  │  Step 6: RAGStep                 ──► RAGAgent                   │ │
│  │                                                                  │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│           │                  │                  │                    │
└───────────┼──────────────────┼──────────────────┼────────────────────┘
            │                  │                  │
            │                  │                  │
┌───────────▼──────────────────▼──────────────────▼────────────────────┐
│                        Azure OpenAI Service                           │
│  ┌────────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │   GPT-4o       │  │  Embeddings  │  │  Content     │             │
│  │ (Chat/Extract) │  │  (Vectors)   │  │  Safety      │             │
│  └────────────────┘  └──────────────┘  └──────────────┘             │
└───────────────────────────────────────────────────────────────────────┘
            │                  │                  │
            ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         Data Storage                                 │
│  ┌────────────────┐  ┌──────────────┐  ┌──────────────┐            │
│  │   SQLite       │  │  Vector DB   │  │  File System │            │
│  │ (Submissions)  │  │  (In-Memory) │  │   (PDFs)     │            │
│  └────────────────┘  └──────────────┘  └──────────────┘            │
└─────────────────────────────────────────────────────────────────────┘
```

### Document Processing Flow

```
User Upload (PDF)
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│ 1. INGESTION AGENT                                           │
│    - Validate file (PDF, <50MB)                             │
│    - Save to file system                                     │
│    - Extract raw text (PdfPig)                              │
│    - Create submission record                                │
│    - Status: Uploaded → Preprocessing                        │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────────┐
│ 2. LANGUAGE DETECTION STEP → PreprocessAgent                │
│    - Analyze text with Azure OpenAI                         │
│    - Detect language (ISO 639-1 code)                       │
│    - Confidence scoring                                      │
│    - Status: Language Detected                               │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────────┐
│ 3. TRANSLATION STEP → TranslationAgent                      │
│    - If non-English: Translate to English                   │
│    - Preserve original text                                  │
│    - Azure OpenAI GPT-4o translation                        │
│    - Status: Translated                                      │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────────┐
│ 4. METADATA EXTRACTION STEP → ExtractionAgent               │
│    - Extract: Title, Authors, Affiliations                  │
│    - Extract: Abstract, Keywords, Year, Journal             │
│    - Structured JSON output via Function Calling            │
│    - Status: Extracted                                       │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────────┐
│ 5. VALIDATION STEP → ValidationAgent                        │
│    - Check page count (8-25 pages)                          │
│    - Check required sections                                 │
│    - Plagiarism detection (vector similarity)                │
│    - Content safety (toxicity check)                         │
│    - Generate validation report                              │
│    - Status: Validated / PendingReview                       │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────────┐
│ 6. SUMMARY GENERATION STEP → SummaryAgent                   │
│    - Generate executive summary                              │
│    - Key findings extraction                                 │
│    - Azure OpenAI GPT-4o                                    │
│    - Status: Summarized                                      │
└────────────────────────┬─────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────────┐
│ 7. RAG STEP → RAGAgent                                      │
│    - Generate embeddings (text-embedding-3-large)           │
│    - Store in vector database                                │
│    - Enable semantic search                                  │
│    - Status: Completed                                       │
└──────────────────────────────────────────────────────────────┘
                         │
                         ▼
        ┌────────────────┴────────────────┐
        │                                  │
        ▼                                  ▼
┌────────────────┐              ┌─────────────────┐
│ Human Review   │              │   User Q&A      │
│ (if flagged)   │              │ (Chat with Doc) │
│ Approve/Reject │              │ QAAgent + RAG   │
└────────────────┘              └─────────────────┘
```

### Multi-Agent System

**8 Specialized AI Agents:**

1. **Ingestion Agent** - File handling, validation, and text extraction
2. **Preprocess Agent** - Language detection and document analysis
3. **Translation Agent** - Multilingual translation to English
4. **Extraction Agent** - Structured metadata parsing via function calling
5. **Validation Agent** - Rule checking, plagiarism, and safety validation
6. **Summary Agent** - AI-generated executive summaries
7. **RAG Agent** - Vector embeddings and semantic search indexing
8. **Q&A Agent** - Conversational interface with context-aware responses

### Technology Stack
- **Framework**: ASP.NET Core Web API (.NET 10.0)
- **AI**: Microsoft Semantic Kernel 1.73.0 + Azure OpenAI (GPT-4o, text-embedding-3-large)
- **Orchestration**: Semantic Kernel Process Framework (built-in workflow engine)
- **Frontend**: Vue.js 3 (via CDN) + Tailwind CSS for modern, reactive UI
- **Authentication**: JWT with role-based access control
- **Database**: SQLite with Entity Framework Core
- **Vector Store**: In-memory vector database with cosine similarity for RAG
- **PDF Processing**: PdfPig
- **Testing**: xUnit, FluentAssertions, Moq

### User Interface

**Vue.js 3 Single-Page Application (SPA)**

- **Framework**: Vue.js 3 (via CDN) with reactive data binding and component-based architecture
- **Styling**: Tailwind CSS utility-first framework with custom configuration
- **Authentication**: JWT-based login with Author/Reviewer roles
- **Responsive**: Mobile-first design with Tailwind responsive utilities
- **No Build Step**: Runs directly in browser using Vue global build
- **Features**:
  - 📤 Upload page with drag-and-drop file handling
  - 📊 Dashboard with real-time submission tracking and status badges
  - 📄 Detailed submission view with processing results and metadata
  - 💬 Research Assistant chat interface for RAG-powered Q&A
  - 📋 Review queue for reviewer approval workflow
  - 🎨 Toast notifications for user feedback
  - ⚡ Real-time progress tracking for document processing

## Getting Started

### Prerequisites
- .NET 10.0 SDK
- Azure OpenAI Service account with:
  - GPT-4o deployment (for chat completion)
  - text-embedding-3-large deployment (for embeddings)
- Visual Studio 2022 or VS Code

### Configuration

1. Create `appsettings.local.json` in `src/ScholarFlow.API` folder:

```json
{
  "AzureOpenAI": {
    "Endpoint": "https://your-resource.openai.azure.com/",
    "ApiKey": "your-api-key-here",
    "ChatDeploymentName": "gpt-4o",
    "EmbeddingDeploymentName": "text-embedding-3-large"
  },
  "JwtSettings": {
    "SecretKey": "your-jwt-secret-key-min-32-chars",
    "Issuer": "ScholarFlow",
    "Audience": "ScholarFlowUsers",
    "ExpirationMinutes": 60
  }
}
```
**⚠️ Important:** This file is gitignored to protect your secrets.

### Running the Application

1. **Build and run the API:**
```bash
cd src/ScholarFlow.API
dotnet restore
dotnet build
dotnet run
```

2. **Access the application:**
   - Web UI: `http://localhost:5288`
   - Swagger API: `http://localhost:5288/swagger`

3. **Login:**
   - For test credentials, please contact sumeet.sethi@infosys.com

### Running Tests

```bash
cd src/ScholarFlow.API.Tests
dotnet test
```

All agent tests use mock implementations - no Azure OpenAI calls needed for testing.

## Validation Rules

The system enforces the following validation rules:

- **Page Count**: 8-25 pages
- **Required Sections**: Title, Abstract, Keywords, Author, References
- **Plagiarism Threshold**: 85% similarity (flags for review if exceeded)
- **Toxicity Threshold**: 70% confidence (flags for review if exceeded)
- **Human Review Trigger**: Submissions with <75% validation confidence

## Audit Logging

All system actions are automatically logged to the `AuditLogs` table with:
- Timestamp and user identity
- Agent/step name and action type
- Submission ID and processing stage
- Detailed messages and error tracking

Query audit logs via: `GET /api/submissions/{id}/audit`

## Key Technical Highlights

### 1. Semantic Kernel Process Framework
- **Built-in orchestration** - No custom workflow engine needed
- **Step-based execution** - Each step wraps an agent with state management
- **Error handling** - Automatic retry and error propagation
- **Audit trail** - Built-in logging at every step

### 2. Multi-Agent Collaboration
- **Specialized agents** - Each agent has a single responsibility
- **Function calling** - Agents use SK function calling for structured output
- **Stateless design** - Agents receive state, process, return result
- **Testable** - All agents have comprehensive unit tests with mocks

### 3. RAG Pipeline
- **Vector embeddings** - Azure OpenAI text-embedding-3-large
- **In-memory store** - Fast retrieval for chat Q&A
- **Semantic search** - Context-aware question answering
- **Multi-document** - Chat across all submissions or specific doc

### 4. Modern UI with Vue.js 3
- **Vue.js 3** - Progressive JavaScript framework via CDN
- **Tailwind CSS** - Utility-first CSS framework for rapid UI development
- **No build step** - Runs directly in browser using Vue global build
- **JWT auth** - Secure token-based authentication
- **Reactive** - Automatic UI updates with Vue's reactivity system
- **Responsive** - Mobile-first design with Tailwind utilities

## Deployment

The application runs as a single ASP.NET Core server that serves both:
1. REST API endpoints (`/api/*`)
2. Static UI files (HTML/CSS/JS)

**Production Considerations:**
- Configure `appsettings.Production.json` for environment-specific settings
- Use Azure Key Vault for secrets management
- Consider SQLite → SQL Server/PostgreSQL for production database
- Add rate limiting and DDoS protection
- Enable CORS for separate frontend deployment if needed

## Future Enhancements

This POC demonstrates core capabilities. For production readiness, several enhancements are recommended:

- **Repository Pattern**: Implement DB repository and unit of work patterns for better data access abstraction
- **Expanded Test Coverage**: Add comprehensive tests for DTOs, models, and DbContext
- **File Reprocessing**: Implement duplicate detection and workflow resumption for failed submissions
- **Enterprise Authentication**: Integrate Azure Entra ID (Azure AD) for SSO and MFA
- **Email Monitoring**: Auto-submit papers from monitored email inbox
- **Intelligent Auto-Approval**: Configurable AI-driven approval based on validation scores with user-defined criteria

**📋 For detailed technical specifications and implementation strategies for these enhancements, see [CAPSTONE_PROJECT_SUBMISSION.md](CAPSTONE_PROJECT_SUBMISSION.md)**

## License

MIT License - Academic/Educational Use

## Authors

Built as a proof-of-concept for automated research document processing with multi-agent AI systems.

---

**For API documentation, see the Postman collection at [docs/ScholarFlow.postman_collection.json](docs/ScholarFlow.postman_collection.json)**
